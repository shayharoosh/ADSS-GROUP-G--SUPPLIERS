# ADSS_Group_G
Submitted by:
shay harush , ID - 314804287
Ilay Cohen , ID - 206515744
Vicor Gavrilenko , ID - 209406255
Noam Tarshish , ID - 207761024
