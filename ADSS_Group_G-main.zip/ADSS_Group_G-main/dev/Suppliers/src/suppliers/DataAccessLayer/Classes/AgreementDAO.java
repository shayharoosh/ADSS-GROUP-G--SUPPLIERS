package suppliers.DataAccessLayer.Classes;

import suppliers.DataAccessLayer.Database;
import suppliers.DataAccessLayer.Interfaces.*;
import suppliers.DataStructures.Message;
import suppliers.DataStructures.Pair;
import suppliers.DomainLayer.Classes.Agreement;
import suppliers.DomainLayer.Classes.Product;

import java.sql.*;
import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class AgreementDAO implements iAgreementDAO {

    private final Connection connection;
    private final HashMap<Integer, Agreement> agreementIM;
    private final iDiscountDAO discountDAO;
    private final iDiscountPerAmountDAO discountPerAmountDAO;
    private final iProductDAO productDAO;
    private final iDeliveryDaysDAO deliveryDaysDAO;

    public AgreementDAO() {
        connection = Database.connect();
        try {
            Statement statement = connection.createStatement();
            statement.execute("PRAGMA foreign_keys=ON;");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        agreementIM = new HashMap<>();
        discountDAO = new DiscountDAO();
        discountPerAmountDAO = new DiscountPerAmountDAO();
        productDAO = new ProductDAO();
        deliveryDaysDAO = new DeliveryDaysDAO();
    }

    @Override
    public Message addAgreement(int supplierID, Agreement agreement) {
        try (PreparedStatement statement = connection.prepareStatement("INSERT INTO agreement (supplierID, paymentType, selfSupply, supplyMethod, supplyTime) VALUES (?, ?, ?, ?, ?)"))
        {
            statement.setInt(1, supplierID);
            statement.setString(2, agreement.getPaymentType());
            statement.setBoolean(3, agreement.getSelfSupply());
            statement.setString(4, agreement.getSupplyMethod());
            statement.setInt(5, agreement.getSupplyTime());
            statement.executeUpdate();
            Message message = deliveryDaysDAO.addDeliveryDays(supplierID, agreement.getSupplyDays());
            if(message.errorOccurred()) return message;
            message = addProducts(supplierID, agreement.getSupplyingProducts());
            if (message.errorOccurred()) return message;
            message = addProducts(supplierID, agreement.getSupplyingProducts());
            if (message.errorOccurred()) return message;
            agreementIM.put(supplierID, agreement);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Message addAgreementWithDiscount(int supplierID, Agreement agreement) {
        try (PreparedStatement statement = connection.prepareStatement("INSERT INTO agreement (supplierID, paymentType, selfSupply, supplyMethod, supplyTime) VALUES (?, ?, ?, ?, ?)"))
        {
            statement.setInt(1, supplierID);
            statement.setString(2, agreement.getPaymentType());
            statement.setBoolean(3, agreement.getSelfSupply());
            statement.setString(4, agreement.getSupplyMethod());
            statement.setInt(5, agreement.getSupplyTime());
            statement.executeUpdate();
            Message message = deliveryDaysDAO.addDeliveryDays(supplierID, agreement.getSupplyDays());
            if(message.errorOccurred()) return message;
            Pair<Integer, Double> discount = agreement.getTotalAmountDiscountPerOrder();
            if (discount != null)
                message = discountDAO.addDiscount(supplierID, "Amount", discount);
            if (message.errorOccurred()) return message;
            Pair<Double, Double> discount2 = agreement.getTotalPriceDiscountPerOrder();
            if (discount2 != null)
                message = discountDAO.addDiscount(supplierID, "Price", discount2);
            if (message.errorOccurred()) return message;
            message = addProducts(supplierID, agreement.getSupplyingProducts());
            if (message.errorOccurred()) return message;
            message = addDiscountsOnProducts(supplierID, agreement.getSupplyingProducts());
            if (message.errorOccurred()) return message;
            agreementIM.put(supplierID, agreement);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }

    }

    @Override
    public Message removeAgreement(int supplierID) {
        try (PreparedStatement statement = connection.prepareStatement("DELETE FROM agreement WHERE supplierID = ?"))
        {
            statement.setInt(1, supplierID);
            statement.executeUpdate();
            agreementIM.remove(supplierID);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Message updateAgreement(int supplierID, String paymentType, boolean selfSupply, String supplyMethod, int supplyTime) {
        try (PreparedStatement statement = connection.prepareStatement("UPDATE agreement SET paymentType = ?, selfSupply = ?, supplyMethod = ?, supplyTime = ? WHERE supplierID = ?")) {
            statement.setString(1, paymentType);
            statement.setBoolean(2, selfSupply);
            statement.setString(3, supplyMethod);
            statement.setInt(4, supplyTime);
            statement.setInt(5, supplierID);
            statement.executeUpdate();
            if (agreementIM.containsKey(supplierID))
            {
                Agreement agreement = agreementIM.get(supplierID);
                agreement.setPaymentType(paymentType);
                agreement.setSelfSupply(selfSupply);
                agreement.setSupplyMethod(supplyMethod);
                agreement.setSupplyTime(supplyTime);
            }
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Agreement getAgreementByID(int supplierID) {
        if(agreementIM.containsKey(supplierID)) return agreementIM.get(supplierID);
        try (PreparedStatement agreementStatement = connection.prepareStatement("SELECT * FROM agreement WHERE supplierID = ?")) {
            agreementStatement.setInt(1, supplierID);
            ResultSet agreementResult = agreementStatement.executeQuery();
            if (agreementResult.next())
            {
                String paymentType = agreementResult.getString("paymentType");
                boolean selfSupply = agreementResult.getBoolean("selfSupply");
                String supplyMethod = agreementResult.getString("supplyMethod");
                int supplyTime = agreementResult.getInt("supplyTime");
                ArrayList<DayOfWeek> supplyDays = deliveryDaysDAO.getDeliveryDays(supplierID);
                Agreement agreement = new Agreement(paymentType, selfSupply, supplyMethod, supplyTime, supplyDays);
                agreement.setTotalAmountDiscountPerOrder(discountDAO.getAmountDiscountByID(supplierID));
                agreement.setTotalPriceDiscountPerOrder(discountDAO.getPriceDiscountByID(supplierID));
                agreement.setSupplyingProducts(productDAO.getAllProductsByID(supplierID));
                agreementIM.put(supplierID, agreement);
                return agreement;
            }
            return null;
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    @Override
    public Message addProducts(int supplierID, Map<Integer, Product> supplyingProducts) {
        for(Product product : supplyingProducts.values())
        {
            Message res = productDAO.addProduct(supplierID, product);
            if(res.errorOccurred()) return res;
        }
        return new Message(supplierID);
    }

    @Override
    public Message addDiscountsOnProducts(int supplierID, Map<Integer, Product> supplyingProducts) {
        for(Product product : supplyingProducts.values())
        {
            for(Map.Entry<Integer, Double> discount : product.getDiscountPerAmount().entrySet()) {
                discountPerAmountDAO.addDiscountPerAmount(supplierID, product.getProductID(), discount.getKey(), discount.getValue());
            }
        }
        return new Message(supplierID);
    }
}

