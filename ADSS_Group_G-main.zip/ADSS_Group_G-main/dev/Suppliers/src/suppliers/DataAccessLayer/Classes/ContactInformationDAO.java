package suppliers.DataAccessLayer.Classes;
import suppliers.DataAccessLayer.Database;
import suppliers.DataAccessLayer.Interfaces.iContactInformationDAO;
import suppliers.DataStructures.Message;
import suppliers.DataStructures.Pair;
import suppliers.DomainLayer.Classes.ContactInformation;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

public class ContactInformationDAO implements iContactInformationDAO {
    private final Connection connection;
    private final HashMap<Pair<Integer, String>, ContactInformation> contactInformationIM;

    public ContactInformationDAO()
    {
        connection = Database.connect();
        try {
            Statement statement = connection.createStatement();
            statement.execute("PRAGMA foreign_keys=ON;");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        contactInformationIM = new HashMap<>();
    }


    @Override
    public Message addContactInformation(int supplierID, ContactInformation contactInformation) {
        try (PreparedStatement contactStatement = connection.prepareStatement("INSERT INTO contactInformation (supplierID, phoneNumber, name, email) VALUES (?, ?, ?, ?)"))
        {
            contactStatement.setInt(1, supplierID);
            contactStatement.setString(2, contactInformation.getPhoneNumber());
            contactStatement.setString(3, contactInformation.getName());
            contactStatement.setString(4, contactInformation.getEmailAddress());
            contactStatement.executeUpdate();
            Pair<Integer, String> pair = new Pair<>(supplierID, contactInformation.getPhoneNumber());
            contactInformationIM.put(pair, contactInformation);
        } catch (SQLException e) { return new Message(e.getMessage()); }
        return new Message(supplierID);
    }

    @Override
    public Message removeContactInformation(int supplierID, String phoneNumber) {
        try (PreparedStatement statement = connection.prepareStatement("DELETE FROM contactInformation WHERE supplierID = ? AND phoneNumber = ?"))
        {
            statement.setInt(1, supplierID);
            statement.setString(2, phoneNumber);
            statement.executeUpdate();
            contactInformationIM.remove(new Pair<>(supplierID, phoneNumber));
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    public ArrayList<ContactInformation> getContactsBySupplierID(int SupplierID) {
        try (PreparedStatement contactStatement = connection.prepareStatement("SELECT * FROM contactInformation WHERE supplierID = ?")) {
            contactStatement.setInt(1, SupplierID);
            ResultSet discountResult = contactStatement.executeQuery();
            ArrayList<ContactInformation> contacts = new ArrayList<>();
            while (discountResult.next())
            {
                String name = discountResult.getString("name");
                String email = discountResult.getString("email");
                String phoneNumber = discountResult.getString("phoneNumber");
                Pair<Integer, String> pair = new Pair<>(SupplierID, phoneNumber);
                if(contactInformationIM.containsKey(pair)) contacts.add(contactInformationIM.get(pair));
                else
                {
                    ContactInformation contact = new ContactInformation(name, phoneNumber,email);
                    contactInformationIM.put(pair, contact);
                    contacts.add(contact);
                }
            }
            return contacts;
        } catch (SQLException e) { System.out.println(e.getMessage()); }
        return null;
    }

    @Override
    public ContactInformation getContactBySupplierID(int supplierID, String phoneNumber) {
        Pair<Integer, String> pair = new Pair<>(supplierID, phoneNumber);
        if(contactInformationIM.containsKey(pair)) return contactInformationIM.get(pair);
        try (PreparedStatement contactStatement = connection.prepareStatement("SELECT * FROM contactInformation WHERE supplierID = ? AND phoneNumber = ?")) {
            contactStatement.setInt(1, supplierID);
            contactStatement.setString(2, phoneNumber);
            ResultSet discountResult = contactStatement.executeQuery();
            if (discountResult.next())
            {
                String name = discountResult.getString("name");
                String email = discountResult.getString("email");
                ContactInformation contactInformation = new ContactInformation(name, phoneNumber, email);
                contactInformationIM.put(pair, contactInformation);
                return contactInformation;
            }
        } catch (SQLException e) { System.out.println(e.getMessage()); }
        return null;
    }

    @Override
    public Message updateName(int supplierID, String phoneNumber, String newName) {
        try (PreparedStatement statement = connection.prepareStatement("UPDATE contactInformation SET name = ? WHERE supplierID = ? AND phoneNumber = ?"))
        {
            statement.setString(1, newName);
            statement.setInt(2, supplierID);
            statement.setString(3, phoneNumber);
            statement.executeUpdate();
            Pair<Integer, String> oldPair = new Pair<>(supplierID, phoneNumber);
            if (contactInformationIM.containsKey(oldPair)) contactInformationIM.get(oldPair).setName(newName);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Message updatePhoneNumber(int supplierID, String oldPhoneNumber,  String newPhoneNumber) {
        try (PreparedStatement statement = connection.prepareStatement("UPDATE contactInformation SET phoneNumber = ? WHERE supplierID = ? AND phoneNumber = ?"))
        {
            statement.setString(1, newPhoneNumber);
            statement.setInt(2, supplierID);
            statement.setString(3, oldPhoneNumber);
            statement.executeUpdate();
            Pair<Integer, String> oldPair = new Pair<>(supplierID, oldPhoneNumber);
            if (contactInformationIM.containsKey(oldPair)){
                ContactInformation contactInformation = contactInformationIM.get(oldPair);
                contactInformation.setPhoneNumber(newPhoneNumber);
                contactInformationIM.put(new Pair<>(supplierID, newPhoneNumber), contactInformation);
                contactInformationIM.remove(oldPair);
            }
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Message updateEmail(int supplierID,  String phoneNumber, String email) {
        try (PreparedStatement statement = connection.prepareStatement("UPDATE contactInformation SET email = ? WHERE supplierID = ? AND phoneNumber = ?"))
        {
            statement.setString(1, email);
            statement.setInt(2, supplierID);
            statement.setString(3, phoneNumber);
            statement.executeUpdate();
            Pair<Integer, String> oldPair = new Pair<>(supplierID, phoneNumber);
            if (contactInformationIM.containsKey(oldPair)) contactInformationIM.get(oldPair).setEmailAddress(email);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }


}
