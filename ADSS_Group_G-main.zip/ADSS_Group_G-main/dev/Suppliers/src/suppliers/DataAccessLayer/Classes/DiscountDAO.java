package suppliers.DataAccessLayer.Classes;
import suppliers.DataAccessLayer.Database;
import suppliers.DataAccessLayer.Interfaces.iDiscountDAO;
import suppliers.DataStructures.Message;
import suppliers.DataStructures.Pair;

import java.sql.*;
import java.util.HashMap;
import java.util.Objects;

public class DiscountDAO implements iDiscountDAO {
    private Connection connection;
    private HashMap<Pair<Integer, String>, Pair<Double, Double>> discountIM;
    public DiscountDAO() {
        connection = Database.connect();
        try {
            Statement statement = connection.createStatement();
            statement.execute("PRAGMA foreign_keys=ON;");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        discountIM = new HashMap<>();
    }

    @Override
    public Message addDiscount(int supplierID, String type, Pair<? extends Number, Double> discount) {
        try (PreparedStatement statement = connection.prepareStatement("INSERT INTO discount (supplierID, type, amount, discount) VALUES (?, ?, ?, ?)"))
        {
            statement.setInt(1, supplierID);
            statement.setString(2, type);
            if(discount.getKey() instanceof Integer) statement.setDouble(3, ((Integer) discount.getKey()).doubleValue());
            else statement.setDouble(3, (Double) discount.getKey());
            statement.setDouble(4, (Double) discount.getValue());
            statement.executeUpdate();
            Pair<Integer, String> pair = new Pair<>(supplierID, type);
            Pair<Double, Double> pairAmountAndDiscount;
            if(discount.getKey() instanceof Integer) pairAmountAndDiscount = new Pair<>(((Integer) discount.getKey()).doubleValue(), (Double)discount.getValue());
            else pairAmountAndDiscount = new Pair<>((Double) discount.getKey(), (Double)discount.getValue());
            discountIM.put(pair, pairAmountAndDiscount);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Message removeDiscount(int supplierID, String type) {
        try (PreparedStatement statement = connection.prepareStatement("DELETE FROM discount WHERE supplierID = ? AND type = ?"))
        {
            statement.setInt(1, supplierID);
            statement.setString(2, type);
            statement.executeUpdate();
            discountIM.remove(new Pair<>(supplierID, type));
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Pair<Integer, Double> getAmountDiscountByID(int supplierID) {
        Pair<Integer, String> pair = new Pair<>(supplierID, "Amount");
        Pair<Double, Double> oldPair;
        if(discountIM.containsKey(pair))
        {
            oldPair = discountIM.get(pair);
            return new Pair<>(oldPair.getValue().intValue(), oldPair.getValue());
        }
        try (PreparedStatement discountStatement = connection.prepareStatement("SELECT * FROM discount WHERE supplierID = ?")) {
            discountStatement.setInt(1, supplierID);
            ResultSet discountResult = discountStatement.executeQuery();
            while (discountResult.next())
            {
                if(Objects.equals(discountResult.getString("type"), "Amount"))
                {
                    int amount = (int)discountResult.getDouble("amount");
                    double discount = discountResult.getDouble("discount");
                    Pair<Integer, Double> pairAmountAndDiscount = new Pair<>(amount, discount);
                    discountIM.put(pair, new Pair<>(discountResult.getDouble("amount"), discount));
                    return pairAmountAndDiscount;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    @Override
    public Pair<Double, Double> getPriceDiscountByID(int supplierID) {
        Pair<Integer, String> pair = new Pair<>(supplierID, "Price");
        if(discountIM.containsKey(pair)) return discountIM.get(pair);
        try (PreparedStatement discountStatement = connection.prepareStatement("SELECT * FROM discount WHERE supplierID = ?")) {
            discountStatement.setInt(1, supplierID);
            ResultSet discountResult = discountStatement.executeQuery();
            while (discountResult.next())
            {
                if(Objects.equals(discountResult.getString("type"), "Price"))
                {
                    double amount = discountResult.getDouble("amount");
                    double discount = discountResult.getDouble("discount");
                    Pair<Double, Double> pairAmountAndDiscount = new Pair<>(amount, discount);
                    discountIM.put(pair, pairAmountAndDiscount);
                    return pairAmountAndDiscount;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

}
