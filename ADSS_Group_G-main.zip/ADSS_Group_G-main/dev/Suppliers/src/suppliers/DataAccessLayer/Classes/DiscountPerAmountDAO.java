package suppliers.DataAccessLayer.Classes;

import suppliers.DataAccessLayer.Database;
import suppliers.DataAccessLayer.Interfaces.iDiscountPerAmountDAO;
import suppliers.DataStructures.Message;
import suppliers.DataStructures.Pair;

import java.sql.*;
import java.util.HashMap;

public class DiscountPerAmountDAO implements iDiscountPerAmountDAO {
    private Connection connection;
    private HashMap<Pair<Integer, Integer>, HashMap<Integer, Double>> discountPerAmountIM;

    public DiscountPerAmountDAO() {
        connection = Database.connect();
        try {
            Statement statement = connection.createStatement();
            statement.execute("PRAGMA foreign_keys=ON;");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        discountPerAmountIM = new HashMap<>();
    }
    @Override
    public Message addDiscountPerAmount(int supplierID, int productID, int discountPerAmount ,double discount) {
        try (PreparedStatement statement = connection.prepareStatement("INSERT INTO discountPerAmount (supplierID, productID, discountPerAmount, discount) VALUES (?, ?, ?, ?)"))
        {
            statement.setInt(1, supplierID);
            statement.setInt(2, productID);
            statement.setInt(3, discountPerAmount);
            statement.setDouble(4, discount);
            statement.executeUpdate();
            Pair<Integer, Integer> pair = new Pair<>(supplierID, productID);
            if(discountPerAmountIM.containsKey(pair)) discountPerAmountIM.get(pair).put(discountPerAmount, discount);
            else
            {
                HashMap<Integer, Double> discountHash = new HashMap<>();
                discountHash.put(discountPerAmount, discount);
                discountPerAmountIM.put(pair, discountHash);
            }
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Message removeDiscountPerAmount(int supplierID, int productID, int discountPerAmount) {
        try (PreparedStatement statement = connection.prepareStatement("DELETE FROM discountPerAmount WHERE supplierID = ? AND productID = ? AND discountPerAmount = ?"))
        {
            statement.setInt(1, supplierID);
            statement.setInt(2, productID);
            statement.setInt(3, discountPerAmount);
            statement.executeUpdate();
            Pair<Integer, Integer> pair = new Pair<>(supplierID, productID);
            if(discountPerAmountIM.containsKey(pair)) discountPerAmountIM.get(pair).remove(discountPerAmount);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }


    @Override
    public HashMap<Integer, Double> getProductDiscountByID(int supplierID, int productID) {
        Pair<Integer, Integer> pair = new Pair<>(supplierID, productID);
        if(discountPerAmountIM.containsKey(pair)) return discountPerAmountIM.get(pair);
        try (PreparedStatement discountStatement = connection.prepareStatement("SELECT * FROM discountPerAmount WHERE supplierID = ? AND productID = ?")) {
            discountStatement.setInt(1, supplierID);
            discountStatement.setInt(2, productID);
            ResultSet discountResult = discountStatement.executeQuery();
            HashMap<Integer, Double> discountPerAmount = new HashMap<>();
            while (discountResult.next())
            {
                int amount = discountResult.getInt("discountPerAmount");
                double discount = discountResult.getDouble("discount");
                discountPerAmount.put(amount, discount);
            }
            discountPerAmountIM.put(pair, discountPerAmount);
            return discountPerAmount;
        } catch (SQLException e) { throw new RuntimeException(e); }
    }
}
