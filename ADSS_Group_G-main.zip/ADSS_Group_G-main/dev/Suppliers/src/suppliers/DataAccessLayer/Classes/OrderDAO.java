package suppliers.DataAccessLayer.Classes;

import suppliers.DataAccessLayer.Database;
import suppliers.DataAccessLayer.Interfaces.iOrderDAO;
import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.Order;

import java.sql.*;


import java.sql.Connection;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

public class OrderDAO implements iOrderDAO {
    private final Connection connection;
    private final HashMap<Integer, Order> orderIM;
    private final ProductsInOrderDAO productsInOrderDAO;

    public OrderDAO() {
        connection = Database.connect();
        try {
            Statement statement = connection.createStatement();
            statement.execute("PRAGMA foreign_keys=ON;");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        orderIM = new HashMap<>();
        productsInOrderDAO = new ProductsInOrderDAO();
    }

    @Override
    public Message addOrder(Order order) {
        try (PreparedStatement contactStatement = connection.prepareStatement("INSERT INTO supplierOrder (orderID, supplierID, supplierName, supplierAddress, contactPhoneNumber, branchID, creationDate, deliveryDate, collected, totalPriceBeforeDiscount, totalPriceAfterDiscount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"))
        {
            contactStatement.setInt(1, order.getOrderID());
            contactStatement.setInt(2, order.getSupplierId());
            contactStatement.setString(3, order.getSupplierName());
            contactStatement.setString(4, order.getSupplierAddress());
            contactStatement.setString(5, order.getContactPhoneNumber());
            contactStatement.setInt(6, order.getBranchID());
            contactStatement.setString(7, localDateToString(order.getCreationDate()));
            contactStatement.setString(8, localDateToString(order.getDeliveryDate()));
            contactStatement.setBoolean(9, order.getCollected());
            contactStatement.setDouble(10, order.getTotalPriceBeforeDiscount());
            contactStatement.setDouble(11, order.getTotalPriceAfterDiscount());
            contactStatement.executeUpdate();
            productsInOrderDAO.addProductsToOrder(order.getOrderID(), order.getProductsInOrder());
            orderIM.put(order.getOrderID(), order);
        } catch (SQLException e) { return new Message(e.getMessage()); }
        return new Message(order.getOrderID());
    }

    @Override
    public Message removeOrder(int orderID) {
        try (PreparedStatement statement = connection.prepareStatement("DELETE FROM supplierOrder WHERE orderID = ?"))
        {
            statement.setInt(1, orderID);
            statement.executeUpdate();
            orderIM.remove(orderID);
            return new Message(orderID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Message markOrderAsCollected(int orderID) {
        try (PreparedStatement statement = connection.prepareStatement("UPDATE supplierOrder SET collected = 1 WHERE orderID = ?"))
        {
            statement.setInt(1, orderID);
            statement.executeUpdate();
            if (orderIM.containsKey(orderID)) orderIM.get(orderID).setCollected(true);
            return new Message(orderID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Order getOrderByID(int orderID) {
        if(orderIM.containsKey(orderID)) return orderIM.get(orderID);
        try (PreparedStatement supplierStatement = connection.prepareStatement("SELECT * FROM supplierOrder WHERE orderID = ?")) {
            supplierStatement.setInt(1, orderID);
            ResultSet result = supplierStatement.executeQuery();
            if (result.next())
            {
                int supplierID = result.getInt("supplierID");
                String supplierName = result.getString("supplierName");
                String supplierAddress = result.getString("supplierAddress");
                String contactPhoneNumber = result.getString("contactPhoneNumber");
                int branchID = result.getInt("branchID");
                LocalDate creationDate = stringToLocalDate(result.getString("creationDate"));
                LocalDate deliveryDate = stringToLocalDate(result.getString("deliveryDate"));
                boolean collected = result.getBoolean("collected");
                double totalPriceBeforeDiscount = result.getDouble("totalPriceBeforeDiscount");
                double totalPriceAfterDiscount = result.getDouble("totalPriceAfterDiscount");
                Order order = new Order(orderID, supplierID, supplierName, supplierAddress, contactPhoneNumber, branchID, creationDate, deliveryDate, collected, totalPriceBeforeDiscount, totalPriceAfterDiscount);
                order.setProductsInOrder(productsInOrderDAO.getProductsInOrder(orderID, supplierID));
                orderIM.put(orderID, order);
                return order;
            }
        } catch (SQLException e) { System.out.println(e.getMessage()); }
        return null;
    }

    @Override
    public int getLastOrderID() {
        try (Statement statement = connection.createStatement()) {
            String sql = "SELECT MAX(orderID) AS maxOrderID FROM supplierOrder";
            ResultSet rs = statement.executeQuery(sql);
            int maxOrderID = 0;
            if (rs.next()) maxOrderID = rs.getInt("maxOrderID");
            rs.close();
            return maxOrderID;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return -1;
    }

    @Override
    public HashMap<Integer, Order> getAllOrders() {
        try (Statement stmt = connection.createStatement())
        {
            ResultSet result = stmt.executeQuery("SELECT * FROM supplierOrder");
            while (result.next())
            {
                int orderID = result.getInt("orderID");
                if(orderIM.containsKey(orderID)) continue;
                int supplierID = result.getInt("supplierID");
                String supplierName = result.getString("supplierName");
                String supplierAddress = result.getString("supplierAddress");
                String contactPhoneNumber = result.getString("contactPhoneNumber");
                int branchID = result.getInt("branchID");
                LocalDate creationDate = stringToLocalDate(result.getString("creationDate"));
                LocalDate deliveryDate = stringToLocalDate(result.getString("deliveryDate"));
                boolean collected = result.getBoolean("collected");
                double totalPriceBeforeDiscount = result.getDouble("totalPriceBeforeDiscount");
                double totalPriceAfterDiscount = result.getDouble("totalPriceAfterDiscount");
                Order order = new Order(orderID, supplierID, supplierName, supplierAddress, contactPhoneNumber, branchID, creationDate, deliveryDate, collected, totalPriceBeforeDiscount, totalPriceAfterDiscount);
                order.setProductsInOrder(productsInOrderDAO.getProductsInOrder(orderID, supplierID));
                orderIM.put(orderID, order);
            }
            return orderIM;
        } catch (SQLException e) { System.out.println(e.getMessage()); }
        return null;
    }

    @Override
    public HashMap<Integer, Order> getOrdersFromSupplier(int supplierID) {
        HashMap<Integer, Order> supplierOrders = new HashMap<>();
        for(Order order : orderIM.values())
            if(order.getSupplierId() == supplierID) supplierOrders.put(order.getOrderID(), order);
        try (PreparedStatement supplierStatement = connection.prepareStatement("SELECT * FROM supplierOrder WHERE supplierID = ?")) {
            supplierStatement.setInt(1, supplierID);
            ResultSet result = supplierStatement.executeQuery();
            while (result.next())
            {
                int orderID = result.getInt("orderID");
                if(supplierOrders.containsKey(orderID)) continue;
                String supplierName = result.getString("supplierName");
                String supplierAddress = result.getString("supplierAddress");
                String contactPhoneNumber = result.getString("contactPhoneNumber");
                int branchID = result.getInt("branchID");
                LocalDate creationDate = stringToLocalDate(result.getString("creationDate"));
                LocalDate deliveryDate = stringToLocalDate(result.getString("deliveryDate"));
                boolean collected = result.getBoolean("collected");
                double totalPriceBeforeDiscount = result.getDouble("totalPriceBeforeDiscount");
                double totalPriceAfterDiscount = result.getDouble("totalPriceAfterDiscount");
                Order order = new Order(orderID, supplierID, supplierName, supplierAddress, contactPhoneNumber, branchID, creationDate, deliveryDate, collected, totalPriceBeforeDiscount, totalPriceAfterDiscount);
                order.setProductsInOrder(productsInOrderDAO.getProductsInOrder(orderID, supplierID));
                orderIM.put(orderID, order);
                supplierOrders.put(orderID, order);
            }
            return supplierOrders;
        } catch (SQLException e) { System.out.println(e.getMessage()); }
        return null;
    }

    @Override
    public HashMap<Integer, Order> getOrdersToBranch(int branchID) {
        HashMap<Integer, Order> branchOrders = new HashMap<>();
        for(Order order : orderIM.values())
            if(order.getBranchID() == branchID) branchOrders.put(order.getOrderID(), order);
        try (PreparedStatement supplierStatement = connection.prepareStatement("SELECT * FROM supplierOrder WHERE branchID = ?")) {
            supplierStatement.setInt(1, branchID);
            ResultSet result = supplierStatement.executeQuery();
            while (result.next())
            {
                int orderID = result.getInt("orderID");
                if(branchOrders.containsKey(orderID)) continue;
                int supplierID = result.getInt("supplierID");
                String supplierName = result.getString("supplierName");
                String supplierAddress = result.getString("supplierAddress");
                String contactPhoneNumber = result.getString("contactPhoneNumber");
                LocalDate creationDate = stringToLocalDate(result.getString("creationDate"));
                LocalDate deliveryDate = stringToLocalDate(result.getString("deliveryDate"));
                boolean collected = result.getBoolean("collected");
                double totalPriceBeforeDiscount = result.getDouble("totalPriceBeforeDiscount");
                double totalPriceAfterDiscount = result.getDouble("totalPriceAfterDiscount");
                Order order = new Order(orderID, supplierID, supplierName, supplierAddress, contactPhoneNumber, branchID, creationDate, deliveryDate, collected, totalPriceBeforeDiscount, totalPriceAfterDiscount);
                order.setProductsInOrder(productsInOrderDAO.getProductsInOrder(orderID, supplierID));
                orderIM.put(orderID, order);
                branchOrders.put(orderID, order);
            }
            return branchOrders;
        } catch (SQLException e) { System.out.println(e.getMessage()); }
        return null;
    }

    @Override
    public HashMap<Integer, Order> getAllOrderForToday() {
        LocalDate todayDate = LocalDate.now();
        HashMap<Integer, Order> todayOrders = new HashMap<>();
        for(Order order : orderIM.values())
            if(order.getDeliveryDate() == todayDate) todayOrders.put(order.getOrderID(), order);
        try (PreparedStatement supplierStatement = connection.prepareStatement("SELECT * FROM supplierOrder WHERE deliveryDate = ?")) {
            supplierStatement.setString(1, localDateToString(todayDate));
            ResultSet result = supplierStatement.executeQuery();
            while (result.next())
            {
                int orderID = result.getInt("orderID");
                if(todayOrders.containsKey(orderID)) continue;
                int supplierID = result.getInt("supplierID");
                String supplierName = result.getString("supplierName");
                String supplierAddress = result.getString("supplierAddress");
                String contactPhoneNumber = result.getString("contactPhoneNumber");
                int branchID = result.getInt("branchID");
                LocalDate creationDate = stringToLocalDate(result.getString("creationDate"));
                LocalDate deliveryDate = stringToLocalDate(result.getString("deliveryDate"));
                boolean collected = result.getBoolean("collected");
                double totalPriceBeforeDiscount = result.getDouble("totalPriceBeforeDiscount");
                double totalPriceAfterDiscount = result.getDouble("totalPriceAfterDiscount");
                Order order = new Order(orderID, supplierID, supplierName, supplierAddress, contactPhoneNumber, branchID, creationDate, deliveryDate, collected, totalPriceBeforeDiscount, totalPriceAfterDiscount);
                order.setProductsInOrder(productsInOrderDAO.getProductsInOrder(orderID, supplierID));
                orderIM.put(orderID, order);
                todayOrders.put(orderID, order);
            }
            return todayOrders;
        } catch (SQLException e) { System.out.println(e.getMessage()); }
        return null;
    }

    @Override
    public HashMap<Integer, Order> getNoneCollectedOrdersForToday(int branchID) {
        LocalDate todayDate = LocalDate.now();
        HashMap<Integer, Order> todayOrders = new HashMap<>();
        for(Order order : orderIM.values())
            if(order.getDeliveryDate() == todayDate) todayOrders.put(order.getOrderID(), order);
        try (PreparedStatement supplierStatement = connection.prepareStatement("SELECT * FROM supplierOrder WHERE branchID = ? AND deliveryDate = ? AND collected = 0")) {
            supplierStatement.setInt(1, branchID);
            supplierStatement.setString(2, localDateToString(todayDate));
            ResultSet result = supplierStatement.executeQuery();
            while (result.next())
            {
                int orderID = result.getInt("orderID");
                if(todayOrders.containsKey(orderID)) continue;
                int supplierID = result.getInt("supplierID");
                String supplierName = result.getString("supplierName");
                String supplierAddress = result.getString("supplierAddress");
                String contactPhoneNumber = result.getString("contactPhoneNumber");
                LocalDate creationDate = stringToLocalDate(result.getString("creationDate"));
                LocalDate deliveryDate = stringToLocalDate(result.getString("deliveryDate"));
                boolean collected = result.getBoolean("collected");
                double totalPriceBeforeDiscount = result.getDouble("totalPriceBeforeDiscount");
                double totalPriceAfterDiscount = result.getDouble("totalPriceAfterDiscount");
                Order order = new Order(orderID, supplierID, supplierName, supplierAddress, contactPhoneNumber, branchID, creationDate, deliveryDate, collected, totalPriceBeforeDiscount, totalPriceAfterDiscount);
                order.setProductsInOrder(productsInOrderDAO.getProductsInOrder(orderID, supplierID));
                orderIM.put(orderID, order);
                todayOrders.put(orderID, order);
            }
            return todayOrders;
        } catch (SQLException e) { System.out.println(e.getMessage()); }
        return null;
    }

    public LocalDate stringToLocalDate(String dateString) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return LocalDate.parse(dateString, formatter);
    }

    public String localDateToString(LocalDate localDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return localDate.format(formatter);
    }
}
