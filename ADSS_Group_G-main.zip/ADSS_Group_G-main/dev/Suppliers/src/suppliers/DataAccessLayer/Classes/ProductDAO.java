package suppliers.DataAccessLayer.Classes;

import suppliers.DataAccessLayer.Database;
import suppliers.DataAccessLayer.Interfaces.iProductDAO;
import suppliers.DataStructures.Message;
import suppliers.DataStructures.Pair;
import suppliers.DomainLayer.Classes.Product;

import java.sql.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class ProductDAO implements iProductDAO {

        private final Connection connection;
        private HashMap<Pair<Integer, Integer>,Product> productIM;
        private final DiscountPerAmountDAO discountPerAmountDAO;

    public ProductDAO() {
        connection = Database.connect();
        try {
            Statement statement = connection.createStatement();
            statement.execute("PRAGMA foreign_keys=ON;");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        productIM = new HashMap<>();
        discountPerAmountDAO = new DiscountPerAmountDAO();
    }

    @Override
    public Message addProduct(int supplierID, Product product) {
        try (PreparedStatement statement = connection.prepareStatement("INSERT INTO product (supplierID, productID, catalogNumber, name, price, amount, weight, manufacturer, expirationDays) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"))
        {
            statement.setInt(1, supplierID);
            statement.setInt(2, product.getProductID());
            statement.setInt(3, product.getCatalogID());
            statement.setString(4, product.getName());
            statement.setDouble(5, product.getPrice());
            statement.setInt(6, product.getAmount());
            statement.setDouble(7, product.getWeight());
            statement.setString(8, product.getManufacturer());
            statement.setInt(9, product.getExpirationDays());
            statement.executeUpdate();
            productIM.put(new Pair<>(supplierID, product.getProductID()), product);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Message removeProduct(int supplierID, int productID) {
        try (PreparedStatement statement = connection.prepareStatement("DELETE FROM product WHERE supplierID = ? AND productID = ?"))
        {
            statement.setInt(1, supplierID);
            statement.setInt(2, productID);
            statement.executeUpdate();
            Pair<Integer, Integer> pair = new Pair<>(supplierID, productID);
            productIM.remove(pair);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Message updateProducts(int supplierID, ArrayList<Product> products) {
        for(Product product : getAllProductsByID(supplierID).values())
        {
            Message message = removeProduct(supplierID, product.getProductID());
            if(message.errorOccurred()) return message;

        }

        for(Product product : products)
        {
            try (PreparedStatement statement = connection.prepareStatement("INSERT INTO product (supplierID, productID, catalogNumber, name, price, amount, weight, manufacturer, expirationDays) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                statement.setInt(1, supplierID);
                statement.setInt(2, product.getProductID());
                statement.setInt(3, product.getCatalogID());
                statement.setString(4, product.getName());
                statement.setDouble(5, product.getPrice());
                statement.setInt(6, product.getAmount());
                statement.setDouble(7, product.getWeight());
                statement.setString(8, product.getManufacturer());
                statement.setInt(9, product.getExpirationDays());
                statement.executeUpdate();
                for (Map.Entry<Integer, Double> entry : product.getDiscountPerAmount().entrySet())
                {
                    Message message = discountPerAmountDAO.addDiscountPerAmount(supplierID, product.getProductID(), entry.getKey(), entry.getValue());
                    if(message.errorOccurred()) return message;
                }
                productIM.put(new Pair<>(supplierID, product.getProductID()), product);
            } catch (SQLException e) {
                System.out.println(Arrays.toString(e.getStackTrace()));
                return new Message(e.getMessage());
            }
        }
        return new Message(supplierID);
    }

    @Override
    public Product getProduct(int supplierID, int productID) {
        Pair<Integer, Integer> pair = new Pair<>(supplierID, productID);
        if(productIM.containsKey(pair)) return productIM.get(pair);
        try (PreparedStatement sProductStatement = connection.prepareStatement("SELECT * FROM product WHERE supplierID = ? AND productID = ?")) {
            sProductStatement.setInt(1, supplierID);
            sProductStatement.setInt(2, productID);
            ResultSet supplierResult = sProductStatement.executeQuery();
            if (supplierResult.next())
            {
                String name = supplierResult.getString("name");
                int catalogID = supplierResult.getInt("catalogNumber");
                double price = supplierResult.getDouble("price");
                String manufacturer = supplierResult.getString("manufacturer");
                int expirationDays = supplierResult.getInt("expirationDays");
                Double weight = supplierResult.getDouble("weight");
                HashMap<Integer, Double> discountPerAmount = discountPerAmountDAO.getProductDiscountByID(supplierID, productID);
                int amount = supplierResult.getInt("amount");
                Product product = new Product(name, supplierID, productID, catalogID, price, amount, discountPerAmount, manufacturer, expirationDays, weight);
                productIM.put(pair, product);
                return product;
            }
        } catch (SQLException e) { System.out.println(e.getMessage()); }
        return null;
    }

    @Override
    public HashMap<Integer, Product> getAllProductsByID(int supplierID) {
        try (PreparedStatement sProductStatement = connection.prepareStatement("SELECT * FROM product WHERE supplierID = ?")) {
            sProductStatement.setInt(1, supplierID);
            ResultSet supplierResult = sProductStatement.executeQuery();
            HashMap<Integer, Product> supplierProducts = new HashMap<>();
            while (supplierResult.next())
            {
                String name = supplierResult.getString("name");
                int catalogID = supplierResult.getInt("catalogNumber");
                int productID = supplierResult.getInt("productID");
                double price = supplierResult.getDouble("price");
                String manufacturer = supplierResult.getString("manufacturer");
                int expirationDays = supplierResult.getInt("expirationDays");
                Double weight = supplierResult.getDouble("weight");
                HashMap<Integer, Double> discountPerAmount = discountPerAmountDAO.getProductDiscountByID(supplierID, productID);
                int amount = supplierResult.getInt("amount");
                Pair<Integer, Integer> pair = new Pair<>(supplierID, productID);
                if(!productIM.containsKey(pair))
                {
                    Product product = new Product(name, supplierID, productID, catalogID, price, amount, discountPerAmount, manufacturer, expirationDays, weight);
                    productIM.put(pair, product);
                    supplierProducts.put(productID, product);
                }
                else
                    supplierProducts.put(productID, productIM.get(pair));
            }
            return supplierProducts;
        } catch (SQLException e) { System.out.println(e.getMessage()); }
        return null;
    }

    @Override
    public Message updateCatalogID(int supplierID, int productID, int catalogID) {
        try (PreparedStatement statement = connection.prepareStatement("UPDATE product SET catalogNumber = ? WHERE supplierID = ? AND productID = ?"))
        {
            statement.setInt(1, catalogID);
            statement.setInt(2, supplierID);
            statement.setInt(3, productID);
            statement.executeUpdate();
            Pair<Integer, Integer> pair = new Pair<>(supplierID, productID);
            if (productIM.containsKey(pair)) productIM.get(pair).setCatalogID(catalogID);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Message updateAmount(int supplierID, int productID, int amount) {
        try (PreparedStatement statement = connection.prepareStatement("UPDATE product SET amount = ? WHERE supplierID = ? AND productID = ?"))
        {
            statement.setInt(1, amount);
            statement.setInt(2, supplierID);
            statement.setInt(3, productID);
            statement.executeUpdate();
            Pair<Integer, Integer> pair = new Pair<>(supplierID, productID);
            if (productIM.containsKey(pair)) productIM.get(pair).setAmount(amount);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public void printProductsBySupplierID(int supplierID) {
        try (PreparedStatement stmt = connection.prepareStatement("SELECT * FROM product WHERE supplierID = ?"))
        {
            stmt.setInt(1, supplierID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
            {
                int productID = rs.getInt("productID");
                int catalogNumber = rs.getInt("catalogNumber");
                String name = rs.getString("name");
                int amount = rs.getInt("amount");
                double price = rs.getDouble("price");
                double weight = rs.getDouble("weight");
                String manufacturer = rs.getString("manufacturer");
                String expirationDays = rs.getString("expirationDays");
                System.out.println("Supplier ID: " + supplierID + ", Product ID: " + productID + ", Catalog Number: " + catalogNumber + ", Name: " + name + ", Amount: " + amount + ", Price: " + price + ", Weight: " + weight + ", Manufacturer: " + manufacturer + ", Expiration Days: " + expirationDays);
            }
            rs.close();
        } catch (SQLException e) { System.out.println(e.getMessage());}
    }



}
