package suppliers.DataAccessLayer.Classes;

import suppliers.DataAccessLayer.Database;
import suppliers.DataAccessLayer.Interfaces.iProductsInOrderDAO;
import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

public class ProductsInOrderDAO implements iProductsInOrderDAO {
    private final Connection connection;
    private HashMap<Integer, ArrayList<Product>> productsInOrderIM;
    private final ProductDAO productDAO;

    public ProductsInOrderDAO() {
        connection = Database.connect();
        try {
            Statement statement = connection.createStatement();
            statement.execute("PRAGMA foreign_keys=ON;");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        productsInOrderIM = new HashMap<>();
        productDAO = new ProductDAO();
    }
    @Override
    public Message addProductsToOrder(int orderID, ArrayList<Product> productsInOrder) {
        try (PreparedStatement statement = connection.prepareStatement("INSERT INTO productsInOrder (orderID, supplierID, productID, amountInOrder) VALUES (?, ?, ?, ?)"))
        {
            for(Product product : productsInOrder)
            {
                statement.setInt(1, orderID);
                statement.setInt(2, product.getSupplierID());
                statement.setInt(3, product.getProductID());
                statement.setInt(4, product.getAmount());
                statement.executeUpdate();
            }
            productsInOrderIM.put(orderID, productsInOrder);
            return new Message(orderID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Message removeProductFromOrder(int orderID, int productID) {
        return null;
    }

    @Override
    public Message updateProductAmountInOrder(int orderID, int productID, int amountInOrder) {
        return null;
    }

    @Override
    public ArrayList<Product> getProductsInOrder(int orderID, int supplierID) {
        if(productsInOrderIM.containsKey(orderID)) return productsInOrderIM.get(orderID);
        productsInOrderIM.put(orderID, new ArrayList<>());
        try (PreparedStatement supplierStatement = connection.prepareStatement("SELECT * FROM productsInOrder WHERE orderID = ?")) {
            supplierStatement.setInt(1, orderID);
            ResultSet result = supplierStatement.executeQuery();
            while (result.next())
            {
                int productID = result.getInt("productID");
                int amountInOrder = result.getInt("amountInOrder");
                Product product = new Product(productDAO.getProduct(supplierID, productID));
                product.setAmount(amountInOrder);
                productsInOrderIM.get(orderID).add(product);
            }
            return productsInOrderIM.get(orderID);
        } catch (SQLException e) { System.out.println(e.getMessage()); }
        return null;
    }
}
