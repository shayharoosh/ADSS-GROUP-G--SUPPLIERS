package suppliers.DataAccessLayer.Classes;

import suppliers.DataAccessLayer.Database;
import suppliers.DomainLayer.Classes.Product;
import suppliers.DomainLayer.Controllers.ProductController;

import java.sql.*;
import java.util.ArrayList;

public class ProductsInPeriodicOrderDAO {

    private final Connection connection;

    public ProductsInPeriodicOrderDAO() {
        connection = Database.connect();
    }

    public void addProductsToPeriodicOrder(int orderID, ArrayList<Product> products, int supplierID) {
        for (Product product : products) {
            try (PreparedStatement statement = connection.prepareStatement("INSERT INTO productsInPeriodicOrder (periodicOrderID, productID, supplierID, amountInOrder) VALUES (?, ?, ?, ?)")) {
                statement.setInt(1, orderID);
                statement.setInt(2, product.getProductID());
                statement.setInt(3, supplierID);
                statement.setInt(4, product.getAmount());
                statement.executeUpdate();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public ArrayList<Product> getProductsInPeriodicOrder(int orderID, int supplierID) {
        ArrayList<Product> products = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement("SELECT * FROM productsInPeriodicOrder WHERE periodicOrderID = ?")) {
            statement.setInt(1, orderID);
            ResultSet result = statement.executeQuery();
            ProductController productController = new ProductController();
            while (result.next()) {
                int productID = result.getInt("productID");
                int amountInOrder = result.getInt("amountInOrder");
                Product product = productController.getProductById(productID);
                if (product != null) {
                    product.setAmount(amountInOrder);
                    products.add(product);
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return products;
    }
}
