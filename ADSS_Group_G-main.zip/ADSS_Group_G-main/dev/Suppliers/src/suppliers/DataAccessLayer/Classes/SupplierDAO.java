package suppliers.DataAccessLayer.Classes;
import suppliers.DataAccessLayer.Database;
import suppliers.DataStructures.Pair;
import java.sql.*;
import suppliers.DataAccessLayer.Interfaces.*;
import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.Agreement;
import suppliers.DomainLayer.Classes.ContactInformation;
import suppliers.DomainLayer.Classes.Product;
import suppliers.DomainLayer.Classes.Supplier;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class SupplierDAO implements iSupplierDAO {
    private final Connection connection;
    private final HashMap<Integer, Supplier> suppliersIM;
    private final iContactInformationDAO contactInformationDAO;
    private final iDiscountDAO discountDAO;
    private final iDiscountPerAmountDAO discountPerAmountDAO;
    private final iProductDAO productDAO;
    private final iAgreementDAO agreementDAO;

    public SupplierDAO() {
        connection = Database.connect();
        try {
            Statement statement = connection.createStatement();
            statement.execute("PRAGMA foreign_keys=ON;");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        suppliersIM = new HashMap<>();
        contactInformationDAO = new ContactInformationDAO();
        discountDAO = new DiscountDAO();
        discountPerAmountDAO = new DiscountPerAmountDAO();
        productDAO = new ProductDAO();
        agreementDAO = new AgreementDAO();
    }

    @Override
    public Message addSupplier(Supplier supplier) {
        try (PreparedStatement supplierStatement = connection.prepareStatement("INSERT INTO supplier (supplierID, name, address, bankAccount) VALUES (?, ?, ?, ?)"))
        {
            supplierStatement.setInt(1, supplier.getSupplierId());
            supplierStatement.setString(2, supplier.getName());
            supplierStatement.setString(3, supplier.getAddress());
            supplierStatement.setString(4, supplier.getBankAccount());
            supplierStatement.executeUpdate();
            Message message;
            for(ContactInformation contactInformation : supplier.getContacts())
            {
                message = contactInformationDAO.addContactInformation(supplier.getSupplierId(), contactInformation);
                if(message.errorOccurred()) return message;
            }
            if(supplier.getAgreement() != null)
            {
                message = agreementDAO.addAgreement(supplier.getSupplierId(), supplier.getAgreement());
                if (message.errorOccurred()) return message;
                Pair<Integer, Double> discount = supplier.getTotalAmountDiscountPerOrder();
                if (supplier.getTotalAmountDiscountPerOrder() != null)
                    message = discountDAO.addDiscount(supplier.getSupplierId(), "Amount", discount);
                if (message.errorOccurred()) return message;
                Pair<Double, Double> discount2 = supplier.getTotalPriceDiscountPerOrder();
                if (supplier.getTotalAmountDiscountPerOrder() != null)
                    message = discountDAO.addDiscount(supplier.getSupplierId(), "Price", discount2);
                if (message.errorOccurred()) return message;
                message = addProducts(supplier.getSupplierId(), supplier.getSupplyingProducts());
                if (message.errorOccurred()) return message;
                message = addDiscountsOnProducts(supplier.getSupplierId(), supplier.getSupplyingProducts());
                if (message.errorOccurred()) return message;
                suppliersIM.put(supplier.getSupplierId(), supplier);
            }
            return new Message(supplier.getSupplierId());
        } catch (SQLException e) {
            return new Message(e.getMessage());
        }
    }

    @Override
    public Message removeSupplier(int supplierID) {
        try (PreparedStatement statement = connection.prepareStatement("DELETE FROM supplier WHERE supplierID = ?"))
        {
            statement.setInt(1, supplierID);
            statement.executeUpdate();
            suppliersIM.remove(supplierID);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public HashMap<Integer, Supplier> getAllSuppliers() {
        try (Statement stmt = connection.createStatement())
        {
            ResultSet supplierResult = stmt.executeQuery("SELECT * FROM supplier");
            while (supplierResult.next())
            {
                int supplierID = supplierResult.getInt("supplierID");
                if(suppliersIM.containsKey(supplierID)) continue;
                String name = supplierResult.getString("name");
                String address = supplierResult.getString("address");
                ArrayList<ContactInformation> contacts = contactInformationDAO.getContactsBySupplierID(supplierID);
                String bankAccount = supplierResult.getString("bankAccount");
                Agreement agreement = agreementDAO.getAgreementByID(supplierID);
                Supplier supplier = new Supplier(supplierID, name, address, contacts, bankAccount, agreement);
                suppliersIM.put(supplierID, supplier);
            }
            return suppliersIM;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    @Override
    public Supplier getSupplierByID(int supplierID) {
        if(suppliersIM.containsKey(supplierID)) return suppliersIM.get(supplierID);
        try (PreparedStatement supplierStatement = connection.prepareStatement("SELECT * FROM supplier WHERE supplierID = ?")) {
            supplierStatement.setInt(1, supplierID);
            ResultSet supplierResult = supplierStatement.executeQuery();
            if (supplierResult.next())
            {
                String name = supplierResult.getString("name");
                String address = supplierResult.getString("address");
                ArrayList<ContactInformation> contacts = contactInformationDAO.getContactsBySupplierID(supplierID);
                String bankAccount = supplierResult.getString("bankAccount");
                Agreement agreement = agreementDAO.getAgreementByID(supplierID);
                Supplier supplier = new Supplier(supplierID, name, address, contacts, bankAccount, agreement);
                suppliersIM.put(supplierID, supplier);
                return supplier;
            }
        } catch (SQLException e) { System.out.println(e.getMessage()); }
        return null;
    }

    @Override
    public Integer getActiveSupplierByID(int supplierID) {
        if(suppliersIM.containsKey(supplierID)) return supplierID;
        try (PreparedStatement supplierStatement = connection.prepareStatement("SELECT * FROM supplier WHERE supplierID = ?")) {
            supplierStatement.setInt(1, supplierID);
            ResultSet supplierResult = supplierStatement.executeQuery();
            if (supplierResult.next())
            {
                return supplierID;
            }
        } catch (SQLException e) { System.out.println(e.getMessage()); }
        return null;
    }

    @Override
    public void printAllSuppliers() {
        try (Statement stmt = connection.createStatement())
        {
            ResultSet resultSet = stmt.executeQuery("SELECT name, supplierID FROM supplier");
            while (resultSet.next())
            {
                String name = resultSet.getString("name");
                int supplierID = resultSet.getInt("supplierID");
                System.out.println("Supplier's name: " + name + ", supplier's id: " + supplierID + ", supplier's products:" );
                productDAO.printProductsBySupplierID(supplierID);
            }
            resultSet.close();
        } catch (SQLException e) { System.out.println(e.getMessage());}
    }

    @Override
    public Message getSupplierNameById(Integer supplierID) {
        if(suppliersIM.containsKey(supplierID)) return new Message(true,suppliersIM.get(supplierID).getName());
        else {
            try (PreparedStatement supplierStatement = connection.prepareStatement("SELECT * FROM supplier WHERE supplierID = ?")) {
                supplierStatement.setInt(1, supplierID);
                ResultSet supplierResult = supplierStatement.executeQuery();
                if (supplierResult.next())
                {
                    String name = supplierResult.getString("name");
                    return new Message(true,name);
                }
            } catch (SQLException e) { System.out.println(e.getMessage()); }
            return null;
        }
    }

    @Override
    public Message updateSupplierName(int supplierID, String newName) {
        try (PreparedStatement statement = connection.prepareStatement("UPDATE supplier SET name = ? WHERE supplierID = ?"))
        {
            statement.setString(1, newName);
            statement.setInt(2, supplierID);
            statement.executeUpdate();
            if(suppliersIM.containsKey(supplierID)) suppliersIM.get(supplierID).setName(newName);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Message updateSupplierAddress(int supplierID, String newAddress) {
        try (PreparedStatement statement = connection.prepareStatement("UPDATE supplier SET address = ? WHERE supplierID = ?"))
        {
            statement.setString(1, newAddress);
            statement.setInt(2, supplierID);
            statement.executeUpdate();
            if(suppliersIM.containsKey(supplierID)) suppliersIM.get(supplierID).setAddress(newAddress);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Message updateSupplierBankAccount(int supplierID, String newBankAccount) {
        try (PreparedStatement statement = connection.prepareStatement("UPDATE supplier SET bankAccount = ? WHERE supplierID = ?"))
        {
            statement.setString(1, newBankAccount);
            statement.setInt(2, supplierID);
            statement.executeUpdate();
            statement.close();
            if(suppliersIM.containsKey(supplierID)) suppliersIM.get(supplierID).setBankAccount(newBankAccount);
            return new Message(supplierID);
        } catch (SQLException e) { return new Message(e.getMessage()); }
    }

    @Override
    public Message addProducts(int supplierID, Map<Integer, Product> supplyingProducts) {
        for(Product product : supplyingProducts.values())
        {
            Message res = productDAO.addProduct(supplierID, product);
            if(res.errorOccurred()) return res;
        }
        return new Message(supplierID);
    }

    @Override
    public Message addDiscountsOnProducts(int supplierID, Map<Integer, Product> supplyingProducts) {
        for(Product product : supplyingProducts.values())
        {
            for(Map.Entry<Integer, Double> discount : product.getDiscountPerAmount().entrySet()) {
                discountPerAmountDAO.addDiscountPerAmount(supplierID, product.getProductID(), discount.getKey(), discount.getValue());
            }
        }
        return new Message(supplierID);
    }

    public int getLastSupplierID()
    {
        try (Statement statement = connection.createStatement()) {
            String sql = "SELECT MAX(supplierID) AS maxSupplierID FROM supplier";
            ResultSet rs = statement.executeQuery(sql);
            int maxSupplierID = 0;
            if (rs.next()) maxSupplierID = rs.getInt("maxSupplierID");
            rs.close();
            return maxSupplierID;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return -1;
    }

    public Message searchBankAccount(String bankAccount)
    {
        try (PreparedStatement statement = connection.prepareStatement("SELECT * FROM supplier WHERE bankAccount = ?"))
        {
            statement.setString(1, bankAccount);
            ResultSet supplierResult = statement.executeQuery();
            return new Message(supplierResult.next());
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return new Message("SQL ERROR");
    }
}
