package suppliers.DataAccessLayer;
import java.sql.*;
import PresentationLayer.ConfigReader;


public class Database {
    //private static final String url = "jdbc:sqlite:SuppliersDB.db";
    private static final String url = PresentationLayer.ConfigReader.getProperty("db.suppliers.url");

    private static Connection connection = null;


    public static Connection connect() {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(url);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }


    public static void disconnect() {
        try {
            if (connection != null){
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void clearTables() {
        String[] tables = {"supplier", "contactInformation", "agreement", "discount", "product", "discountPerAmount", "supplierOrder", "productsInOrder", "periodicOrder", "productsInPeriodicOrder", "deliveryDays"};
        try (Connection conn = connect();
             Statement stmt = conn.createStatement()) {
            for (String table : tables) {
                stmt.executeUpdate("DROP TABLE IF EXISTS " + table);
            }
            createTables();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void createTables()
    {
        String sql1 = "CREATE TABLE IF NOT EXISTS supplier (\n"
                + "supplierID INTEGER,\n"
                + "name TEXT NOT NULL,\n"
                + "address TEXT NOT NULL,\n"
                + "bankAccount TEXT NOT NULL UNIQUE,\n"
                + "PRIMARY KEY(supplierID)\n"
                + ");";

        String sql2 = "CREATE TABLE IF NOT EXISTS contactInformation (\n"
                + "supplierID INTEGER NOT NULL,\n"
                + "phoneNumber TEXT,\n"
                + "name TEXT NOT NULL,\n"
                + "email TEXT NOT NULL,\n"
                + "PRIMARY KEY(phoneNumber),\n"
                + "CONSTRAINT fk_contactInformation FOREIGN KEY (supplierID) REFERENCES supplier(supplierID) ON DELETE CASCADE ON UPDATE CASCADE\n"
                + ");";

        String sql3 = "CREATE TABLE IF NOT EXISTS agreement (\n"
                + "supplierID INTEGER,\n"
                + "paymentType TEXT NOT NULL,\n"
                + "selfSupply BOOLEAN NOT NULL,\n"
                + "supplyMethod TEXT NOT NULL,\n"
                + "supplyTime INTEGER NOT NULL,\n"
                + "PRIMARY KEY(supplierID),\n"
                + "FOREIGN KEY(supplierID) REFERENCES supplier(supplierID) ON UPDATE CASCADE ON DELETE CASCADE\n"
                + ");";

        String sql4 = "CREATE TABLE IF NOT EXISTS discount (\n"
                + "supplierID INTEGER,\n"
                + "type TEXT NOT NULL,\n"
                + "amount DOUBLE NOT NULL,\n"
                + "discount DOUBLE NOT NULL,\n"
                + "PRIMARY KEY(supplierID, type),\n"
                + "FOREIGN KEY(supplierID) REFERENCES supplier(supplierID) ON UPDATE CASCADE ON DELETE CASCADE\n"
                + ");";

        String sql5 = "CREATE TABLE IF NOT EXISTS product (\n"
                + "supplierID INTEGER,\n"
                + "productID INTEGER,\n"
                + "catalogNumber INTEGER NOT NULL,\n"
                + "name TEXT NOT NULL,\n"
                + "amount INTEGER NOT NULL,\n"
                + "price DOUBLE NOT NULL,\n"
                + "weight DOUBLE NOT NULL,\n"
                + "manufacturer TEXT NOT NULL,\n"
                + "expirationDays TEXT NOT NULL,\n"
                + "PRIMARY KEY(supplierID,productID),\n"
                + "FOREIGN KEY(supplierID) REFERENCES supplier(supplierID) ON UPDATE CASCADE ON DELETE CASCADE\n"
                + ");";

        String sql6 = "CREATE TABLE IF NOT EXISTS discountPerAmount (\n"
                + "supplierID INTEGER,\n"
                + "productID INTEGER,\n"
                + "discountPerAmount INTEGER NOT NULL,\n"
                + "discount DOUBLE NOT NULL,\n"
                + "PRIMARY KEY(supplierID,productID, discountPerAmount),\n"
                + "FOREIGN KEY(supplierID, productID) REFERENCES supplierProduct(supplierID, productID) ON UPDATE CASCADE ON DELETE CASCADE\n"
                + ");";
        String sql7 = "CREATE TABLE IF NOT EXISTS supplierOrder (\n"
                + "orderID INTEGER,\n"
                + "supplierID INTEGER NOT NULL,\n"
                + "supplierName TEXT NOT NULL,\n"
                + "supplierAddress TEXT NOT NULL,\n"
                + "contactPhoneNumber TEXT NOT NULL,\n"
                + "branchID INTEGER NOT NULL,\n"
                + "creationDate TEXT NOT NULL,\n"
                + "deliveryDate TEXT NOT NULL,\n"
                + "collected BOOLEAN NOT NULL,\n"
                + "totalPriceBeforeDiscount DOUBLE NOT NULL,\n"
                + "totalPriceAfterDiscount DOUBLE NOT NULL,\n"
                + "PRIMARY KEY(orderID),\n"
                + "FOREIGN KEY(supplierID) REFERENCES supplier(supplierID) ON UPDATE CASCADE\n"
                + ");";

        String sql8 = "CREATE TABLE IF NOT EXISTS productsInOrder (\n"
                + "orderID INTEGER,\n"
                + "supplierID INTEGER NOT NULL,\n"
                + "productID INTEGER NOT NULL,\n"
                + "amountInOrder INTEGER NOT NULL,\n"
                + "PRIMARY KEY(orderID, productID),\n"
                + "FOREIGN KEY(orderID) REFERENCES supplierOrder(orderID) ON UPDATE CASCADE ON DELETE CASCADE,\n"
                + "FOREIGN KEY(productID, supplierID) REFERENCES supplierProduct(productID, supplierID) ON UPDATE CASCADE\n"
                + ");";

        String sql9 = "CREATE TABLE IF NOT EXISTS periodicOrder (\n"
                + "periodicOrderID INTEGER,\n"
                + "supplierID INTEGER NOT NULL,\n"
                + "branchID INTEGER NOT NULL,\n"
                + "fixedDay TEXT NOT NULL,\n"
                + "PRIMARY KEY(periodicOrderID),\n"
                + "FOREIGN KEY(supplierID) REFERENCES supplier(supplierID) ON UPDATE CASCADE\n"
                + "-- FOREIGN KEY(branchID) REFERENCES branch(branchID) ON UPDATE CASCADE ON DELETE CASCADE\n"
                + ");";

        String sql10 = "CREATE TABLE IF NOT EXISTS productsInPeriodicOrder (\n"
                + "periodicOrderID INTEGER,\n"
                + "productID INTEGER NOT NULL,\n"
                + "supplierID INTEGER NOT NULL,\n"
                + "amountInOrder INTEGER NOT NULL,\n"
                + "PRIMARY KEY(periodicOrderID, productID),\n"
                + "FOREIGN KEY(periodicOrderID) REFERENCES periodicOrder(periodicOrderID) ON UPDATE CASCADE ON DELETE CASCADE,\n"
                + "FOREIGN KEY(productID, supplierID) REFERENCES supplierProduct(productID, supplierID) ON UPDATE CASCADE\n"
                + ");";
        String sql11 = "CREATE TABLE IF NOT EXISTS deliveryDays (\n"
                + "supplierID INTEGER,\n"
                + "day TEXT NOT NULL,\n"
                + "PRIMARY KEY(supplierID, day),\n"
                + "CONSTRAINT fk_deliveryDays FOREIGN KEY (supplierID) REFERENCES agreement(supplierID) ON DELETE CASCADE ON UPDATE CASCADE\n"
                + ");";
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql1);
            stmt.execute(sql2);
            stmt.execute(sql3);
            stmt.execute(sql4);
            stmt.execute(sql5);
            stmt.execute(sql6);
            stmt.execute(sql7);
            stmt.execute(sql8);
            stmt.execute(sql9);
            stmt.execute(sql10);
            stmt.execute(sql11);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

}