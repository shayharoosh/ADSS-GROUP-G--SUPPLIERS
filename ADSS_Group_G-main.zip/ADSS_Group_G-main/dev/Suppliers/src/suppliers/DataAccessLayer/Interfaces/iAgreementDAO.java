package suppliers.DataAccessLayer.Interfaces;

import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.Agreement;
import suppliers.DomainLayer.Classes.Product;

import java.util.Map;

public interface iAgreementDAO {
    Message addAgreement (int supplierID, Agreement agreement);
    Message addAgreementWithDiscount(int supplierID, Agreement agreement);
    Message removeAgreement (int supplierID);
    Message updateAgreement(int supplierID, String paymentType, boolean selfSupply, String supplyMethod, int supplyTime);
    Agreement getAgreementByID (int supplierID);
    Message addProducts(int supplierID, Map<Integer, Product> supplyingProducts);
    Message addDiscountsOnProducts(int supplierID, Map<Integer, Product> supplyingProducts);

}
