package suppliers.DataAccessLayer.Interfaces;

import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.ContactInformation;

import java.util.ArrayList;

public interface iContactInformationDAO {
    Message addContactInformation(int supplierID, ContactInformation contactInformation);
    Message removeContactInformation(int supplierID, String phoneNumber);
    ArrayList<ContactInformation> getContactsBySupplierID(int supplierID);
    ContactInformation getContactBySupplierID(int supplierID, String phoneNumber);

    Message updateName(int supplierID, String phoneNumber, String newName);
    Message updatePhoneNumber(int supplierID, String oldPhoneNumber,  String newPhoneNumber);
    Message updateEmail(int supplierID,  String phoneNumber, String email);

}
