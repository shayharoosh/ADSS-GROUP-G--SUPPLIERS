package suppliers.DataAccessLayer.Interfaces;

import suppliers.DataStructures.Message;

import java.time.DayOfWeek;
import java.util.ArrayList;

public interface iDeliveryDaysDAO {
    Message addDeliveryDays(int supplierID, ArrayList<DayOfWeek> days);
    Message removeDeliveryDays(int supplierID);
    Message updateDeliveryDays(int supplierID, ArrayList<DayOfWeek> days);
    ArrayList<DayOfWeek> getDeliveryDays(int id);

}
