package suppliers.DataAccessLayer.Interfaces;

import suppliers.DataStructures.Message;
import suppliers.DataStructures.Pair;

public interface iDiscountDAO {
    Message addDiscount(int supplierID, String type, Pair<? extends Number, Double> discount);
    Message removeDiscount(int supplierID, String type);
    Pair<Integer, Double> getAmountDiscountByID(int supplierID);
    Pair<Double, Double> getPriceDiscountByID(int supplierID);

}
