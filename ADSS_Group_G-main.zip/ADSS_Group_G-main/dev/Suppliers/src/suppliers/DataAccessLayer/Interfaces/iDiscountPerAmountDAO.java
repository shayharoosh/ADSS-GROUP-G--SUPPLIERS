package suppliers.DataAccessLayer.Interfaces;

import suppliers.DataStructures.Message;

import java.util.HashMap;

public interface iDiscountPerAmountDAO {
    Message addDiscountPerAmount (int supplierID, int productID, int discountPerAmount ,double discount);
    Message removeDiscountPerAmount (int supplierID, int productID, int discountPerAmount);
    HashMap<Integer, Double> getProductDiscountByID (int supplierID, int productID);
}
