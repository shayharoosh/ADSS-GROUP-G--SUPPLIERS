package suppliers.DataAccessLayer.Interfaces;

import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.Order;

import java.util.HashMap;

public interface iOrderDAO {
    Message addOrder(Order order);
    Message removeOrder(int orderID);
    Message markOrderAsCollected(int orderID);
    Order getOrderByID(int orderID);
    int getLastOrderID();
    HashMap<Integer, Order> getAllOrders();
    HashMap<Integer, Order> getOrdersFromSupplier(int supplierID);
    HashMap<Integer, Order> getOrdersToBranch(int branchID);
    HashMap<Integer, Order> getAllOrderForToday();
    HashMap<Integer, Order> getNoneCollectedOrdersForToday(int branchID);
}
