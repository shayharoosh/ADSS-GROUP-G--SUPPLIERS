package suppliers.DataAccessLayer.Interfaces;

import suppliers.DomainLayer.Classes.Product;
import suppliers.DataStructures.Message;

import java.util.ArrayList;
import java.util.HashMap;

public interface iProductDAO {
    Message addProduct(int supplierID, Product product);
    Message removeProduct(int supplierID, int productID);
    Message updateProducts(int supplierID, ArrayList<Product> products);
    Product getProduct(int supplierID, int productID);
    HashMap<Integer,Product> getAllProductsByID(int supplierID);
    Message updateCatalogID(int supplierID, int productID, int catalogID);
    Message updateAmount(int supplierID, int productID, int amount);
    void printProductsBySupplierID(int supplierID);



    /*
    Message updateProduct(int supplierID, Product product);
    void printProductsBySupplierID(int supplierID);
    Message updatePrice(int productID, double price);
    Message updateDiscount(int productID, int amount, double discount);
    Message updateManufacturer(int productID, String manufacturer);
    Message updateExpirationDays(int productID, int expirationDays);
    Message updateWeight(int productID, Double weight);
    Message updateSupplierID(int productID, int supplierID);
    */

}
