package suppliers.DataAccessLayer.Interfaces;

import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.Product;

import java.util.ArrayList;

public interface iProductsInOrderDAO {
    Message addProductsToOrder(int orderID, ArrayList<Product> productsInOrder);
    Message removeProductFromOrder(int orderID, int productID);
    Message updateProductAmountInOrder(int orderID, int productID, int amountInOrder);
    ArrayList<Product> getProductsInOrder(int orderID, int supplierID);
}
