package suppliers.DataAccessLayer.Interfaces;

import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.Product;

import java.util.ArrayList;

public interface iProductsInPeriodicOrderDAO{
    Message addProductsToPeriodicOrder(int orderID, ArrayList<Product> productsInOrder);
    Message removeProductFromPeriodicOrder(int orderID, int productID);
    ArrayList<Product> getProductsInPeriodicOrder(int orderID, int supplierID);

}
