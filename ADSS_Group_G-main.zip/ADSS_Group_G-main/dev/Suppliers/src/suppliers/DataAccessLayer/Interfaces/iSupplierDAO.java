package suppliers.DataAccessLayer.Interfaces;

import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.Product;
import suppliers.DomainLayer.Classes.Supplier;

import java.util.HashMap;
import java.util.Map;

public interface iSupplierDAO {
    Message addSupplier(Supplier supplier);
    Message removeSupplier(int supplierID);
    HashMap<Integer, Supplier> getAllSuppliers();
    Supplier getSupplierByID(int supplierID);
    Integer getActiveSupplierByID(int supplierID);
    void printAllSuppliers();
    Message getSupplierNameById(Integer supplierID);
    Message updateSupplierName(int supplierID, String newName);
    Message updateSupplierAddress(int supplierID, String newAddress);
    Message updateSupplierBankAccount(int supplierID, String newBankAccount);
    Message addProducts(int supplierID, Map<Integer, Product> supplyingProducts);
    Message addDiscountsOnProducts(int supplierID, Map<Integer, Product> supplyingProducts);
}
