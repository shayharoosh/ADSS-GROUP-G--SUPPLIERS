package suppliers.DataStructures;


import suppliers.DomainLayer.Classes.Supplier;
import suppliers.DomainLayer.Classes.Product;

import java.util.ArrayList;

public class Message {

    private String errorMessage;
    private int supplierId;
    private ArrayList<Supplier> suppliersInOrder;
    private ArrayList<ArrayList<Pair<Product,Integer>>> supplyLists;

    //Attributes added in part B
    private boolean answer;
    private String stringValue;

    public Message(ArrayList<Supplier> suppliersInOrder, ArrayList<ArrayList<Pair<Product,Integer>>> supplyLists){
        this.suppliersInOrder = suppliersInOrder;
        this.supplyLists = supplyLists;
    }

    public Message(int supplierId){
        this.supplierId = supplierId;
    }
    public Message(){};
    public Message(String errorMessage){
        this.errorMessage = errorMessage;
    }
    public Message(boolean answer, String name){
        this.answer = answer;
        this.stringValue = name;
    }

    public Message(boolean answer) { this.answer = answer; }

    public boolean errorOccurred(){return errorMessage != null;}
    public ArrayList<Supplier> getSuppliersInOrder(){return this.suppliersInOrder;}
    public ArrayList<ArrayList<Pair<Product,Integer>>> getSupplyLists(){return this.supplyLists;}
    public String getErrorMessage() {
        return errorMessage;
    }
    public int getSupplierId(){return supplierId;}
    public boolean getAnswer() { return answer; }
    public String getStringValue() { return stringValue; }
}
