package suppliers.DomainLayer.Classes;

import suppliers.DataStructures.Pair;

import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.HashMap;


public class Agreement {
    private String paymentType;
    private Pair<Integer, Double> totalAmountDiscountPerOrder;
    private Pair<Double, Double> totalPriceDiscountPerOrder;
    private boolean selfSupply;
    private ArrayList<DayOfWeek> supplyDays;
    private HashMap<Integer, Product> supplyingProducts;

    //added in part B
    private int supplyTime;
    private String supplyMethod;

    //Constructors

    //Constructor without products and discounts
    public Agreement(String paymentType, boolean selfSupply, String supplyMethod, int supplyTime, ArrayList<DayOfWeek> supplyDays,
                     HashMap <Integer, Product> supplyingProducts) {
        this.paymentType = paymentType;
        this.selfSupply = selfSupply;
        this.supplyMethod = supplyMethod;
        this.supplyTime = supplyTime;
        this.supplyDays = supplyDays;
        this.supplyingProducts = supplyingProducts;
    }

    //Constructor without discounts
    public Agreement(String paymentType, boolean selfSupply, String supplyMethod, int supplyTime, ArrayList<DayOfWeek> supplyDays) {
        this.paymentType = paymentType;
        this.selfSupply = selfSupply;
        this.supplyMethod = supplyMethod;
        this.supplyTime = supplyTime;
        this.supplyDays = supplyDays;
    }

    //Full constructor
    public Agreement(String paymentType, boolean selfSupply, String supplyMethod, int supplyTime, ArrayList<DayOfWeek> supplyDays, HashMap<Integer, Product> supplyingProducts,
                     Pair<Integer, Double> totalAmountDiscountPerOrder, Pair<Double, Double> totalPriceDiscountPerOrder) {
        this.paymentType = paymentType;
        this.selfSupply = selfSupply;
        this.supplyMethod = supplyMethod;
        this.supplyTime = supplyTime;
        this.supplyDays = supplyDays;
        this.supplyingProducts = supplyingProducts;
        this.totalAmountDiscountPerOrder = totalAmountDiscountPerOrder;
        this.totalPriceDiscountPerOrder = totalPriceDiscountPerOrder;
    }

    //Getters
    public HashMap<Integer, Product> getSupplyingProducts() {return supplyingProducts;}
    public boolean getSelfSupply() {return this.selfSupply;}
    public ArrayList<DayOfWeek> getSupplyDays() {return supplyDays;}
    public Pair<Double, Double> getTotalPriceDiscountPerOrder() {return totalPriceDiscountPerOrder;}
    public Pair<Integer, Double> getTotalAmountDiscountPerOrder() {return totalAmountDiscountPerOrder;}
    public String getPaymentType() {return paymentType;}
    public String getSupplyMethod() {return supplyMethod;}
    public int getSupplyTime() {return supplyTime;}


    //Setters
    public void setPaymentType(String paymentType) {this.paymentType = paymentType;}
    public void setSelfSupply(boolean selfSupply) {this.selfSupply = selfSupply;}
    public void setSupplyDays(ArrayList<DayOfWeek> supplyDays) {this.supplyDays = supplyDays;}
    public void setSupplyMethod(String supplyMethod) {this.supplyMethod = supplyMethod;}
    public void setSupplyTime(int supplyTime) {this.supplyTime = supplyTime;}
    public void setTotalPriceDiscountPerOrder(Pair<Double, Double> totalPriceDiscountPerOrder) {this.totalPriceDiscountPerOrder = totalPriceDiscountPerOrder;}
    public void setTotalAmountDiscountPerOrder(Pair<Integer, Double> totalAmountDiscountPerOrder) {this.totalAmountDiscountPerOrder = totalAmountDiscountPerOrder;}
    public void setSupplyingProducts(HashMap<Integer, Product> supplyingProducts) {this.supplyingProducts = supplyingProducts;}

}
