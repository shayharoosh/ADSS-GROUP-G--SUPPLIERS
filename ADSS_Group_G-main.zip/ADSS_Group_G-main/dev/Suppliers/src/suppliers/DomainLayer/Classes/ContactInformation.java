package suppliers.DomainLayer.Classes;

public class ContactInformation {
    private String name;
    private String phoneNumber;
    private String emailAddress;

    //Constructors
    public ContactInformation(String name, String phoneNumber, String emailAddress) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
    }

    //Getters
    public String getName() {
        return name;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public String getEmailAddress() {return emailAddress;}
    public Object getEmail() {return emailAddress;}

    //Setters
    public void setName(String name) {
        this.name = name;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public void setEmailAddress(String newEmail) {
        this.emailAddress = newEmail;
    }
}
