package suppliers.DomainLayer.Classes;

import java.util.ArrayList;
import java.time.LocalDate;

public class Order
{
    private String supplierName;
    private String supplierAddress;
    private int supplierId;
    private int orderID;
    private int branchID;
    private boolean IsCollected;
    private String contactPhoneNumber;
    private final LocalDate creationDate;
    private final LocalDate deliveryDate;
    private ArrayList<Product> productsInOrder;
    private double totalPriceBeforeDiscount;
    private double totalPriceAfterDiscount;


    //Constructors
    public Order(int orderID, String supplierName, String supplierAddress, int supplierId ,String contactPhoneNumber, ArrayList<Product> productsInOrder, double totalPriceBeforeDiscount, double totalPriceAfterDiscount, LocalDate deliveryDate, int branchID) {
        this.orderID = orderID;
        this.supplierName = supplierName;
        this.supplierAddress = supplierAddress;
        this.supplierId = supplierId;
        this.contactPhoneNumber = contactPhoneNumber;
        this.creationDate = LocalDate.now();
        this.productsInOrder = productsInOrder;
        this.totalPriceBeforeDiscount = totalPriceBeforeDiscount;
        this.totalPriceAfterDiscount = totalPriceAfterDiscount;
        this.deliveryDate = deliveryDate;
        this.IsCollected = false;
        this.branchID = branchID;
    }

    public Order(int orderID, int supplierID, String supplierName, String supplierAddress, String contactPhoneNumber, int branchID, LocalDate creationDate, LocalDate deliveryDate, boolean collected, double totalPriceBeforeDiscount, double totalPriceAfterDiscount) {
        this.orderID = orderID;
        this.supplierId = supplierID;
        this.supplierName = supplierName;
        this.supplierAddress = supplierAddress;
        this.contactPhoneNumber = contactPhoneNumber;
        this.branchID = branchID;
        this.creationDate = creationDate;
        this.deliveryDate = deliveryDate;
        this.IsCollected = collected;
        this.totalPriceBeforeDiscount = totalPriceBeforeDiscount;
        this.totalPriceAfterDiscount = totalPriceAfterDiscount;
    }

    public Order(Order other, ArrayList<Product> productsInOrder, double priceBeforeDiscount, double priceAfterDiscount) {
        this.supplierName = other.supplierName;
        this.supplierAddress = other.supplierAddress;
        this.supplierId = other.supplierId;
        this.orderID = other.orderID;
        this.branchID = other.branchID;
        this.IsCollected = other.IsCollected;
        this.contactPhoneNumber = other.contactPhoneNumber;
        this.creationDate = other.creationDate;
        this.deliveryDate = other.deliveryDate;
        this.productsInOrder = productsInOrder;
        this.totalPriceBeforeDiscount = priceBeforeDiscount;
        this.totalPriceAfterDiscount = priceAfterDiscount;
    }


    //Getters
    public String getSupplierName() {return supplierName;}
    public String getSupplierAddress() {return supplierAddress;}
    public int getSupplierId() {return supplierId;}
    public int getOrderID() {return orderID;}
    public void setOrderID(int orderID) {this.orderID = orderID;}
    public String getContactPhoneNumber() {return contactPhoneNumber;}
    public ArrayList<Product> getProductsInOrder() {return productsInOrder;}
    public double getTotalPriceBeforeDiscount() {return totalPriceBeforeDiscount;}
    public double getTotalPriceAfterDiscount() {return totalPriceAfterDiscount;}
    public LocalDate getCreationDate() {return creationDate;}
    public LocalDate getDeliveryDate() {return deliveryDate;}
    public int getBranchID() {return branchID;}
    public boolean getCollected() {return IsCollected;}



    //Setters
    public void setContactPhoneNumber(String contactPhoneNumber) {this.contactPhoneNumber = contactPhoneNumber;}
    public void setSupplierId(int supplierId) {this.supplierId = supplierId;}
    public void setSupplierName(String supplierName) {this.supplierName = supplierName;}
    public void setSupplierAddress(String supplierAddress) {this.supplierAddress = supplierAddress;}
    public void setProductsInOrder(ArrayList<Product> productsInOrder) {this.productsInOrder = productsInOrder;}
    public void setTotalPriceBeforeDiscount(double totalPriceBeforeDiscount) {this.totalPriceBeforeDiscount = totalPriceBeforeDiscount;}
    public void setTotalPriceAfterDiscount(double totalPriceAfterDiscount) {this.totalPriceAfterDiscount = totalPriceAfterDiscount;}
    public void setCollected(boolean collected) {IsCollected = collected;}
    public void setBranchID(int branchID) {this.branchID = branchID;}

    //Helper functions
    @Override
    public String toString(){
        StringBuilder str = new StringBuilder();
        str.append("Order Details:\n");
        str.append("OrderID: ").append(orderID).append(", branchID: ").append(branchID).append(", creation date: ").append(creationDate).append(", delivery date: ").append(deliveryDate).append("\n");
        str.append("Supplier Details:\n");
        str.append("Name: ").append(supplierName).append(", Address: ").append(supplierAddress).append(", ID: ").append(supplierId).append(", Contact: ").append(contactPhoneNumber).append("\n");
        str.append("Products:\n");

        for(Product p : productsInOrder){
            int productId = p.getProductID();
            String productName = p.getName();
            int amount = p.getAmount();
            double productPrice = p.getPrice();
            str.append("ProductID: ").append(productId).append(", Name: ").append(productName).append(", Amount: ").append(amount).append(", Price: ").append(productPrice).append("\n");
        }
        str.append("Total Price Before Discount: ").append(totalPriceBeforeDiscount).append("\n");
        str.append("Total Price After Discount: ").append(totalPriceAfterDiscount).append("\n");

        return str.toString();
    }

}