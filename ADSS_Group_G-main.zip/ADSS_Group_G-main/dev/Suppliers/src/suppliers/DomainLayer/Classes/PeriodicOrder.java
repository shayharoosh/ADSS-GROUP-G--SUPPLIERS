package suppliers.DomainLayer.Classes;

import java.time.DayOfWeek;
import java.util.ArrayList;

public class PeriodicOrder {
    private int periodicOrderID;
    private int supplierID;
    private DayOfWeek fixedDay;
    private int branchID;
    private ArrayList<Product> productsInOrder;

    //Constructors
    public PeriodicOrder(int periodicOrderID, int supplierID, int branchID, DayOfWeek fixedDay, ArrayList<Product> productsInOrder) {
        this.periodicOrderID = periodicOrderID;
        this.supplierID = supplierID;
        this.fixedDay = fixedDay;
        this.branchID = branchID;
        this.productsInOrder = productsInOrder;
    }

    public PeriodicOrder(PeriodicOrder periodicOrder, ArrayList<Product> productsInOrder) {
        this.periodicOrderID = periodicOrder.getPeriodicOrderID();
        this.supplierID = periodicOrder.getSupplierID();
        this.fixedDay = periodicOrder.getFixedDay();
        this.productsInOrder = productsInOrder;
    }

    //Getters
    public int getPeriodicOrderID() {return periodicOrderID;}
    public int getSupplierID() {return supplierID;}
    public DayOfWeek getFixedDay() {return fixedDay;}
    public ArrayList<Product> getProductsInOrder() {return productsInOrder;}
    public int getBranchID() {return branchID;}

    //Setters
    public void setPeriodicOrderID(int periodicOrderID) {this.periodicOrderID = periodicOrderID;}
    public void setSupplierID(int supplierID) {this.supplierID = supplierID;}
    public void setFixedDay(DayOfWeek fixedDay) {this.fixedDay = fixedDay;}
    public void setProductsInOrder(ArrayList<Product> productsInOrder) {this.productsInOrder = productsInOrder;}
    public void setBranchID(int branchID) {this.branchID = branchID;}

    @Override
    public String toString(){
        StringBuilder str = new StringBuilder();
        str.append("Periodic Order Details:\n");
        str.append("Periodic Order ID: ").append(periodicOrderID).append(", Supplier ID: ").append(supplierID).append(", Branch ID: ").append(branchID).append(", Fixed Day: ").append(fixedDay).append("\n");

        for(Product p : productsInOrder){
            int productId = p.getProductID();
            String productName = p.getName();
            int amount = p.getAmount();
            double productPrice = p.getPrice();
            str.append(" - ProductID: ").append(productId).append(", Name: ").append(productName).append(", Amount: ").append(amount).append(", Price: ").append(productPrice).append("\n");
        }

        return str.toString();
    }
}
