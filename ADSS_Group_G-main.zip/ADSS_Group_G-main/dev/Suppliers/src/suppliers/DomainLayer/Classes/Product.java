package suppliers.DomainLayer.Classes;

import java.util.HashMap;
import java.util.Objects;

public class Product
{
    private String name;
    private int catalogID;
    private int productID;
    private double price;
    private HashMap<Integer, Double> discountPerAmount;
    private int amount;

    //attributes added in part b
    private String manufacturer;
    private int expirationDays;
    private Double weight;
    private int supplierID;

    public Product(String name, int productID, int catalogID, double price, int amount, HashMap<Integer, Double> discountPerAmount) {
        this.name = name;
        this.productID = productID;
        this.catalogID = catalogID;
        this.price = price;
        this.amount = amount;
        this.discountPerAmount = discountPerAmount;
    }

    public Product(String name, int supplierID, int productID, int catalogID, double price, int amount, HashMap<Integer, Double> discountPerAmount, String manufacturer, int expirationDays, Double weight) {
        this.name = name;
        this.supplierID = supplierID;
        this.productID = productID;
        this.catalogID = catalogID;
        this.price = price;
        this.manufacturer = manufacturer;
        this.expirationDays = expirationDays;
        this.weight = weight;
        this.discountPerAmount = discountPerAmount;
        this.amount = amount;
    }

    public Product(Product product)
    {
        this.name = product.name;
        this.supplierID = product.supplierID;
        this.catalogID = product.catalogID;
        this.productID = product.productID;
        this.price = product.price;
        this.manufacturer = product.manufacturer;
        this.expirationDays = product.expirationDays;
        this.weight = product.weight;
        this.discountPerAmount = product.discountPerAmount;
        this.amount = product.amount;
    }

    public Product(){
    }

    public Product(int productId, int supplierId, int catalogNumber) {
        this.productID = productId;
        this.supplierID = supplierId;
        this.catalogID = catalogNumber;
    }

    //Getters
    public int getProductID() {
        return productID;
    }
    public HashMap<Integer, Double> getDiscountPerAmount(){
        return discountPerAmount;
    }
    public String getName() {
        return name;
    }
    public int getCatalogID() {
        return catalogID;
    }
    public int getAmount() {
        return amount;
    }
    public double getPrice() {
        return price;
    }
    public String getManufacturer() {return manufacturer;}
    public int getExpirationDays() {return expirationDays;}
    public Double getWeight() {return weight;}
    public int getSupplierID() {return supplierID;}


    //Setters
    public void setAmount(int amount) {
        this.amount= amount;
    }
    public void setCatalogID(int newCatalogNumber){
        this.catalogID=newCatalogNumber;
    }
    public void setPrice(double price) {this.price = price;}
    public void setName(String name) {this.name = name;}
    public void setProductID(int productID) {this.productID = productID;}
    public void setDiscountPerAmount(HashMap<Integer, Double> discountPerAmount) {
        this.discountPerAmount = discountPerAmount;
    }
    public void setManufacturer(String manufacturer) {this.manufacturer = manufacturer;}
    public void setExpirationDays(int expirationDays) {this.expirationDays = expirationDays;}
    public void setWeight(Double weight) {this.weight = weight;}
    public void setSupplierID(int supplierID) {this.supplierID = supplierID;}

    //Helper functions
    public void addDiscount(int amount, double discount){
        discountPerAmount.put(amount, discount);
        System.out.println(discountPerAmount.get(amount));
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if(!(obj instanceof Product)) return false;
        Product product = (Product) obj;
        return productID == product.productID;
    }

    @Override
    public int hashCode() {return Objects.hash(productID);}

    public void removeDiscount(int amount){discountPerAmount.remove(amount);}

}