package suppliers.DomainLayer.Classes;

import suppliers.DataStructures.Pair;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Supplier {
    private int supplierId;
    private String name;
    private String address;
    private ArrayList<ContactInformation> contacts;
    private String bankAccount;
    private ArrayList<String> manufacturers;
    private ArrayList<String> domains;
    private Agreement agreement;
    private boolean isActive;


    public Supplier(int supplierId, String name, String bankAccount, String address, ArrayList<String> manufacturers, ArrayList<String> domains, Agreement agreement, HashMap<Integer, Integer> productsAmount) {
        this.supplierId = supplierId;
        this.name = name;
        this.contacts = new ArrayList<>();
        this.bankAccount = bankAccount;
        this.address = address;
        this.manufacturers = manufacturers;
        this.domains = domains;
        this.agreement = agreement;
    }

    public Supplier(int supplierId, String name, String bankAccount, String address, Agreement agreement) {
        this.supplierId = supplierId;
        this.name = name;
        this.bankAccount = bankAccount;
        this.address = address;
        this.agreement = agreement;
    }


    public Supplier(int supplierId, String name, String address, String bankAccount) {
        this.supplierId = supplierId;
        this.name = name;
        this.address = address;
        this.bankAccount = bankAccount;
        this.agreement = null;
        contacts = new ArrayList<>();
    }

    public Supplier(int supplierId, String name, String address, ArrayList<ContactInformation> contacts, String bankAccount, Agreement agreement) {
        this.supplierId = supplierId;
        this.name = name;
        this.address = address;
        this.contacts = contacts;
        this.bankAccount = bankAccount;
        this.agreement = agreement;
    }

    //Getters
    public int getSupplierId() {
        return supplierId;
    }
    public String getName() {
        return name;
    }
    public String getBankAccount() {
        return bankAccount;
    }
    public String getAddress() {
        return address;
    }
    public ArrayList<String> getManufacturers() {
        return manufacturers;
    }
    public Agreement getAgreement() {
        return agreement;
    }
    public ArrayList<String> getDomains() {
        return domains;
    }
    public ArrayList<ContactInformation> getContacts() {return contacts;}
    public boolean isActive() {return isActive;}



    //Setters
    public void setName(String newName) {
        name = newName;
    }
    public void setContacts(ArrayList<ContactInformation> contactsList) {
        this.contacts = contactsList;
    }
    public void setBankAccount(String newBankAccount) {
        bankAccount = newBankAccount;
    }
    public void setNewManufacturers(ArrayList<String> manufacturers) {
        this.manufacturers = manufacturers;
    }
    public void setNewAgreement(Agreement agreement) {this.agreement = agreement;}
    public void setAddress(String address) {
        this.address = address;
    }
    public void setNewDomains(ArrayList<String> domain) {
        this.domains = domain;
    }
    public void setSelfSupply(boolean selfSupply) {
        this.agreement.setSelfSupply(selfSupply);
    }
    public void SetPaymentType(String paymentType) {
        this.agreement.setPaymentType(paymentType);
    }
    public void setDeliveryDays(ArrayList<DayOfWeek> days) {agreement.setSupplyDays(days);}
    public void setProductCatalogNumber(int productId, int newCatalogNumber) {
        agreement.getSupplyingProducts().get(productId).setCatalogID(newCatalogNumber);
    }
    public void setSupplyTime(int supplyTime) {this.agreement.setSupplyTime(supplyTime);}
    public void setSupplyMethod(String supplyMethod) {this.agreement.setSupplyMethod(supplyMethod);}



    //Helper functions
    public ContactInformation addContactInformation(String name, String phone, String email) {
        ContactInformation ci = new ContactInformation(name, phone, email);
        contacts.add(ci);
        return ci;
    }
    public Product addProduct(String name, int supplierId, int productId, int catalogNumber, double price, int amount, HashMap<Integer, Double> discountPerAmount, double weight, String manufacturer, int expirationDays) {
        Product product = new Product(name, supplierId, productId, catalogNumber, price, amount, discountPerAmount, manufacturer, expirationDays, weight);
        agreement.getSupplyingProducts().put(productId, product);
        return product;
    }

    public void removeProduct(int productId) {
        agreement.getSupplyingProducts().remove(productId);
    }

    public Map<Integer, Product> getSupplyingProducts() {return agreement.getSupplyingProducts();}

    public ArrayList<Pair<Integer, Integer>> getItemsToCreateOrder(HashMap<Integer, Integer> productsToOrder) {
        ArrayList<Pair<Integer, Integer>> itemsToCreateOrder = new ArrayList<>();
        Map<Integer, Product> supplyingProducts = getSupplyingProducts();

        for (Map.Entry<Integer, Integer> entry : productsToOrder.entrySet()) {

            if (supplyingProducts.containsKey(entry.getKey())) {
                int amount = supplyingProducts.get(entry.getKey()).getAmount();
                if (amount - entry.getValue() >= 0) {
                    itemsToCreateOrder.add(new Pair<>(entry.getKey(), entry.getValue()));
                } else {
                    itemsToCreateOrder.add(new Pair<>(entry.getKey(), amount));
                }
            }
        }
        return itemsToCreateOrder;
    }


    public double calculatePriceAfterDiscount (ArrayList<Pair<Integer,Integer>> products) {
        double totalPriceForAllOrder = 0.0;
        for (Pair<Integer, Integer> pair : products) {
            double totalPrice=0.0;
            int productId = pair.getKey();
            int amountForDiscount = pair.getValue();
            boolean canUseAdiscount = false;
            Product product = agreement.getSupplyingProducts().get(productId);
            double productPrice = product.getPrice();
            HashMap<Integer, Double> productDiscounts = product.getDiscountPerAmount();
            for (Map.Entry<Integer, Double> entry : productDiscounts.entrySet()) {
                if (entry.getKey() <= pair.getValue()) {
                    canUseAdiscount = true;
                    amountForDiscount = entry.getKey();
                } else {
                    break;
                }
            }
            if (canUseAdiscount) {
                double priceAfterDiscount = ((100 - productDiscounts.get(amountForDiscount)) * amountForDiscount * productPrice) / 100;
                totalPrice = (pair.getValue() - amountForDiscount) * productPrice + priceAfterDiscount;
            } else {
                totalPrice = (pair.getValue()) * productPrice;
            }
            totalPriceForAllOrder+=totalPrice;
        }
        return totalPriceForAllOrder;
    }

    public double calculatePriceAfterDiscountNew (ArrayList<Product> products) {
        double totalPriceForAllOrder = 0.0;
        for (Product supplierProduct : products) {
            double totalPrice;
            int productId = supplierProduct.getProductID();
            int amountForDiscount = supplierProduct.getAmount();
            boolean canUseAdiscount = false;
            double productPrice = supplierProduct.getPrice();
            HashMap<Integer, Double> productDiscounts = supplierProduct.getDiscountPerAmount();
            for (Map.Entry<Integer, Double> entry : productDiscounts.entrySet()) {
                if (entry.getKey() <= amountForDiscount) {
                    canUseAdiscount = true;
                    amountForDiscount = entry.getKey();
                } else {
                    break;
                }
            }
            if (canUseAdiscount) {
                double priceAfterDiscount = ((100 - productDiscounts.get(amountForDiscount)) * amountForDiscount * productPrice) / 100;
                totalPrice = (supplierProduct.getAmount() - amountForDiscount) * productPrice + priceAfterDiscount;
            } else {
                totalPrice = (supplierProduct.getAmount()) * productPrice;
            }
            totalPriceForAllOrder+=totalPrice;
        }
        return totalPriceForAllOrder;
    }

    public Product getProductById (int productId){
        return getSupplyingProducts().get(productId);
    }

    public double calculatePriceBeforeDiscount (ArrayList<Pair<Integer,Integer>> products) {
        double totalPriceForAllOrder = 0.0;
        for (Pair<Integer, Integer> pair : products) {
            int productId = pair.getKey();
            int amountToOrder = pair.getValue();
            Product product = agreement.getSupplyingProducts().get(productId);
            double productPrice = product.getPrice();
            totalPriceForAllOrder+=amountToOrder*productPrice;
        }
        return totalPriceForAllOrder;
    }

    public double calculatePriceBeforeDiscountNew (ArrayList<Product> products) {
        double totalPriceForAllOrder = 0.0;
        for (Product supplierProduct : products) {
            int amountToOrder = supplierProduct.getAmount();
            double productPrice = supplierProduct.getPrice();
            totalPriceForAllOrder+=amountToOrder*productPrice;
        }
        return totalPriceForAllOrder;
    }
    public Pair<Double,Double> getTotalPriceDiscountPerOrder(){return agreement.getTotalPriceDiscountPerOrder();}
    public Pair<Integer,Double> getTotalAmountDiscountPerOrder(){
        return agreement.getTotalAmountDiscountPerOrder();
    }

    public int getTotalAmount (ArrayList<Pair<Integer,Integer>> products) {
        int totalAmount=0;
        for (Pair<Integer,Integer> p:products){
            totalAmount+=p.getValue();
        }
        return totalAmount;
    }

    public int getTotalAmountNew (ArrayList<Product> products) {
        int totalAmount=0;
        for (Product supplierProduct : products)
            totalAmount += supplierProduct.getAmount();
        return totalAmount;
    }

    public int getMinimum(ArrayList<Integer> numbers) {
        int min = Integer.MAX_VALUE;
        for (int number : numbers) {
            if (number < min) {
                min = number;
            }
        }
        return min;
    }

    public int getSupplierClosestDaysToDelivery(){
        ArrayList<Integer> daysInInt = new ArrayList<>();
        Agreement a1 = getAgreement();
        if(a1.getSupplyDays() != null  && a1.getSupplyDays().size() > 0){
            for(DayOfWeek date: a1.getSupplyDays()){
                if(date.getValue() - LocalDate.EPOCH.getDayOfMonth() > 0){
                    daysInInt.add(date.getValue() - LocalDate.EPOCH.getDayOfMonth());
                }
                else {
                    daysInInt.add((LocalDate.EPOCH.getDayOfMonth() + 7) - date.getValue());
                }
            }
            return getMinimum(daysInInt);
        }
        return a1.getSupplyTime();
    }

    public int getAmountByProduct(int productId) {
        return getSupplyingProducts().get(productId).getAmount();
    }

    public String getContactPhoneNumber() {
        if (contacts.size() > 0) {
            return contacts.get(0).getPhoneNumber();
        }
        return null;
    }

    public double calculatePricePerProduct(int productId, int amountToOrder){
        Pair<Integer, Integer> productAndAmount = new Pair<>(productId, amountToOrder);
        ArrayList<Pair<Integer, Integer>> toCalculate = new ArrayList<>();
        toCalculate.add(productAndAmount);

        return calculatePriceAfterDiscount(toCalculate);
    }


}