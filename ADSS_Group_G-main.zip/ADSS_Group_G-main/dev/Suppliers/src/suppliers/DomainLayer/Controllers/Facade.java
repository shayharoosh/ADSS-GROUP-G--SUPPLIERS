package suppliers.DomainLayer.Controllers;

import suppliers.DataAccessLayer.Classes.AgreementDAO;
import suppliers.DomainLayer.Classes.*;
import suppliers.ServiceLayer.AgreementService;
import suppliers.ServiceLayer.ContactInformationService;
import suppliers.DataStructures.Message;
import java.time.DayOfWeek;

import java.util.ArrayList;
import java.util.HashMap;

public class Facade {
    private SupplierController supplierController;
    private ProductController productController;
    private OrderController orderController;
    private final PeriodicOrderController periodicOrderController;
    private final AgreementDAO agreementDAO;

    public Facade(){
        supplierController = new SupplierController();
        productController = new ProductController();
        orderController = new OrderController();
        periodicOrderController = new PeriodicOrderController();
        agreementDAO = new AgreementDAO();
    }
    public Message addSupplier(String name, String address, String bankAccount, AgreementService serviceAgreement,  ArrayList<ContactInformationService> contactList) {
        Message mes = supplierController.addSupplier(name, address, bankAccount);
        if (!mes.errorOccurred()) {
            int supplierId = mes.getSupplierId();
            HashMap<Integer, Product> supplyingProducts1 = productController.createSupplyingProducts(serviceAgreement.getSupplyingProducts(), supplierId);
            if(serviceAgreement.getTotalAmountDiscountPerOrder()!=null && serviceAgreement.getTotalPriceDiscountPerOrder()!=null){
                Agreement agreement1 = supplierController.createAgreementWithDiscounts(serviceAgreement.getPaymentType(), serviceAgreement.getSelfSupply(), serviceAgreement.getSupplyDays(), supplyingProducts1, serviceAgreement.getSupplyMethod(), serviceAgreement.getSupplyTime() ,serviceAgreement.getTotalAmountDiscountPerOrder(), serviceAgreement.getTotalPriceDiscountPerOrder());
                supplierController.setAgreement(agreement1, supplierId);
                agreementDAO.addAgreementWithDiscount(supplierId,agreement1);
            }
            else {
                Agreement agreement1 = supplierController.createAgreement(serviceAgreement.getPaymentType(), serviceAgreement.getSelfSupply(), serviceAgreement.getSupplyDays(), supplyingProducts1, serviceAgreement.getSupplyMethod(), serviceAgreement.getSupplyTime());
                supplierController.setAgreement(agreement1, supplierId);
                agreementDAO.addAgreement(supplierId,agreement1);
            }
            supplierController.setContacts(contactList, supplierId);

        }
        return mes;
    }


    public Message removeSupplier(int id) {
        Message res1 = supplierController.removeSupplier(id);
        if(!res1.errorOccurred()){
            Message res2 = productController.removeSupplierProducts(id);
            if(res2.getErrorMessage()!= null && res2.getErrorMessage().equals("The user doesn't have any products yet")){
                return new Message("The user with id: " + id + " deleted successfully and he doesn't have any products");
            }
            return res1;
        }
        return res1;
    }

    public Message changeAddress(int id, String address) {
        return supplierController.changeAddress(id, address);
    }

    public Message changeSupplierBankAccount(int id, String bankAccount) {
        return supplierController.changeSupplierBankAccount(id, bankAccount);
    }

    public Message changeSupplierName(int id, String name) {
        return supplierController.changeSupplierName(id, name);
    }

    public Message addContactsTOSupplier(int id, String name, String email, String phone) {
        return supplierController.addContactsTOSupplier(id, name, email, phone);
    }

    public Message removeSupplierContact(int id, String phone) {
        return supplierController.removeSupplierContact(id, phone);
    }

    public Message editSupplierContacts(int id, String email, String newEmail, String newPhone, String oldPhone) {
        return supplierController.editSupplierContacts(id, email, newEmail, newPhone, oldPhone);
    }

    public Message addItemToAgreement(int supplierID, String name, int productId, int catalogNumber, double price, int amount,  HashMap<Integer, Double> discountPerAmount, double weight, String manufacturer, int expirationDays) {
        Message message = supplierController.addItemToAgreement(supplierID, name,  productId, catalogNumber, price, amount, discountPerAmount, weight, manufacturer, expirationDays);
        if (!message.errorOccurred()){
            productController.addProductToSupplier(supplierID, name, productId, catalogNumber, price, discountPerAmount);
        }
        return message;
    }

    public Message removeItemFromAgreement(int supplierID, int itemIdToDelete) {
        Message message = supplierController.removeItemFromAgreement(supplierID, itemIdToDelete);
        if (!message.errorOccurred()){
            return productController.removeProductFromSupplier(supplierID, itemIdToDelete);
        }
        return message;
    }

    public Message editPaymentMethodAndDeliveryMethodAndDeliveryDays(int supplierId, boolean selfSupply, String paymentMethod, ArrayList<DayOfWeek> days, String supplyMethod, int supplyTime) {
        return supplierController.editPaymentMethodAndDeliveryMethodAndDeliveryDays(supplierId, selfSupply, paymentMethod, days, supplyMethod, supplyTime);
    }

    public Message editItemCatalogNumber(int supplierId, int productId, int newCatalogNumber) {
        Message res = supplierController.editItemCatalogNumber(supplierId, productId, newCatalogNumber);
        if(!res.errorOccurred()){
            productController.editItemCatalogNumber(supplierId, productId, newCatalogNumber);
        }
        return res;
    }

    public void printSuppliers() {
        supplierController.printSuppliers();
    }

    public Message addDiscounts(int supplierId, int productId, int amount, double discount) {
        return supplierController.addDiscount(supplierId, productId, amount, discount);
    }

    public Message removeDiscounts(int supplierId, int productId, int amount, double discount) {
        return supplierController.removeDiscount(supplierId, productId, amount, discount);
    }

    public Message createOrderByShortage(int branchId, HashMap<Integer, Integer> shortage) {
        ArrayList<ArrayList<Supplier>> orderSuppliers = supplierController.findFastestSuppliers(shortage);
        Message message = orderController.createOrderByShortage(orderSuppliers, branchId, shortage);
        return message;
    }

    public Message createPeriodicOrder(int supplierID, int branchID, DayOfWeek fixedDay, HashMap<Integer, Integer> productsAndAmount) {
        return periodicOrderController.createPeriodicOrder(supplierID, branchID, fixedDay, productsAndAmount);
    }

    public HashMap<Integer, PeriodicOrder> getAllPeriodicOrders() { return periodicOrderController.getAllPeriodicOrderForToday(); }
    public void printOrder(int supplierID) {orderController.printOrder(supplierID);}
    public void printOrders() {orderController.printOrders();}
    public void printPeriodicOrders() {periodicOrderController.printPeriodicOrders();}

    public boolean isProductExists(int productId) {
        return productController.isProductExists(productId);
    }

    public Message updateProductsInOrder(int orderID, HashMap<Integer, Integer> productsToAdd) { return orderController.updateProductsInOrder(orderID, productsToAdd); }
    public Message removeProductsFromOrder(int orderID, ArrayList<Integer> productsToRemove) { return orderController.removeProductsFromOrder(orderID, productsToRemove); }
    public Message executePeriodicOrder(int periodicOrderID) {return orderController.executePeriodicOrder(periodicOrderID);}

    public HashMap<Integer, Order> getNoneCollectedOrdersForToday(int branchID) { return orderController.getNoneCollectedOrdersForToday(branchID); }
    public HashMap<Integer, Order> getOrdersFromSupplier(int supplierID) { return orderController.getOrdersFromSupplier(supplierID); }
    public HashMap<Integer, Order> getOrdersToBranch(int branchID) { return orderController.getOrdersToBranch(branchID); }
    public HashMap<Integer, Order> getAllOrderForToday() { return orderController.getAllOrderForToday(); }
    public Message markOrderAsCollected(int orderID) { return orderController.markOrderAsCollected(orderID); }

    public Order getOrderByID(int orderID) { return orderController.getOrderByID(orderID); }

    public HashMap<Integer, PeriodicOrder> getAllPeriodicOrderForToday() { return periodicOrderController.getAllPeriodicOrderForToday(); }


}
