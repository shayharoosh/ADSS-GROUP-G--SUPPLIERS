package suppliers.DomainLayer.Controllers;

import suppliers.DataStructures.Pair;
import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.Order;
import suppliers.DomainLayer.Classes.PeriodicOrder;
import suppliers.DomainLayer.Classes.Product;
import suppliers.DomainLayer.Classes.Supplier;
import suppliers.DataAccessLayer.Classes.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;


public class OrderController {
    private final OrderDAO orderDAO;
    private final PeriodicOrderDAO periodicOrderDAO;
    private final ProductDAO productDAO;
    private final SupplierDAO supplierDAO;
    private static int id;

    public OrderController() {
        orderDAO = new OrderDAO();
        periodicOrderDAO = new PeriodicOrderDAO();
        productDAO = new ProductDAO();
        supplierDAO = new SupplierDAO();
        id = orderDAO.getLastOrderID() + 1;
    }

    public HashMap<Supplier, ArrayList<Pair<Integer, Integer>>> createOrderList (ArrayList<ArrayList<Supplier>> sortedSuppliers, HashMap<Integer, Integer> shortage){
        int i = 0;
        HashMap<Supplier, ArrayList<Pair<Integer, Integer>>> orderList = new HashMap<>();
        for (Map.Entry<Integer, Integer> entry : shortage.entrySet()) {
            int amountToSupply = entry.getValue();
            int productId = entry.getKey();
            for (int j = 0; j < sortedSuppliers.get(i).size(); j++) {
                if (amountToSupply > 0) {
                    int supplierAmount = sortedSuppliers.get(i).get(j).getAmountByProduct(productId);
                    if (amountToSupply <= supplierAmount) {
                        Pair<Integer, Integer> pair = new Pair<>(productId, amountToSupply);
                        if (orderList.containsKey(sortedSuppliers.get(i).get(j))) {
                            orderList.get(sortedSuppliers.get(i).get(j)).add(pair);
                        }
                        else {
                            ArrayList<Pair<Integer, Integer>> list = new ArrayList<>();
                            list.add(pair);
                            orderList.put(sortedSuppliers.get(i).get(j), list);
                        }
                        break;
                    }
                    else //(amountToSupply > supplierAmount)
                    {
                        amountToSupply = amountToSupply - supplierAmount;
                        Pair<Integer, Integer> pair2 = new Pair<>(productId, supplierAmount);
                        if (orderList.containsKey(sortedSuppliers.get(i).get(j))) {
                            orderList.get(sortedSuppliers.get(i).get(j)).add(pair2);
                        } else {
                            ArrayList<Pair<Integer, Integer>> list2 = new ArrayList<>();
                            list2.add(pair2);
                            orderList.put(sortedSuppliers.get(i).get(j), list2);
                        }
                    }
                }
            }
            if(i < sortedSuppliers.size()){
                i++;
            }
        }
        return orderList;
    }

    public Message createOrderByShortage(ArrayList<ArrayList<Supplier>> sortedSuppliers, int branchId, HashMap<Integer, Integer> shortage) {
        if(sortedSuppliers.isEmpty()){
            return new Message("order creation was failed");
        }
        HashMap<Supplier, ArrayList<Pair<Integer, Integer>>> orderList = createOrderList(sortedSuppliers,shortage);
        for (Map.Entry<Supplier, ArrayList<Pair<Integer, Integer>>> entry : orderList.entrySet()) {
            Supplier supplierToOrder = entry.getKey();
            ArrayList<Pair<Integer, Integer>> suppliersProduct = entry.getValue();
            int supplierId = supplierToOrder.getSupplierId();
            String supplierName = supplierToOrder.getName();
            String supplierAddress = supplierToOrder.getAddress();
            String contactPhoneNumber = supplierToOrder.getContactPhoneNumber();
            ArrayList<Product> productsToOrder = new ArrayList<>();

            for (Pair<Integer, Integer> integerIntegerPair : suppliersProduct) {
                int productId = integerIntegerPair.getKey();
                int amountToOrder = integerIntegerPair.getValue();

                Product product = new Product(supplierToOrder.getProductById(productId));
                product.setAmount(amountToOrder);
                productsToOrder.add(product);
            }
            double priceAfterDiscount = supplierToOrder.calculatePriceAfterDiscount(suppliersProduct);
            int totalAmountToOrder = supplierToOrder.getTotalAmount(suppliersProduct);
            if (supplierToOrder.getTotalPriceDiscountPerOrder() != null && supplierToOrder.getTotalAmountDiscountPerOrder() != null) {
                if (priceAfterDiscount > supplierToOrder.getTotalPriceDiscountPerOrder().getKey()) {
                    priceAfterDiscount = priceAfterDiscount - supplierToOrder.getTotalPriceDiscountPerOrder().getValue();
                }
                if (totalAmountToOrder > supplierToOrder.getTotalAmountDiscountPerOrder().getKey()) {
                    priceAfterDiscount = ((100 - supplierToOrder.getTotalAmountDiscountPerOrder().getValue()) / 100) * priceAfterDiscount;
                }
            }
            double priceBeforeDiscount = supplierToOrder.calculatePriceBeforeDiscount(suppliersProduct);

            LocalDate deliveryDate = LocalDate.now().plusDays(supplierToOrder.getSupplierClosestDaysToDelivery());

            Order newOrderForSupplier = new Order(id++, supplierName, supplierAddress, supplierId, contactPhoneNumber, productsToOrder, priceBeforeDiscount, priceAfterDiscount,deliveryDate, branchId);
            Message response = orderDAO.addOrder(newOrderForSupplier);
            if(response.errorOccurred()) return response;
        }
        return new Message(0);
    }

    public Message updateProductsInOrder(int orderID, HashMap<Integer, Integer> productsToAdd)
    {
        Order order = orderDAO.getOrderByID(orderID);
        if(order == null)
            return new Message("Periodic Order Updating Fails, Reason: OrderID Is Not Exists");
        if(Math.abs(ChronoUnit.DAYS.between(order.getDeliveryDate(), LocalDate.now())) <= 1)
            return new Message("Periodic Order Updating Fails, Reason: There is one day or less until the delivery");
        for(int productID : productsToAdd.keySet())
            if (productDAO.getProduct(order.getSupplierId(), productID) == null)
                return new Message("The supplier with the ID: " + order.getSupplierId() + " not supplying the product with the ID: " + productID);
        Supplier supplierToOrder = supplierDAO.getSupplierByID(order.getSupplierId());
        ArrayList<Product> productsInOrder = order.getProductsInOrder();
        TreeSet<Product> productsToOrder = new TreeSet<>(Comparator.comparingInt(Product::getProductID));
        for (Map.Entry<Integer, Integer> productAndAmount : productsToAdd.entrySet())
        {
            int productID = productAndAmount.getKey();
            int amount = productAndAmount.getValue();
            Product productInSupplier = productDAO.getProduct(order.getSupplierId(), productID);
            if(productInSupplier == null || productInSupplier.getAmount() == 0) continue;
            Product product = new Product(productInSupplier);
            if(productInSupplier.getAmount() > amount) product.setAmount(amount);
            productsToOrder.add(product);
        }
        //Update the products amount for the order - checks the amount that the supplier got
        for(Product productInOrder : productsInOrder)
        {
            Product productInSupplier = productDAO.getProduct(order.getSupplierId(), productInOrder.getProductID());
            if(productInSupplier == null || productInSupplier.getAmount() == 0) continue;
            if(productInSupplier.getAmount() < productInOrder.getAmount())
                productsToOrder.add(new Product(productInSupplier));
            else
                productsToOrder.add(new Product(productInOrder));
        }
        ArrayList<Product> productsList = new ArrayList<>(productsToOrder);
        double priceAfterDiscount = supplierToOrder.calculatePriceAfterDiscountNew(productsList);
        int totalAmountToOrder = supplierToOrder.getTotalAmountNew(productsList);
        if (supplierToOrder.getTotalPriceDiscountPerOrder() != null && supplierToOrder.getTotalAmountDiscountPerOrder() != null)
        {
            if (priceAfterDiscount > supplierToOrder.getTotalPriceDiscountPerOrder().getKey())
                priceAfterDiscount = priceAfterDiscount - supplierToOrder.getTotalPriceDiscountPerOrder().getValue();
            if (totalAmountToOrder > supplierToOrder.getTotalAmountDiscountPerOrder().getKey())
                priceAfterDiscount = ((100 - supplierToOrder.getTotalAmountDiscountPerOrder().getValue()) / 100) * priceAfterDiscount;
        }
        double priceBeforeDiscount = supplierToOrder.calculatePriceBeforeDiscountNew(productsList);
        Order updatedOrderForSupplier = new Order(order, productsList, priceBeforeDiscount, priceAfterDiscount);
        Message message = orderDAO.removeOrder(orderID);
        if(message.errorOccurred()) return message;
        message = orderDAO.addOrder(updatedOrderForSupplier);
        if(message.errorOccurred()) return message;
        return new Message(updatedOrderForSupplier.getOrderID());
    }

    public Message removeProductsFromOrder(int orderID, ArrayList<Integer> productsToRemove)
    {
        Order order = orderDAO.getOrderByID(orderID);
        if(order == null)
            return new Message("Periodic Order Updating Fails, Reason: OrderID Is Not Exists");
        if(Math.abs(ChronoUnit.DAYS.between(order.getDeliveryDate(), LocalDate.now())) <= 1)
            return new Message("Periodic Order Updating Fails, Reason: There is one day or less until the delivery");
        boolean found = false;
        for(int productID : productsToRemove) {
            for (Product supplierProduct : order.getProductsInOrder())
            {
                if (supplierProduct.getProductID() == productID) {
                    found = true;
                    break;
                }
            }
            if(!found) return new Message("In this order there is no such product with the ID: " + productID);
            else found = false;
        }

        Supplier supplierToOrder = supplierDAO.getSupplierByID(order.getSupplierId());
        ArrayList<Product> productsToOrder = new ArrayList<>(order.getProductsInOrder());
        for (int productID : productsToRemove)
            productsToOrder.removeIf(product -> product.getProductID() == productID);
        //Update the products amount for the order - checks the amount that the supplier got
        double priceAfterDiscount = supplierToOrder.calculatePriceAfterDiscountNew(productsToOrder);
        int totalAmountToOrder = supplierToOrder.getTotalAmountNew(productsToOrder);
        if (supplierToOrder.getTotalPriceDiscountPerOrder() != null && supplierToOrder.getTotalAmountDiscountPerOrder() != null)
        {
            if (priceAfterDiscount > supplierToOrder.getTotalPriceDiscountPerOrder().getKey())
                priceAfterDiscount = priceAfterDiscount - supplierToOrder.getTotalPriceDiscountPerOrder().getValue();
            if (totalAmountToOrder > supplierToOrder.getTotalAmountDiscountPerOrder().getKey())
                priceAfterDiscount = ((100 - supplierToOrder.getTotalAmountDiscountPerOrder().getValue()) / 100) * priceAfterDiscount;
        }
        double priceBeforeDiscount = supplierToOrder.calculatePriceBeforeDiscountNew(productsToOrder);
        Order updatedOrderForSupplier = new Order(order, productsToOrder, priceBeforeDiscount, priceAfterDiscount);
        Message message = orderDAO.removeOrder(orderID);
        if(message.errorOccurred()) return message;
        if(priceAfterDiscount == 0){
            message = orderDAO.addOrder(updatedOrderForSupplier);
            if (message.errorOccurred()) return message;
        }
        return new Message(updatedOrderForSupplier.getOrderID());
    }

    public Message executePeriodicOrder(int periodicOrderID){
        PeriodicOrder periodicOrder = periodicOrderDAO.getPeriodicOrderByID(periodicOrderID);
        if(periodicOrder == null)
            return new Message("Periodic Order Creation Fails, Reason: periodicOrderID Is Not Exists");
        Supplier supplierToOrder = supplierDAO.getSupplierByID(periodicOrder.getSupplierID());
        ArrayList<Product> productsInOrder = periodicOrder.getProductsInOrder();
        ArrayList<Product> productsToOrder = new ArrayList<>();
        //Update the products amount for the order - checks the amount that the supplier got
        for(Product productInOrder : productsInOrder)
        {
            Product productInSupplier = productDAO.getProduct(periodicOrder.getSupplierID(), productInOrder.getProductID());
            if(productInSupplier == null || productInSupplier.getAmount() == 0) continue;
            if(productInSupplier.getAmount() < productInOrder.getAmount())
            {
                productsToOrder.add(new Product(productInSupplier));
            }
            else
            {
                productsToOrder.add(new Product(productInOrder));
            }
        }
        double priceAfterDiscount = supplierToOrder.calculatePriceAfterDiscountNew(productsToOrder);
        int totalAmountToOrder = supplierToOrder.getTotalAmountNew(productsToOrder);
        if (supplierToOrder.getTotalPriceDiscountPerOrder() != null && supplierToOrder.getTotalAmountDiscountPerOrder() != null)
        {
            if (priceAfterDiscount > supplierToOrder.getTotalPriceDiscountPerOrder().getKey())
                priceAfterDiscount = priceAfterDiscount - supplierToOrder.getTotalPriceDiscountPerOrder().getValue();
            if (totalAmountToOrder > supplierToOrder.getTotalAmountDiscountPerOrder().getKey())
                priceAfterDiscount = ((100 - supplierToOrder.getTotalAmountDiscountPerOrder().getValue()) / 100) * priceAfterDiscount;
        }
        double priceBeforeDiscount = supplierToOrder.calculatePriceBeforeDiscountNew(productsToOrder);
        LocalDate deliveryDate = LocalDate.now().plusDays(supplierToOrder.getSupplierClosestDaysToDelivery());//create the arrival date
        Order newOrderForSupplier = new Order(id++, supplierToOrder.getName(), supplierToOrder.getAddress(), supplierToOrder.getSupplierId(), supplierToOrder.getContactPhoneNumber(), productsToOrder, priceBeforeDiscount, priceAfterDiscount,deliveryDate, periodicOrder.getBranchID());
        Message message = orderDAO.addOrder(newOrderForSupplier);
        if(message.errorOccurred()) return message;
        return new Message(newOrderForSupplier.getOrderID());
    }

    public Order getOrderByID(int orderID) { return orderDAO.getOrderByID(orderID); }

    public void printOrder(int supplierID) {
        HashMap<Integer, Order> orders = orderDAO.getOrdersFromSupplier(supplierID);
        if(orders == null || orders.size() == 0) System.out.println("There is not orders from this supplier");
        for(Order order : orders.values())
            System.out.println(order);

    }

    public void printOrders() {
        if (orderDAO.getAllOrders() == null || orderDAO.getAllOrders().size() == 0){
            System.out.println("There is no regular orders in the system, check maybe periodic orders");
        }
        for(Order order: orderDAO.getAllOrders().values())
            System.out.println(order);
        System.out.println("\n");
    }

    public HashMap<Integer, Order> getNoneCollectedOrdersForToday(int branchID) { return orderDAO.getNoneCollectedOrdersForToday(branchID); }
    public HashMap<Integer, Order> getOrdersFromSupplier(int supplierID) { return orderDAO.getOrdersFromSupplier(supplierID); }
    public HashMap<Integer, Order> getOrdersToBranch(int branchID) { return orderDAO.getOrdersToBranch(branchID); }
    public HashMap<Integer, Order> getAllOrderForToday() { return orderDAO.getAllOrderForToday(); }
    public Message markOrderAsCollected(int orderID) { return orderDAO.markOrderAsCollected(orderID); }





    }
