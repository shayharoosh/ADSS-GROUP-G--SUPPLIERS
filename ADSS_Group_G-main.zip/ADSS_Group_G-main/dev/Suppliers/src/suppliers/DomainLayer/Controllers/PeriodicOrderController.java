
package suppliers.DomainLayer.Controllers;

import suppliers.DataAccessLayer.Classes.PeriodicOrderDAO;
import suppliers.DataAccessLayer.Classes.ProductDAO;
import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.PeriodicOrder;
import suppliers.DomainLayer.Classes.Product;

import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.HashMap;

public class PeriodicOrderController {
    private ProductDAO productDAO;
    private PeriodicOrderDAO periodicOrderDAO;
    private static int id;


    public PeriodicOrderController() {
        productDAO = new ProductDAO();
        periodicOrderDAO = new PeriodicOrderDAO();
        id = periodicOrderDAO.getLastPeriodicOrderID() + 1;
    }
    public Message createPeriodicOrder(int supplierID, int branchID, DayOfWeek fixedDay, HashMap<Integer, Integer> productsAndAmount) {
        HashMap<Integer, Product> supplierProducts = productDAO.getAllProductsByID(supplierID);
        ArrayList<Product> productsInOrder = new ArrayList<>();
        for(int productID : productsAndAmount.keySet()) {
            Product productInSupplier = supplierProducts.get(productID);
            if(productInSupplier == null)
                return new Message("The supplier with the ID: " + supplierID + " not supplying the product with the ID: " + productID);
            Product productInOrder = new Product(productInSupplier);
            productInOrder.setAmount(productsAndAmount.get(productID));
            productsInOrder.add(productInOrder);
        }
        PeriodicOrder periodicOrder = new PeriodicOrder(id++, supplierID, branchID, fixedDay, productsInOrder);
        return periodicOrderDAO.addPeriodicOrder(periodicOrder);
    }

    public HashMap<Integer, PeriodicOrder> getAllPeriodicOrderForToday() {
        return periodicOrderDAO.getAllPeriodicOrderForToday();
    }

    public HashMap<Integer, PeriodicOrder> getAllPeriodicOrders() {
        return periodicOrderDAO.getAllPeriodicOrders();
    }

    public void printPeriodicOrders() {
        HashMap<Integer, PeriodicOrder> periodicOrders = getAllPeriodicOrders();
        if (periodicOrders.isEmpty()) {
            System.out.println("There are no periodic orders");
            return;
        }
        for(PeriodicOrder periodicOrder : periodicOrders.values()) {
            System.out.println(periodicOrder);
        }
    }
}

