package suppliers.DomainLayer.Controllers;

import suppliers.DomainLayer.Classes.Product;
import suppliers.ServiceLayer.ProductService;
import suppliers.DataStructures.Message;

import java.util.HashMap;
import java.util.Map;


public class ProductController {

    private HashMap<Integer, HashMap<Integer, Integer>> productCatalogMapping;

    public ProductController(){
        productCatalogMapping = new HashMap<>();
    }

    public HashMap<Integer, HashMap<Integer, Integer>> getProductCatalogMapping() {
        return productCatalogMapping;
    }

    public HashMap<Integer, Product> createSupplyingProducts(HashMap<Integer, ProductService> supplyingProducts, int supplierId) {
        HashMap<Integer, Product> supplierProducts = new HashMap<>();
        for (Map.Entry<Integer, ProductService> entry : supplyingProducts.entrySet()) {
            int productId = entry.getKey();
            ProductService productService = entry.getValue();
            int catalogNumber = productService.getCatalogNumber();
            Product product = new Product(productService.getName(), supplierId, productService.getProductId(), productService.getCatalogNumber(), productService.getPrice(), productService.getAmount(), productService.getDiscountPerAmount(), productService.getManufacturer(),productService.getExpirationDays(), productService.getWeight());
            supplierProducts.put(productId, product);
            if(productCatalogMapping.containsKey(productId)) {
                productCatalogMapping.get(productId).put(supplierId, catalogNumber);
            } else {
                HashMap<Integer, Integer> toAdd = new HashMap<>();
                toAdd.put(supplierId, catalogNumber);
                productCatalogMapping.put(productId, toAdd);
            }
        }
        return supplierProducts;
    }

    public Message removeSupplierProducts(int supplierId) {
        int candidate = 0;
        for (Map.Entry<Integer, HashMap<Integer, Integer>> entry : productCatalogMapping.entrySet()) {
            HashMap<Integer, Integer> product =  entry.getValue();
            if(product.containsKey(supplierId)){
                candidate = 1;
                product.remove(supplierId);
            }
        }
        if(candidate == 1){
            return new Message(supplierId);
        }
        return new Message("The user doesn't have any products yet");
    }

    public void addProductToSupplier(int supplierId, String name, int productId, int catalogNumber, double price, HashMap<Integer, Double> discountPerAmount) {
        if(productCatalogMapping.containsKey(productId)){
            productCatalogMapping.get(productId).put(supplierId, catalogNumber);
        }
        else {
            HashMap<Integer, Integer> toAdd = new HashMap<>();
            toAdd.put(supplierId, catalogNumber);
            productCatalogMapping.put(productId, toAdd);
        }
    }

    public Message removeProductFromSupplier(int supplierId, int productId) {
        if(productCatalogMapping.containsKey(productId)) {
            HashMap<Integer, Integer> product = productCatalogMapping.get(productId);
            if(product.containsKey(supplierId)) {
                product.remove(supplierId);
                return new Message(productId);
            }
        }
        return new Message("Cannot delete item with id: " + productId + " because it does not exist in the supplier's product list");
    }

    public void editItemCatalogNumber(int supplierId, int productId, int newCatalogNumber) {
        HashMap<Integer, Integer> supplierCatalog = productCatalogMapping.get(productId);
        if(supplierCatalog.containsKey(supplierId)) {
            supplierCatalog.remove(supplierId);
            supplierCatalog.put(supplierId, newCatalogNumber);
        }
    }

    public boolean isProductExists(int productId) {
        return productCatalogMapping.containsKey(productId);
    }

    public Product getProductById(int productId) {
        HashMap<Integer, Integer> supplierCatalog = productCatalogMapping.get(productId);
        if(supplierCatalog != null) {
            for (Map.Entry<Integer, Integer> entry : supplierCatalog.entrySet()) {
                int supplierId = entry.getKey();
                int catalogNumber = entry.getValue();
                return new Product(productId, supplierId, catalogNumber);
            }
        }
        return null;
    }
}
