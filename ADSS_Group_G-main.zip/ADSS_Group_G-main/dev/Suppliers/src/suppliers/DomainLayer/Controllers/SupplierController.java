package suppliers.DomainLayer.Controllers;

import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.Agreement;
import suppliers.DomainLayer.Classes.ContactInformation;
import suppliers.DomainLayer.Classes.Product;
import suppliers.DomainLayer.Classes.Supplier;
import suppliers.ServiceLayer.ContactInformationService;
import suppliers.DataStructures.Pair;
import suppliers.DataAccessLayer.Classes.*;

import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SupplierController {
    private final ContactInformationDAO contactInformationDAO;
    private final DiscountPerAmountDAO discountPerAmountDAO;
    private final ProductDAO productDAO;
    private final SupplierDAO supplierDAO;
    private final AgreementDAO agreementDAO;
    private final DeliveryDaysDAO deliveryDaysDAO;
    private static int id;


    public SupplierController() {
        contactInformationDAO = new ContactInformationDAO();
        discountPerAmountDAO = new DiscountPerAmountDAO();
        productDAO = new ProductDAO();
        supplierDAO = new SupplierDAO();
        agreementDAO = new AgreementDAO();
        deliveryDaysDAO = new DeliveryDaysDAO();
        id = supplierDAO.getLastSupplierID() + 1;
    }

    public Message addSupplier(String name, String address, String bankAccount) {
        Message message = supplierDAO.searchBankAccount(bankAccount);
        if(message.errorOccurred()) return message;
        if(message.getAnswer())
        {
            System.out.println("Supplier with the same bank account is already exist in the system");
            return new Message("cannot add supplier, bankAccount is already exist");
        }
        Supplier newSupplier = new Supplier(id++, name, address, bankAccount);
        supplierDAO.addSupplier(newSupplier);
        return new Message(newSupplier.getSupplierId());
    }

    public Agreement createAgreement(String paymentType, boolean selfSupply, ArrayList<DayOfWeek> supplyDays, HashMap<Integer, Product> SupplyingProducts, String supplyMethod, int supplyTime) {
        Agreement agreement = new Agreement(paymentType, selfSupply, supplyMethod, supplyTime, supplyDays, SupplyingProducts);
        return new Agreement(paymentType, selfSupply, supplyMethod, supplyTime, supplyDays, SupplyingProducts);
    }

    public Agreement createAgreementWithDiscounts(String paymentType, boolean selfSupply, ArrayList<DayOfWeek> supplyDays, HashMap<Integer, Product> SupplyingProducts, String supplyMethod, int supplyTime, Pair<Integer,Double> totalAmountDiscountPerOrder ,  Pair<Double,Double> totalPriceDiscountPerOrder) {
        return new Agreement(paymentType, selfSupply, supplyMethod, supplyTime, supplyDays, SupplyingProducts, totalAmountDiscountPerOrder, totalPriceDiscountPerOrder);
    }

    public void setAgreement(Agreement a, int id) {
        supplierDAO.getSupplierByID(id).setNewAgreement(a);
    }

    public void setContacts(ArrayList<ContactInformationService> contactList, int supplierId) {
        ArrayList<ContactInformation> newContacts = new ArrayList<>();
        for (ContactInformationService c : contactList) {
            ContactInformation newContact = new ContactInformation(c.getName(), c.getPhoneNumber(), c.getEmail());
            newContacts.add(newContact);
            contactInformationDAO.addContactInformation(supplierId,newContact);
        }
        supplierDAO.getSupplierByID(supplierId).setContacts(newContacts);
    }

    public Message removeSupplier(int id) {
        if (supplierDAO.getSupplierByID(id)==null) {
            return new Message("Supplier can't be deleted because there is no supplier with the given id: " + id);
        }
        Message message = supplierDAO.removeSupplier(id);
        if(message.errorOccurred()) return message;
        return new Message(id);
    }

    public Message changeAddress(int id, String address) {
        if (supplierDAO.getSupplierByID(id)==null) {
            return new Message("Can't change address because supplier with id " + id + " doesn't exist in the system");
        } else {
            supplierDAO.getSupplierByID(id).setAddress(address);
            Message message = supplierDAO.updateSupplierAddress(id, address);
            if(message.errorOccurred()) return message;
            return new Message(id);
        }
    }

    public Message changeSupplierBankAccount(int id, String bankAccount) {
        if (supplierDAO.getSupplierByID(id)==null) {
            return new Message("Can't change bankAccount because supplier with id " + id + " doesn't exist in the system");
        } else {
            supplierDAO.getSupplierByID(id).setBankAccount(bankAccount);
            Message message = supplierDAO.updateSupplierBankAccount(id, bankAccount);
            if(message.errorOccurred()) return message;
            return new Message(id);
        }
    }

    public Message changeSupplierName(int id, String name) {
        if (supplierDAO.getSupplierByID(id)==null) {
            return new Message("Can't change name because supplier with id " + id + " doesn't exist in the system");
        } else {
            supplierDAO.getSupplierByID(id).setName(name);
            Message message = supplierDAO.updateSupplierName(id, name);
            if(message.errorOccurred()) return message;
            return new Message(id);
        }
    }

    public Message addContactsTOSupplier(int id, String name, String phone, String email) {
        if (supplierDAO.getSupplierByID(id)==null) {
            return new Message("Can't change name because supplier with id " + id + " doesn't exist in the system");
        }
        if(contactInformationDAO.getContactBySupplierID(id, phone) != null) {
            return new Message("can not add the new contact because he is already in the supplier's contactsList");
        }
        ContactInformation contactInformation = supplierDAO.getSupplierByID(id).addContactInformation(name, phone, email);
        Message message = contactInformationDAO.addContactInformation(id, contactInformation);
        if(message.errorOccurred()) return message;
        return new Message(id);
    }

    public Message removeSupplierContact(int id, String phoneNumber) {
        if (supplierDAO.getSupplierByID(id) == null)
            return new Message("Can't change name because supplier with id " + id + " doesn't exist in the system");
        if(contactInformationDAO.getContactBySupplierID(id, phoneNumber) == null)
            return new Message("Contact with the phone number: "+ phoneNumber +" does not exist ");
        for (ContactInformation c : supplierDAO.getSupplierByID(id).getContacts()) {
            if (c.getPhoneNumber().equals(phoneNumber)) {
                supplierDAO.getSupplierByID(id).getContacts().remove(c);
                contactInformationDAO.removeContactInformation(id, phoneNumber);
                return new Message(id);
            }
        }
        Message res = contactInformationDAO.removeContactInformation(id, phoneNumber);
        if(res.errorOccurred()) return res;
        return new Message("Contact with the phone number: "+ phoneNumber +" does not exist ");
    }

    public Message editSupplierContacts(int id, String email, String newEmail, String newPhone, String oldPhone) {
        if (supplierDAO.getSupplierByID(id) == null) return new Message("Can't change name because supplier with id " + id + " doesn't exist in the system");
        if(contactInformationDAO.getContactBySupplierID(id, oldPhone) == null) return new Message("Can't edit phoneNumber because contact with the phoneNumber: " + oldPhone +" does not exist ");
        if(newEmail.equals("")) {
            Message res = editSupplierContactPhone(id, oldPhone, newPhone);
            if(res.errorOccurred()) return res;
            Message res2 = contactInformationDAO.updatePhoneNumber(id, oldPhone, newPhone);
            if(res2.errorOccurred()) return res2;
            else return res;
        }
        else {
            Message res = editSupplierContactEmail(id, email, newEmail);
            if(res.errorOccurred()) return res;
            Message res2 = contactInformationDAO.updateEmail(id, oldPhone, newEmail);
            if(res2.errorOccurred()) return res2;
            else return res;
        }
    }


    public Message editSupplierContactEmail(int id, String email, String newEmail){
        for (ContactInformation c : supplierDAO.getSupplierByID(id).getContacts()) {
            if (c.getEmail().equals(email)) {
                c.setEmailAddress(newEmail);
                return new Message(id);
            }
        }
        return new Message("Can't edit email because contact with the email: "+ email +" does not exist ");
    }

    public Message editSupplierContactPhone(int id, String oldPhone, String newPhone){
        for (ContactInformation c : supplierDAO.getSupplierByID(id).getContacts()) {
            if (c.getPhoneNumber().equals(oldPhone)) {
                c.setPhoneNumber(newPhone);
                return new Message(id);
            }
        }
        return new Message("Can't edit phone number because contact with the  phone number: " + oldPhone + " does not exist ");
    }

    public Message addItemToAgreement(int supplierID,String name, int productId, int catalogNumber, double price, int amount,  HashMap<Integer, Double> discountPerAmount, double weight, String manufacturer, int expirationDays) {
        if (supplierDAO.getSupplierByID(supplierID) == null) {
            return new Message("Can't change name because supplier with id " + supplierID + " doesn't exist in the system");
        }
        HashMap<Integer, Product> supplierProductsMap =supplierDAO.getSupplierByID(supplierID).getAgreement().getSupplyingProducts();
        for (Map.Entry<Integer, Product> entry : supplierProductsMap.entrySet()) {
            Product product = entry.getValue();
            if (product.getProductID() == productId)
                return new Message("can not add item with id: " + productId + " because it's already exist in the supplier's products List");
        }
        Product product = supplierDAO.getSupplierByID(supplierID).addProduct(name, supplierID, productId, catalogNumber, price, amount, discountPerAmount, weight, manufacturer, expirationDays);
        Message message = productDAO.addProduct(supplierID, product);
        if (message.errorOccurred()) return message;
        for(Map.Entry<Integer, Double> discount : discountPerAmount.entrySet())
        {
            message = discountPerAmountDAO.addDiscountPerAmount(supplierID, productId, discount.getKey(), discount.getValue());
            if (message.errorOccurred()) return message;
        }
        return new Message(supplierID);
    }

    public Message removeItemFromAgreement(int supplierID, int itemIdToDelete) {
        if (supplierDAO.getSupplierByID(supplierID) == null) {
            return new Message("Can't change name because supplier with id " + supplierID + " doesn't exist in the system");
        }
        HashMap<Integer, Product> supplierProductsMap= supplierDAO.getSupplierByID(supplierID).getAgreement().getSupplyingProducts();
        for (Map.Entry<Integer, Product> entry : supplierProductsMap.entrySet()) {
            Product product = entry.getValue();
            if (product.getProductID() == itemIdToDelete) {
                supplierDAO.getSupplierByID(supplierID).removeProduct(itemIdToDelete);
                Message response = productDAO.removeProduct(supplierID, itemIdToDelete);
                if (response.errorOccurred()) return response;
                return new Message(supplierID);
            }
        }
        return new Message("can not delete item with id: " + itemIdToDelete + " beacuse it is not exist in the supplier's products List");
    }

    public Message editPaymentMethodAndDeliveryMethodAndDeliveryDays(int supplierId, boolean selfSupply, String paymentMethod, ArrayList<DayOfWeek> days, String supplyMethod, int supplyTime) {
        if(supplierDAO.getSupplierByID(supplierId) == null){
            return new Message("Supplier with id: " + supplierId + " is not exist, please try again");
        }
        Supplier supplier = supplierDAO.getSupplierByID(supplierId);
        supplier.setSelfSupply(selfSupply);
        supplier.SetPaymentType(paymentMethod);
        supplier.setDeliveryDays(days);
        supplier.setSupplyMethod(supplyMethod);
        supplier.setSupplyTime(supplyTime);
        Message response = agreementDAO.updateAgreement(supplierId, paymentMethod, selfSupply, supplyMethod, supplyTime);
        if (response.errorOccurred()) return response;
        if(days != null) response = deliveryDaysDAO.updateDeliveryDays(supplierId, days);
        else response = deliveryDaysDAO.removeDeliveryDays(supplierId);
        if(response.errorOccurred()) return response;
        return new Message(supplierId);
    }

    public Message editItemCatalogNumber(int supplierId, int productId, int newCatalogNumber) {
        if(supplierDAO.getSupplierByID(supplierId) == null){
            return new Message("Supplier with id: " + supplierId + " is not exist, please try again");
        }
        HashMap<Integer, Product> supplierProductsMap= supplierDAO.getSupplierByID(supplierId).getAgreement().getSupplyingProducts();
        for (Map.Entry<Integer, Product> entry : supplierProductsMap.entrySet()) {
            Product product = entry.getValue();
            if (product.getProductID() == productId) {
                supplierDAO.getSupplierByID(supplierId).setProductCatalogNumber(productId, newCatalogNumber);
                Message response = productDAO.updateCatalogID(supplierId, productId, newCatalogNumber);
                if (response.errorOccurred()) return response;
                return new Message(supplierId);
            }
        }
        return new Message("can not edit item with id: " + productId + " because it is not exist in the supplier's products List");
    }

    public void printSuppliers() {
        if(id <= 1) System.out.println("Please add a supplier before choosing this option");
        else supplierDAO.printAllSuppliers();
    }

    public Message addDiscount(int supplierId, int productId, int amount, double discount) {
        if(supplierDAO.getSupplierByID(supplierId) == null){
            return new Message("Supplier with id: " + supplierId + " is not exist, please try again");
        }
        HashMap<Integer, Product> supplierProductsMap= supplierDAO.getSupplierByID(supplierId).getAgreement().getSupplyingProducts();
        for (Map.Entry<Integer, Product> entry : supplierProductsMap.entrySet()) {
            Product product = entry.getValue();
            if (product.getProductID() == productId) {
                product.addDiscount(amount, discount);
                Message res = discountPerAmountDAO.addDiscountPerAmount(supplierId, productId, amount, discount);
                if(res.errorOccurred()) return res;
                return new Message(supplierId);
            }
        }
        return new Message("can not add discount to item with id : " + productId + " because item is not exist in the supplier's products List");
    }

    public Message removeDiscount(int supplierId, int productId, int amount, double discount) {
        if(supplierDAO.getSupplierByID(supplierId) == null){
            return new Message("Supplier with id: " + supplierId + " is not exist, please try again");
        }
        HashMap<Integer, Product> supplierProductsMap= supplierDAO.getSupplierByID(supplierId).getAgreement().getSupplyingProducts();
        for (Map.Entry<Integer, Product> entry : supplierProductsMap.entrySet()) {
            Product product = entry.getValue();
            if (product.getProductID() == productId) {
                product.removeDiscount(amount);
                Message res = discountPerAmountDAO.removeDiscountPerAmount(supplierId, productId, amount);
                if(res.errorOccurred()) return res;
                return new Message(supplierId);
            }
        }
        return new Message("can not delete discount to item with id : " + productId + " because item is not exist in the supplier's products List");
    }


    public ArrayList<ArrayList<Supplier>> findFastestSuppliers(HashMap<Integer, Integer> products) {
        HashMap<Integer, Supplier> copyOfSuppliers = new HashMap<>(supplierDAO.getAllSuppliers());
        ArrayList<ArrayList<Supplier>> sortedSuppliers = new ArrayList<>();

        for (Map.Entry<Integer, Integer> entry : products.entrySet()) {
            int productId = entry.getKey();
            int requiredAmount = entry.getValue();
            ArrayList<Supplier> supplierCanSupply = new ArrayList<>();

            // Filter suppliers that can supply the required amount
            for (Map.Entry<Integer, Supplier> e : copyOfSuppliers.entrySet()) {
                Supplier currSup = e.getValue();
                if (currSup.getSupplyingProducts().containsKey(productId) &&
                        currSup.getAmountByProduct(productId) >= requiredAmount) {
                    supplierCanSupply.add(currSup);
                }
            }

            // Sort filtered suppliers by price and delivery time
            supplierCanSupply.sort((s1, s2) -> {
                double price1 = s1.calculatePricePerProduct(productId, requiredAmount);
                double price2 = s2.calculatePricePerProduct(productId, requiredAmount);
                if (price1 != price2) {
                    return Double.compare(price1, price2);
                } else {
                    int deliveryTime1 = s1.getSupplierClosestDaysToDelivery();
                    int deliveryTime2 = s2.getSupplierClosestDaysToDelivery();
                    return Integer.compare(deliveryTime1, deliveryTime2);
                }
            });

            sortedSuppliers.add(supplierCanSupply);
        }

        return sortedSuppliers;
    }



}
