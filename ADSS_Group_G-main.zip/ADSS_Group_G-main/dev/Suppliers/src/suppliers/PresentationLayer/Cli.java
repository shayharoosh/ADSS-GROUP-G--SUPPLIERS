package suppliers.PresentationLayer;

import suppliers.DataAccessLayer.Database;
import suppliers.DataStructures.Message;
import suppliers.DataStructures.Pair;
import suppliers.DomainLayer.Classes.PeriodicOrder;
import suppliers.ServiceLayer.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.time.DayOfWeek;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class Cli {
    private final BufferedReader reader;
    private final SupplierService supplierService;
    private final ContactInformationService contactInformationService;
    private final OrderService orderService;

    public Cli() {
        Database.connect();
        Database.clearTables();
        reader = new BufferedReader(new InputStreamReader(System.in));
        supplierService = new SupplierService();
        contactInformationService = new ContactInformationService();
        orderService = new OrderService();
        startDailyTask();
    }

    public static void main(String[] args) {
        Cli ui = new Cli();
        ui.updateProductsInOrder();
        ui.removeProductsFromOrder();
    }

    public void print(String message) {
        System.out.println(message);
    }

    private void printOrders() {
        supplierService.printOrders();
    }

    private void printPeriodicOrders() {
        supplierService.printPeriodicOrders();
    }

    public void start() {
        try {
            print("Welcome to Super-Lee supplier module!\nDo you want to use existing data or load new data to the system?\n1. Load Data\n2. New Data \n3. Exit \n4. Return the the Menu");
            int n = Integer.parseInt(reader.readLine());
            switch (n) {
                case 1:
                    loadData();
                    menuOrder();
                    break;
                case 2:
                    menuAdd();
                    break;
                case 3:
                    print("Thank you for using, hope to see you again!");
                    System.exit(0);
                    return;
                case 4:
                    return;
                default:
                    print("Input out of range, please select 1, 2 or 3");
                    start();
                    break;
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
            start();
        }
    }

    private void menuAdd() {
        try {
            print("Hey, Do you want to add new supplier? \n1. Yes\n2. No");
            int n = Integer.parseInt(reader.readLine());
            switch (n) {
                case 1:
                    addNewSupplier();
                    menuOrder();
                    break;
                case 2:
                    menuOrder();
                    break;
                default:
                    print("Input out of range, please choose again");
                    menuAdd();
                    break;
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
            menuAdd();
        }
    }

    private void menuOrder() {
        while (true) {
            print("Please choose one of the following options:");
            print("1 - Create an Order Due To Shortage");
            print("2 - Create a Periodic Order");
            print("3 - Edit Suppliers");
            print("4 - View Past Orders");
            print("5 - View Past Periodic Orders");
            print("6 - View Periodic Orders For Today");
            print("7 - Back To The Menu");
            try {
                int choose = Integer.parseInt(reader.readLine());
                switch (choose) {
                    case 1:
                        HashMap<Integer, Integer> shortageList = enterShortage();
                        supplierService.createOrderByShortage(1, shortageList);
                        print("Order created successfully");
                        break;
                    case 2:
                        createPeriodicOrder();
                        supplierManagerCLI();
                        break;
                    case 3:
                        supplierManagerCLI();
                        break;
                    case 4:
                        printOrders();
                        menuOrder();
                        break;
                    case 5:
                        printPeriodicOrders();
                        menuOrder();
                        break;
                    case 6:
                        printPeriodicOrdersForToday();
                        break;
                    case 7:
                        start();
                        break;
                    default:
                        print("Please choose a valid number");
                        break;
                }
            } catch (IOException | NumberFormatException e) {
                e.printStackTrace();
                print("Invalid input, please try again.");
            }
        }
    }


    private HashMap<Integer, Integer> enterShortage() throws IOException {
        HashMap<Integer, Integer> productsToOrder = new HashMap<>();
        boolean continueAdding = true;
        while (continueAdding) {
            print("Enter product ID: ");
            int productId = Integer.parseInt(reader.readLine());
            if (!supplierService.isProductExists(productId)) {
                print("Product doesn't exist, please try again");
                continue;
            }
            print("Enter amount needed: ");
            int amount = Integer.parseInt(reader.readLine());
            productsToOrder.put(productId, amount);
            String response = "";
            while (true) {
                print("Do you want to add another product? (yes/no): ");
                response = reader.readLine();
                if (response.equalsIgnoreCase("yes") || response.equalsIgnoreCase("no")) {
                    break;
                } else {
                    print("Invalid input. Please enter 'yes' or 'no'.");
                }
            }

            if (response.equalsIgnoreCase("no")) {
                continueAdding = false;
            }
        }
        return productsToOrder;
    }


    public void loadData() {
        boolean supplier1Added = addSupplier("Zoglo", "Rager 17", "123456", createAgreement1(), createContacts1());
        boolean supplier2Added = addSupplier("Pinuk LTD", "Rotchild", "202020", createAgreement2(), createContacts2());
        boolean supplier3Added = addSupplier("Shelly Sweets", "Hatizmoret 4", "281199", createAgreement3(), createContacts3());

        if (supplier1Added || supplier2Added || supplier3Added) {
            print("Data loaded successfully, you can use it now");
        }
    }

    private boolean addSupplier(String name, String address, String bankAccount, AgreementService agreement, ArrayList<ContactInformationService> contacts) {
        Message mes = supplierService.addSupplier(name, address, bankAccount, agreement, contacts);
        if (!mes.errorOccurred()) {
            return true;
        } else {
            print(mes.getErrorMessage());
            return false;
        }
    }

    private AgreementService createAgreement1() {
        ArrayList<DayOfWeek> deliveryDays = new ArrayList<>();
        deliveryDays.add(DayOfWeek.SUNDAY);
        deliveryDays.add(DayOfWeek.TUESDAY);
        deliveryDays.add(DayOfWeek.SATURDAY);
        HashMap<Integer, ProductService> supplyingProducts = new HashMap<>();
        HashMap<Integer, Double> discountPerAmount = new HashMap<>();
        discountPerAmount.put(20, 5.0);
        supplyingProducts.put(1, new ProductService("Tomato", 1, 20, 4.5, 10, discountPerAmount, "Bereshit", 10, 0.2));
        supplyingProducts.put(2, new ProductService("Cucumber", 2, 2, 5, 35, discountPerAmount, "Zoglo", 10, 0.2));
        return new AgreementService("Cash", true, deliveryDays, supplyingProducts,"By Days", 0);
    }

    private AgreementService createAgreement2() {
        ArrayList<DayOfWeek> deliveryDays = new ArrayList<>();
        deliveryDays.add(DayOfWeek.THURSDAY);
        deliveryDays.add(DayOfWeek.FRIDAY);
        HashMap<Integer, ProductService> supplyingProducts = new HashMap<>();
        HashMap<Integer, Double> discountPerAmount = new HashMap<>();
        discountPerAmount.put(10, 15.0);
        discountPerAmount.put(30, 20.0);
        supplyingProducts.put(3, new ProductService("Shampoo", 3, 30, 10, 20, discountPerAmount, "Dove", 30, 0.5));
        supplyingProducts.put(4, new ProductService("Lotion", 4, 40, 15, 50, discountPerAmount, "Nivea", 30, 0.5));
        supplyingProducts.put(1, new ProductService("Tomato", 1, 10, 4.5, 30, discountPerAmount, "Bereshit", 10, 0.2));
        supplyingProducts.put(2, new ProductService("Cucumber", 2, 20, 5, 100, discountPerAmount, "Bereshit", 10, 0.2));
        return new AgreementService("Cash", true, deliveryDays, supplyingProducts,"By Order", 3);
    }

    private AgreementService createAgreement3() {
        ArrayList<DayOfWeek> deliveryDays = new ArrayList<>();
        deliveryDays.add(DayOfWeek.MONDAY);
        deliveryDays.add(DayOfWeek.WEDNESDAY);
        HashMap<Integer, ProductService> supplyingProducts = new HashMap<>();
        HashMap<Integer, Double> discountPerAmount = new HashMap<>();
        Pair<Integer, Double> totalDiscountPerAmount = new Pair<>(30, 5.0);
        Pair<Double, Double> totalDiscountPerPrice = new Pair<>(200.0, 20.0);
        discountPerAmount.put(20, 5.0);
        supplyingProducts.put(5, new ProductService("Bubble Gum", 5, 50, 2, 30, discountPerAmount, "Orbit", 30, 0.1));
        supplyingProducts.put(6, new ProductService("Lollipop", 6, 60, 3, 40, discountPerAmount, "Sugarpova", 30, 0.1));

        return new AgreementService("Cash", true, deliveryDays, supplyingProducts, totalDiscountPerAmount, totalDiscountPerPrice, "By Days", 0);
    }

    private ArrayList<ContactInformationService> createContacts1() {
        ArrayList<ContactInformationService> contacts = new ArrayList<>();
        contacts.add(new ContactInformationService("itay", "itay@gmail.com", "052-5252525"));
        return contacts;
    }

    private ArrayList<ContactInformationService> createContacts2() {
        ArrayList<ContactInformationService> contacts = new ArrayList<>();
        contacts.add(new ContactInformationService("Nadav", "nadav@gmail.com", "054-5454545"));
        return contacts;
    }

    private ArrayList<ContactInformationService> createContacts3() {
        ArrayList<ContactInformationService> contacts = new ArrayList<>();
        contacts.add(new ContactInformationService("Shelly", "Shelly_sweets@gmail.com", "050-5050500"));
        return contacts;
    }

    //-------------------------------------------- Supplier Manager CLI ----------------------------------------------------//

    private void supplierManagerCLI() {
        print("Please choose one of the following option:\n1. Add new Supplier\n2. Delete Supplier \n3. Edit Supplier's information \n4. Print Suppliers \n5. Back");
        try {
            int action = Integer.parseInt(reader.readLine());
            switch (action) {
                case 1:
                    addNewSupplier();
                    menuOrder();
                    break;
                case 2:
                    deleteSupplier();
                    menuOrder();
                    break;
                case 3:
                    editSupplier();
                    menuOrder();
                    break;
                case 4:
                    printSuppliers();
                    menuOrder();
                    break;
                case 5:
                    return;
                default:
                    supplierManagerCLI();
            }
            start();
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Illegal Input");
            supplierManagerCLI();
        }
    }

    private void addNewSupplier() {
        try {
            int keepAdding = 1;
            while (keepAdding == 1) {
                print("Please enter the supplier's name");
                String name = reader.readLine();
                print("Please enter the supplier's address");
                String address = reader.readLine();
                String bankAccount;
                do {
                    print("Please enter the supplier's bank account number");
                    bankAccount = reader.readLine();
                    if (!checkBankAccountValidation(bankAccount)) {
                        print("Not a valid bank account number, please try again");
                    } else {
                        break;
                    }
                } while (true);

                ArrayList<ContactInformationService> contactList = createContacts();
                AgreementService as = createAgreement();
                Message mes = supplierService.addSupplier(name, address, bankAccount, as, contactList);
                if (!mes.errorOccurred()) {
                    print("Supplier added successfully, supplier's id is: " + mes.getSupplierId());
                } else {
                    print(mes.getErrorMessage());
                }
                print("Would you like to add another supplier?  \n1. Yes\n2. No");
                keepAdding = Integer.parseInt(reader.readLine());
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void deleteSupplier() {
        try {
            int keepDeleting = 1;
            while (keepDeleting == 1) {
                print("Please Enter The ID of the Supplier you wish to delete");
                int id = Integer.parseInt(reader.readLine());
                Message mes = supplierService.removeSupplier(id);
                if (mes.errorOccurred())
                    print(mes.getErrorMessage());
                else {
                    print("The supplier with id: " + mes.getSupplierId() + " deleted successfully");
                }
                print("Would you like to delete another supplier?  \n1. Yes\n2. No");
                keepDeleting = Integer.parseInt(reader.readLine());
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void editSupplier() {
        try {
            print("Please Enter The ID of the Supplier you wish to edit");
            int id = Integer.parseInt(reader.readLine());
            int keepEditing = 1;
            while (keepEditing == 1) {
                print("What would you like to edit?  \n1. Supplier's personal details \n2. Supplier's agreement details ");
                int action = Integer.parseInt(reader.readLine());
                switch (action) {
                    case 1:
                        editSupplierPersonalDetails(id);
                        break;
                    case 2:
                        editSupplierAgreement(id);
                        break;
                }
                print("Would you like to edit anything else?  \n1. Yes\n2. No");
                keepEditing = Integer.parseInt(reader.readLine());
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void printSuppliers() {
        supplierService.printSuppliers();
    }

    //---------------------------------------------- Helper Functions for adding new supplier --------------------------------------------------------//
    private String choosePaymentMethod() {
        try {
            print("Please choose Payment method according to the supplier's agreement \n1. Cash \n2. TransitToAccount \n3. Credit\n4. net 30 EOM \n5. net 60 EOM");
            int paymentMethod = Integer.parseInt(reader.readLine());
            while (paymentMethod < 1 || paymentMethod > 5) {
                print("Please Enter a valid number (1 to 5)");
                paymentMethod = Integer.parseInt(reader.readLine());
            }
            switch (paymentMethod) {
                case 1:
                    return "Cash";
                case 2:
                    return "TransitToAccount";
                case 3:
                    return "Credit";
                case 4:
                    return "net 30 EOM";
                case 5:
                    return "net 60 EOM";
                default:
                    return choosePaymentMethod();
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
            return choosePaymentMethod();
        }
    }

    private void editPaymentMethodAndDeliveryMethodAndDeliveryDays(int id) {
        try {
            String paymentMethod = choosePaymentMethod();
            boolean selfSupply;
            String supplyMethod = "";
            int supplyTime = 0;
            ArrayList<DayOfWeek> days = new ArrayList<>();
            print("Choose one of the following Supply methods according to the supplier's agreement \n1. By Days \n2. By Order \n3. By Super-Lee");
            int userInput = Integer.parseInt(reader.readLine());
            while (userInput < 1 || userInput > 3) {
                print("Please Enter a valid number (1,2,3)");
                userInput = Integer.parseInt(reader.readLine());
            }
            if (userInput == 1) {
                selfSupply = true;
                supplyMethod = "Fixed Days";
                supplyTime = -1;
                int day = 0;
                print("please choose supplying days");
                print("\n1. Monday \n2. Tuesday \n3. Wednesday \n4. Thursday \n5. Friday \n6. Saturday \n7. Sunday \n8.That's all...");
                while (day != 8) {
                    day = Integer.parseInt(reader.readLine());
                    if (day >= 1 && day <= 7)
                        days.add(DayOfWeek.of(day));
                    else if (day != 8)
                        print("Please enter a valid number : 1 to 7, or 8 if you done adding days");
                }
            } else if (userInput == 2) {
                selfSupply = true;
                supplyMethod = "DaysAmount";
                print("please enter the amount of days you want to supply");
                supplyTime = Integer.parseInt(reader.readLine());
            } else {
                selfSupply = false;
                supplyMethod = "Super-Lee";
                print("please enter the amount of days you want to supply");
                supplyTime = Integer.parseInt(reader.readLine());
            }

            Message mes = supplierService.editPaymentMethodAndDeliveryMethodAndDeliveryDays(id, selfSupply, paymentMethod, days, supplyMethod, supplyTime);
            if (!mes.errorOccurred()) {
                print("The supplier's delivery term changed successfully for Supplier with id: " + id);
            } else {
                print(mes.getErrorMessage());
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private ArrayList<ContactInformationService> createContacts() {
        ArrayList<ContactInformationService> contactList = new ArrayList<>();
        try {
            int keepAdding = 1;
            while (keepAdding == 1) {
                ContactInformationService c = addContact();
                contactList.add(c);
                print("Would you like to add another contact? \n1. Yes\n2. No");
                keepAdding = Integer.parseInt(reader.readLine());
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
        return contactList;
    }

    public ContactInformationService addContact() {
        try {
            print("Please enter a contact name");
            String nameC = reader.readLine();
            String email = getValidEmail();
            print("Please enter " + nameC + "'s phone number");
            String phone = reader.readLine();
            while (!ContactInformationService.validatePhoneNumber(phone)) {
                print("Not a valid phone number, please try again");
                phone = reader.readLine();
            }
            return new ContactInformationService(nameC, email, phone);
        } catch (IOException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
            return addContact();
        }
    }

    private AgreementService createAgreement() {
        try {
            String paymentMethod = choosePaymentMethod();
            String supplyMethod;
            int supplyTime;
            boolean selfSupply;
            ArrayList<DayOfWeek> days = new ArrayList<>();
            print("Choose one of the following Supply methods according to the supplier's agreement \n1. By Days \n2. By Order \n3. By Super-Lee");
            int userInput = Integer.parseInt(reader.readLine());
            while (userInput < 1 || userInput > 3) {
                print("Please Enter a valid number (1,2,3)");
                userInput = Integer.parseInt(reader.readLine());
            }
            if (userInput == 1) {
                selfSupply = true;
                supplyMethod = "Fixed Days";
                supplyTime = -1;
                int day = 0;
                print("please choose supplying days\n1. Monday \n2. Tuesday \n3. Wednesday \n4. Thursday \n5. Friday \n6. Saturday \n7. Sunday \n8.Done adding days");
                while (day != 8) {
                    day = Integer.parseInt(reader.readLine());
                    if (day >= 1 && day <= 7)
                        days.add(DayOfWeek.of(day));
                    else if (day != 8)
                        print("Please enter a valid number : 1 to 7, or 8 if you done adding days");
                }
            } else if (userInput == 2) {
                selfSupply = true;
                supplyMethod = "DaysAmount";
                print("please enter the amount of days you want to supply");
                supplyTime = Integer.parseInt(reader.readLine());
            } else {
                selfSupply = false;
                supplyMethod = "Super-Lee";
                print("please enter the amount of days you want to supply");
                supplyTime = Integer.parseInt(reader.readLine());
            }

            print("Would you like to add specific items to the agreement? \n1. Yes\n2. No");
            int keepAdding = Integer.parseInt(reader.readLine());
            HashMap<Integer, ProductService> items = new HashMap<>();
            while (keepAdding == 1) {
                ProductService newProduct = createProduct();
                items.put(newProduct.getProductId(), newProduct);
                print("Would you like to add another Item? \n1. Yes\n2. No");
                keepAdding = Integer.parseInt(reader.readLine());
            }
            print("Would you like to add discounts per order price and per order amount? \n1. Yes\n2. No");
            int addDiscount = Integer.parseInt(reader.readLine());
            if (addDiscount == 1) {
                print("please enter the minimum amount you want to give a discount for, and the discount in percentage in the format : amount:discount");
                String amountDiscount = reader.readLine();
                String[] arr1 = amountDiscount.split(":");
                print("please enter the minimum order price you want to give a discount for, and the discount price in the format : price:discount price");
                String priceDiscount = reader.readLine();
                String[] arr2 = priceDiscount.split(":");
                Pair<Integer, Double> amountPair = new Pair<>(Integer.parseInt(arr1[0]), Double.parseDouble(arr1[1]));
                Pair<Double, Double> pricePair = new Pair<>(Double.parseDouble(arr2[0]), Double.parseDouble(arr2[1]));
                return new AgreementService(paymentMethod, selfSupply, days, items, amountPair, pricePair, supplyMethod, supplyTime);
            }
            return new AgreementService(paymentMethod, selfSupply, days, items, supplyMethod, supplyTime);
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
            return createAgreement();
        }
    }

    public ProductService createProduct() {
        try {
            print("Please enter product's name");
            String name = reader.readLine();
            print("Please enter product's id");
            int productId = Integer.parseInt(reader.readLine());
            print("Please enter product's price");
            double price = Double.parseDouble(reader.readLine());
            print("Please enter product's catalog number");
            int catalogNumber = Integer.parseInt(reader.readLine());
            print("Please enter product's amount");
            int amount = Integer.parseInt(reader.readLine());
            print("Please enter product's manufacturer");
            String manufacturer = reader.readLine();
            print("Please enter product's expiration days");
            int expirationDays = Integer.parseInt(reader.readLine());
            print("Please enter product's weight");
            double weight = Double.parseDouble(reader.readLine());
            print("Ok, now please add Discounts according to the format:amount:Discount in percentages, amount:Discount in percentages,..");
            String[] arr = reader.readLine().split("\\s*,\\s*");
            HashMap<Integer, Double> discounts = new HashMap<>();
            for (String s1 : arr) {
                String[] val = s1.split(":");
                int key = Integer.parseInt(val[0]);
                double value = Double.parseDouble(val[1]);
                discounts.put(key, value);
            }
            return new ProductService(name, productId, catalogNumber, price, amount, discounts, manufacturer, expirationDays, weight);
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
            return createProduct();
        }
    }

    public boolean checkBankAccountValidation(String input) {
        String pattern = "^\\d{6,9}$";
        return input.matches(pattern);
    }

    //---------------------------------------------- Helper Functions for editing supplier--------------------------------------------

    private void editSupplierAgreement(int id) {
        try {
            print("What would you like to edit? \n1. Supplier's payment method + delivery method + delivery days \n2.Supplier's items");
            int action = Integer.parseInt(reader.readLine());
            while (action < 1 || action > 2) {
                print("Please Enter a valid number (1 or 2)");
                action = Integer.parseInt(reader.readLine());
            }
            switch (action) {
                case 1:
                    editPaymentMethodAndDeliveryMethodAndDeliveryDays(id);
                    break;
                case 2:
                    editItems(id);
                    break;
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void editItems(int supplierID) {
        try {
            print("Please choose an action?  \n1. Add a new item\n2. Delete an item \n3. edit an item");
            int action = Integer.parseInt(reader.readLine());
            if (action == 1) {
                ProductService newItem = createProduct();
                Message mes = supplierService.addItemToAgreement(supplierID, newItem.getName(), newItem.getProductId(), newItem.getCatalogNumber(), newItem.getPrice(), newItem.getAmount(), newItem.getDiscountPerAmount(), newItem.getWeight(), newItem.getManufacturer(), newItem.getExpirationDays());
                if (mes.errorOccurred())
                    print(mes.getErrorMessage());
            } else if (action == 2) {
                print("please enter the product ID you wish to delete from suppliers agreement");
                int itemIdToDelete = Integer.parseInt(reader.readLine());
                Message mes = supplierService.removeItemFromAgreement(supplierID, itemIdToDelete);
                if (mes.errorOccurred())
                    print(mes.getErrorMessage());
            } else if (action == 3) {
                editItem(supplierID);
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    public void editItem(int supplierID) {
        try {
            print("please enter the product ID you want to edit");
            int productId = Integer.parseInt(reader.readLine());
            print("Please choose an action?  \n1. edit item's catalog number\n2. Delete a discount for this item \n3. add a discount for this item");
            int action = Integer.parseInt(reader.readLine());
            switch (action) {
                case 1:
                    editItemCatalogNumber(supplierID, productId);
                    break;
                case 2:
                    editRemoveDiscount(supplierID, productId);
                    break;
                case 3:
                    editAddDiscount(supplierID, productId);
                    break;
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void editAddDiscount(int supplierID, int productId) {
        try {
            print("please add Discount according to the format:amount:Discount in percentages");
            String s = reader.readLine();
            String[] val = s.split(":");
            int amount = Integer.parseInt(val[0]);
            double discount = Double.parseDouble(val[1]);
            Message mes = supplierService.addDiscounts(supplierID, productId, amount, discount);
            if (mes.errorOccurred())
                print(mes.getErrorMessage());
            else {
                print("Discount added successfully");
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void editRemoveDiscount(int supplierID, int productId) {
        try {
            print("please enter the discount you want to delete");
            String s = reader.readLine();
            String[] val = s.split(":");
            int amount = Integer.parseInt(val[0]);
            double discount = Double.parseDouble(val[1]);
            Message mes = supplierService.removeDiscounts(supplierID, productId, amount, discount);
            if (mes.errorOccurred())
                print(mes.getErrorMessage());
            else {
                print("Discount deleted successfully");
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void editItemCatalogNumber(int supplierId, int productId) {
        try {
            print("please enter the new catalog number");
            int newCatalogNumber = Integer.parseInt(reader.readLine());
            Message mes = supplierService.editItemCatalogNumber(supplierId, productId, newCatalogNumber);
            if (mes.errorOccurred())
                print(mes.getErrorMessage());
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void editSupplierPersonalDetails(int id) {
        try {
            print("What would you like to edit?  \n1. Supplier's contacts \n2. Supplier's address \n3. Supplier's bank account \n4. Supplier's name");
            int action = Integer.parseInt(reader.readLine());
            while (action < 1 || action > 4) {
                print("Please Enter a valid number (1 to 4)");
                action = Integer.parseInt(reader.readLine());
            }
            switch (action) {
                case 1:
                    editContacts(id);
                    break;
                case 2:
                    editAddress(id);
                    break;
                case 3:
                    editBankAccount(id);
                    break;
                case 4:
                    editName(id);
                    break;
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void editContacts(int id) {
        try {
            print("Choose an action \n1. Add a contact \n2. Delete a contact \n3. Edit contact's email \n4. Edit contact's phone number");
            int action = Integer.parseInt(reader.readLine());
            while (action < 1 || action > 4) {
                print("Please Enter a valid number (1 to 4)");
                action = Integer.parseInt(reader.readLine());
            }
            switch (action) {
                case 1:
                    addContactToSupplier(id);
                    break;
                case 2:
                    deleteContact(id);
                    break;
                case 3:
                    editContactEmail(id);
                    break;
                case 4:
                    editContactPhone(id);
                    break;
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void addContactToSupplier(int id) {
        ContactInformationService c = addContact();
        Message mes = supplierService.addContactsTOSupplier(id, c.getName(), c.getEmail(), c.getPhoneNumber());
        if (mes.errorOccurred())
            print(mes.getErrorMessage());
    }

    private void deleteContact(int id) {
        String phone = getValidPhoneNumber();
        Message mes = supplierService.removeSupplierContact(id, phone);
        if (mes.errorOccurred())
            print(mes.getErrorMessage());
        else {
            print("Contact with email: " + phone + " deleted successfully from supplier with id: " + id);
        }
    }

    private void editContactEmail(int id) {
        try {
            String email = getValidEmail();
            String phone = getValidPhoneNumber();
            print("Please enter the new email ");
            String newEmail = reader.readLine();
            while (!ContactInformationService.isValidEmail(newEmail)) {
                print("Not a valid email, please try again");
                newEmail = reader.readLine();
            }
            Message mes = supplierService.editSupplierContacts(id, email, newEmail, "", phone);
            if (mes.errorOccurred())
                print(mes.getErrorMessage());
        } catch (IOException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private String getValidEmail() {
        try {
            print("Please enter contact's email: ");
            String email = reader.readLine();
            while (!ContactInformationService.isValidEmail(email)) {
                print("Not a valid email. Please enter a legal email address");
                email = reader.readLine();
            }
            return email;
        } catch (IOException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
            return getValidEmail();
        }
    }

    public String getValidPhoneNumber() {
        try {
            print("Please enter contact's phoneNumber: ");
            String phoneNumber = reader.readLine();
            while (!ContactInformationService.validatePhoneNumber(phoneNumber)) {
                print("not a valid phone number. please enter a legal phone number");
                phoneNumber = reader.readLine();
            }
            return phoneNumber;
        } catch (IOException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
            return getValidPhoneNumber();
        }
    }

    private void editContactPhone(int id) {
        try {
            String oldPhone = getValidPhoneNumber();
            print("Please enter the new phone number");
            String newPhone = reader.readLine();
            while (!ContactInformationService.validatePhoneNumber(newPhone)) {
                print("Not a valid phone number, please try again");
                newPhone = reader.readLine();
            }
            Message mes = supplierService.editSupplierContacts(id, "", "", newPhone, oldPhone);
            if (mes.errorOccurred())
                print(mes.getErrorMessage());
        } catch (IOException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void editAddress(int id) {
        try {
            print("Please enter the new address");
            String address = reader.readLine();
            Message mes = supplierService.changeAddress(id, address);
            if (mes.errorOccurred())
                print(mes.getErrorMessage());
            else {
                print("The supplier's address changed successfully for Supplier with id: " + id);
            }
        } catch (IOException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void editBankAccount(int id) {
        try {
            print("Please enter the new bank account number");
            String bankAccount = reader.readLine();
            Message mes = supplierService.changeSupplierBankAccount(id, bankAccount);
            if (mes.errorOccurred())
                print(mes.getErrorMessage());
        } catch (IOException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void editName(int id) {
        try {
            print("Please enter the new name");
            String name = reader.readLine();
            Message mes = supplierService.changeSupplierName(id, name);
            if (mes.errorOccurred())
                print(mes.getErrorMessage());
        } catch (IOException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    //---------------------------------------------- New Functions - Part B --------------------------------------------------------//

    private void startDailyTask() {
        Timer timer = new Timer();
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 14);
        calendar.set(Calendar.MINUTE, 14);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        if (calendar.getTimeInMillis() < System.currentTimeMillis())
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        timer.scheduleAtFixedRate(orderService, calendar.getTime(), TimeUnit.MILLISECONDS.convert(1, TimeUnit.DAYS));
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            timer.cancel();
            Database.disconnect();
        }));
    }

    private void updateProductsInOrder() {
        try {
            print("Please Enter Order ID: ");
            int orderID = Integer.parseInt(reader.readLine());
            boolean correct = false;
            HashMap<Integer, Integer> productsAndAmount = new HashMap<>();
            while (!correct) {
                print("Choose Products And Amounts According To The Format: ProductID:Amount");
                try {
                    String[] arr = reader.readLine().split("\\s*,\\s*");
                    for (String s1 : arr) {
                        String[] val = s1.split(":");
                        int productID = Integer.parseInt(val[0]);
                        int amount = Integer.parseInt(val[1]);
                        productsAndAmount.put(productID, amount);
                    }
                    correct = true;
                } catch (Exception e) {
                    System.out.println("Please Enter Only According To The Format!");
                    productsAndAmount.clear();
                }
            }

            Message message = orderService.updateProductsInOrder(orderID, productsAndAmount);
            if (message.errorOccurred()) System.out.println(message.getErrorMessage());
            else System.out.println("Order With The ID " + message.getSupplierId() + " Has Successfully Been Updated");
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void removeProductsFromOrder() {
        try {
            print("Please Enter Order ID: ");
            int orderID = Integer.parseInt(reader.readLine());
            boolean correct = false;
            ArrayList<Integer> products = new ArrayList<>();
            while (!correct) {
                print("Choose Products To The Format: ProductID_1, ProductID_2, ProductID_3,...");
                try {
                    String[] arr = reader.readLine().split("\\s*,\\s*");
                    for (String s1 : arr)
                        products.add(Integer.parseInt(s1));
                    correct = true;
                } catch (Exception e) {
                    System.out.println("Please Enter Only Product IDs!");
                    products.clear();
                }
            }
            Message message = orderService.removeProductsFromOrder(orderID, products);
            if (message.errorOccurred()) System.out.println(message.getErrorMessage());
            else System.out.println("Order With The ID " + message.getSupplierId() + " Has Successfully Been Updated");
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void createPeriodicOrder() {
        try {
            print("Please Enter Branch ID: ");
            int branchID = Integer.parseInt(reader.readLine());
            print("Please Enter Supplier ID: ");
            int supplierID = Integer.parseInt(reader.readLine());
            print("Please Choose The Periodic Order Day");
            print("1. Monday \n2. Tuesday \n3. Wednesday \n4. Thursday \n5. Friday \n6. Saturday \n7. Sunday");
            int day = Integer.parseInt(reader.readLine());
            while (day < 1 || day > 7) {
                print("Please enter a valid number: 1 to 7");
                day = Integer.parseInt(reader.readLine());
            }
            DayOfWeek fixedDay = DayOfWeek.of(day);
            boolean correct = false;
            HashMap<Integer, Integer> productsAndAmount = new HashMap<>();
            while (!correct) {
                print("Choose Products And Amounts According To The Format: ProductID:Amount");
                try {
                    String[] arr = reader.readLine().split("\\s*,\\s*");
                    for (String s1 : arr) {
                        String[] val = s1.split(":");
                        int productID = Integer.parseInt(val[0]);
                        int amount = Integer.parseInt(val[1]);
                        productsAndAmount.put(productID, amount);
                    }
                    correct = true;
                } catch (Exception e) {
                    System.out.println("Please Enter Products and Amounts Only According To The Format!");
                    productsAndAmount.clear();
                }
            }
            Message message = orderService.createPeriodicOrder(supplierID, branchID, fixedDay, productsAndAmount);
            if (message.errorOccurred()) {
                System.out.println(message.getErrorMessage());
            } else {
                System.out.println("Periodic Order With The ID " + message.getSupplierId() + " Has Successfully Been Created");
                printPeriodicOrderDetails(supplierID, branchID, fixedDay, productsAndAmount);
            }
            menuOrder();
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            print("Invalid input, please try again.");
        }
    }

    private void printPeriodicOrderDetails(int supplierID, int branchID, DayOfWeek fixedDay, HashMap<Integer, Integer> productsAndAmount) {
        System.out.println("Periodic Order Details:");
        System.out.println("Supplier ID: " + supplierID);
        System.out.println("Branch ID: " + branchID);
        System.out.println("Fixed Day: " + fixedDay);
        System.out.println("Products:");
        for (Map.Entry<Integer, Integer> entry : productsAndAmount.entrySet()) {
            System.out.println(" - ProductID: " + entry.getKey() + ", Amount: " + entry.getValue());
        }
        System.out.println();
    }

    private void printPeriodicOrdersForToday() {
        HashMap<Integer, PeriodicOrder> todayOrders = supplierService.getAllPeriodicOrderForToday();
        if (todayOrders.isEmpty()) {
            System.out.println("No periodic orders for today.");
        } else {
            System.out.println("Periodic Orders for Today:");
            for (PeriodicOrder order : todayOrders.values()) {
                System.out.println(order);
            }
        }
    }


}
