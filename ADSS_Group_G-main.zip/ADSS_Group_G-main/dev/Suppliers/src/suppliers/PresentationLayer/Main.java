package suppliers.PresentationLayer;

public class Main {
    public static void main(String[] args) {
        Cli ui = new Cli();
        ui.start();
    }
}