package suppliers.ServiceLayer;

import suppliers.DataStructures.Pair;

import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.HashMap;

public class AgreementService {
    private String paymentType;
    private boolean selfSupply;
    private ArrayList<DayOfWeek> supplyDays;
    private HashMap <Integer, ProductService> supplyingProducts;
    private Pair<Integer,Double> totalAmountDiscountPerOrder;
    private Pair<Double,Double> totalPriceDiscountPerOrder;
    private String supplyMethod;
    private int supplyTime;

    //Constructors
    public AgreementService(String paymentType, boolean selfSupply, ArrayList<DayOfWeek> supplyDays, HashMap <Integer, ProductService> supplyingProduct
            ,String supplyMethod, int supplyTime){
        this.paymentType=paymentType;
        this.selfSupply=selfSupply;
        this.supplyDays=supplyDays;
        this.supplyingProducts = supplyingProduct;
        this.supplyMethod = supplyMethod;
        this.supplyTime = supplyTime;
    }
    public AgreementService(String paymentType, boolean selfSupply, ArrayList<DayOfWeek> supplyDays, HashMap <Integer, ProductService> supplyingProducts
            , Pair<Integer,Double> totalAmountDiscountPerOrder, Pair<Double,Double> totalPriceDiscountPerOrder, String supplyMethod, int supplyTime){
        this.paymentType = paymentType;
        this.selfSupply = selfSupply;
        this.supplyDays = supplyDays;
        this.supplyingProducts = supplyingProducts;
        this.totalAmountDiscountPerOrder = totalAmountDiscountPerOrder;
        this.totalPriceDiscountPerOrder = totalPriceDiscountPerOrder;
        this.supplyMethod = supplyMethod;
        this.supplyTime = supplyTime;
    }

    //Getters
    public String getPaymentType(){
        return paymentType;
    }
    public boolean getSelfSupply(){
        return selfSupply;
    }
    public ArrayList<DayOfWeek> getSupplyDays(){
        return supplyDays;
    }
    public  HashMap <Integer, ProductService> getSupplyingProducts(){
        return supplyingProducts;
    }
    public Pair<Double, Double> getTotalPriceDiscountPerOrder() {
        return totalPriceDiscountPerOrder;
    }
    public Pair<Integer, Double> getTotalAmountDiscountPerOrder() {return totalAmountDiscountPerOrder;}
    public String getSupplyMethod() {return supplyMethod;}
    public int getSupplyTime() {return supplyTime;}
}