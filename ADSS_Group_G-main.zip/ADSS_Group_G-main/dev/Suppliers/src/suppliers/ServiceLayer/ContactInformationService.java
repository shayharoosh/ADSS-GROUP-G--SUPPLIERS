package suppliers.ServiceLayer;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class ContactInformationService {
    private String name;
    private String email;
    private String phoneNumber;

    //Constructors
    public ContactInformationService(String name, String email, String phoneNumber) {
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }
    public ContactInformationService(){}

    //Getters
    public String getName() {
        return name;
    }
    public String getEmail() {return email;}
    public String getPhoneNumber() {
        return phoneNumber;
    }

    //Helper functions
    public static boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        if (email == null) {
            return false;
        }
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public static boolean validatePhoneNumber(String number) {
        String pattern = "^05[02485]-\\d{7}$";
        return Pattern.matches(pattern, number);
    }

}