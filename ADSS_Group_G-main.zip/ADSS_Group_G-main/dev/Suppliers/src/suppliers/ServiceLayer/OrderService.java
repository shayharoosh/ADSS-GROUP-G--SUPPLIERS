package suppliers.ServiceLayer;
import suppliers.DomainLayer.Classes.Order;
import suppliers.DomainLayer.Classes.PeriodicOrder;
import suppliers.DataStructures.Message;

import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TimerTask;


public class OrderService extends TimerTask {
    private final iOrderService orderService;

    public OrderService() {
        orderService = new SupplierService();
    }
    @Override
    public void run()
    {
        System.out.println("Periodic Orders That Executed Today: ");
        for(PeriodicOrder periodicOrder : getAllPeriodicOrderForToday().values())
        {
            Message message = executePeriodicOrder(periodicOrder.getPeriodicOrderID());
            if(message.errorOccurred()) System.out.println(message.getErrorMessage());
            else
            {
                System.out.println("Periodic Order ID: " + periodicOrder.getPeriodicOrderID());
                System.out.println(getOrderByID(message.getSupplierId()));
            }
        }
    }
    public Order getOrderByID(int orderID) { return orderService.getOrderByID(orderID); }
    public HashMap<Integer, PeriodicOrder> getAllPeriodicOrderForToday() { return orderService.getAllPeriodicOrderForToday(); }
    public Message executePeriodicOrder(int periodicOrderID) { return orderService.executePeriodicOrder(periodicOrderID); }
    public Message createPeriodicOrder(int supplierID, int branchID, DayOfWeek fixedDay, HashMap<Integer, Integer> productsAndAmount) { return orderService.createPeriodicOrder(supplierID, branchID, fixedDay, productsAndAmount); }
    public Message updateProductsInOrder(int orderID, HashMap<Integer, Integer> productsToAdd) { return orderService.updateProductsInOrder(orderID, productsToAdd); }
    public Message removeProductsFromOrder(int orderID, ArrayList<Integer> productsToRemove) { return orderService.removeProductsFromOrder(orderID, productsToRemove); }


}
