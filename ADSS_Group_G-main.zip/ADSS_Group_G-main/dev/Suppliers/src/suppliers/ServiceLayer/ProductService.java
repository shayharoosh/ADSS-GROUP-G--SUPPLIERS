package suppliers.ServiceLayer;

import suppliers.DomainLayer.Classes.Product;
import suppliers.DataAccessLayer.Classes.ProductDAO;

import java.util.HashMap;

public class ProductService {
    private String name;
    private int productId;
    private int catalogNumber;
    private double price;
    private int amount;
    private String manufacturer;
    private int expirationDays;
    private Double weight;
    private HashMap<Integer, Double> discountPerAmount;
    private final ProductDAO productDAO; // Add this

    // Constructors
    public ProductService(String name, int productId, int catalogNumber, double price, int amount, HashMap<Integer, Double> discountPerAmount, String manufacturer, int expirationDays, Double weight) {
        this.name = name;
        this.productId = productId;
        this.catalogNumber = catalogNumber;
        this.price = price;
        this.amount = amount;
        this.discountPerAmount = discountPerAmount;
        this.manufacturer = manufacturer;
        this.expirationDays = expirationDays;
        this.weight = weight;
        this.productDAO = new ProductDAO(); // Initialize DAO
    }

    public ProductService(String name, int productId, int catalogNumber, double price, int amount, HashMap<Integer, Double> discountPerAmount, String manufacturer, int expirationDays) {
        this(name, productId, catalogNumber, price, amount, discountPerAmount, manufacturer, expirationDays, null);
    }

    public ProductService() {
        this.productDAO = new ProductDAO(); // Initialize DAO
    }

    // Getters
    public double getPrice() { return price; }
    public int getProductId() { return productId; }
    public int getCatalogNumber() { return catalogNumber; }
    public HashMap<Integer, Double> getDiscountPerAmount() { return discountPerAmount; }
    public int getAmount() { return amount; }
    public String getName() { return name; }
    public String getManufacturer() { return manufacturer; }
    public int getExpirationDays() { return expirationDays; }
    public Double getWeight() { return weight; }

    // New Method to get product by ID and supplier ID
    public Product getProduct(int supplierID, int productID) {
        return productDAO.getProduct(supplierID, productID); // Using the DAO method
    }

}
