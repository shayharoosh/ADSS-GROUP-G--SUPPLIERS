package suppliers.ServiceLayer;
import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.Order;
import suppliers.DomainLayer.Classes.PeriodicOrder;
import suppliers.DomainLayer.Controllers.Facade;
import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.HashMap;


public class SupplierService implements iOrderService{
    private Facade facade;

    //Constructors
    public SupplierService() {
        facade = new Facade();
    }

    //Helper functions
    public Message addSupplier(String name, String address, String bankAccount, AgreementService serviceAgreement, ArrayList<ContactInformationService> contactList) {
        return facade.addSupplier(name, address, bankAccount, serviceAgreement, contactList);
    }
    public Message removeSupplier(int id) {
        return facade.removeSupplier(id);
    }
    public Message changeAddress(int id, String address) {
        return facade.changeAddress(id, address);
    }
    public Message changeSupplierBankAccount(int id, String bankAccount) {
        return facade.changeSupplierBankAccount(id, bankAccount);
    }
    public Message changeSupplierName(int id, String name) {
        return facade.changeSupplierName(id, name);
    }
    public Message addContactsTOSupplier(int id, String name, String email, String phone){
        return facade.addContactsTOSupplier(id, name, email, phone);
    }
    public Message removeSupplierContact(int id, String phone) {return facade.removeSupplierContact(id, phone);}

    public Message editSupplierContacts(int id, String email, String newEmail, String newPhone, String oldPhone) {
        return facade.editSupplierContacts(id, email, newEmail, newPhone, oldPhone);
    }

    public Message addItemToAgreement(int supplierID, String name, int productId, int catalogNumber, double price, int amount, HashMap<Integer, Double> discountPerAmount, double weight, String manufacturer, int expirationDays) {
        return facade.addItemToAgreement(supplierID, name, productId, catalogNumber, price, amount, discountPerAmount, weight, manufacturer, expirationDays);
    }

    public Message removeItemFromAgreement(int supplierID, int itemIdToDelete) {
        return facade.removeItemFromAgreement(supplierID, itemIdToDelete);
    }

    public Message editPaymentMethodAndDeliveryMethodAndDeliveryDays(int supplierId, boolean selfSupply, String paymentMethod, ArrayList<DayOfWeek> days, String supplyMethod, int supplyTime) {
        return facade.editPaymentMethodAndDeliveryMethodAndDeliveryDays(supplierId, selfSupply, paymentMethod, days, supplyMethod, supplyTime);
    }

    public Message editItemCatalogNumber(int supplierId, int productId, int newCatalogNumber) {
        return facade.editItemCatalogNumber(supplierId, productId, newCatalogNumber);
    }

    public void printSuppliers() {
        facade.printSuppliers();
    }

    public Message addDiscounts(int supplierId, int productId, int ammount, double discount) {
        return facade.addDiscounts(supplierId, productId, ammount, discount);
    }

    public Message removeDiscounts(int supplierId, int productId, int ammount, double discount) {
        return facade.removeDiscounts(supplierId, productId, ammount, discount);
    }

    public void printOrder(int supplierId) {
        facade.printOrder(supplierId);
    }
    public void printOrders() {
        facade.printOrders();
    }
    public void printPeriodicOrders() {facade.printPeriodicOrders();}

    public boolean isProductExists(int productId) {
        return facade.isProductExists(productId);
    }


    @Override
    public void createOrderByShortage(int branchId ,HashMap<Integer, Integer> shortage) { facade.createOrderByShortage(branchId ,shortage); }
    @Override
    public HashMap<Integer, Order> getNoneCollectedOrdersForToday(int branchID) { return facade.getNoneCollectedOrdersForToday(branchID); }
    @Override
    public HashMap<Integer, Order> getOrdersFromSupplier(int supplierID) { return facade.getOrdersFromSupplier(supplierID); }
    @Override
    public HashMap<Integer, Order> getOrdersToBranch(int branchID) { return facade.getOrdersToBranch(branchID); }
    @Override
    public HashMap<Integer, Order> getAllOrderForToday() { return facade.getAllOrderForToday(); }
    @Override
    public HashMap<Integer, PeriodicOrder> getAllPeriodicOrders() { return facade.getAllPeriodicOrders(); }

    @Override
    public Message markOrderAsCollected(int orderID) { return facade.markOrderAsCollected(orderID); }
    @Override
    public Message executePeriodicOrder(int periodicOrderID) { return facade.executePeriodicOrder(periodicOrderID); }
    @Override
    public Message createPeriodicOrder(int supplierID, int branchID, DayOfWeek fixedDay, HashMap<Integer, Integer> productsAndAmount) { return facade.createPeriodicOrder(supplierID, branchID, fixedDay, productsAndAmount); }
    @Override
    public Order getOrderByID(int orderID) { return facade.getOrderByID(orderID); }
    @Override
    public HashMap<Integer, PeriodicOrder> getAllPeriodicOrderForToday() { return facade.getAllPeriodicOrderForToday(); }

    @Override
    public Message updateProductsInOrder(int orderID, HashMap<Integer, Integer> productsToAdd) { return facade.updateProductsInOrder(orderID, productsToAdd); }

    @Override
    public Message removeProductsFromOrder(int orderID, ArrayList<Integer> productsToRemove) { return facade.removeProductsFromOrder(orderID, productsToRemove); }

}