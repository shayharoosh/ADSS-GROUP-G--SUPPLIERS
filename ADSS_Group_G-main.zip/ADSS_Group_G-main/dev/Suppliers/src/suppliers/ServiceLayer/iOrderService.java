package suppliers.ServiceLayer;

import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.Order;
import suppliers.DomainLayer.Classes.PeriodicOrder;

import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.HashMap;

public interface iOrderService {
    void createOrderByShortage(int branchId , HashMap<Integer, Integer> shortage);
    HashMap<Integer, Order> getOrdersFromSupplier(int supplierID);
    HashMap<Integer, Order> getOrdersToBranch(int branchID);
    HashMap<Integer, Order> getAllOrderForToday();
    HashMap<Integer, Order> getNoneCollectedOrdersForToday(int branchID);
    Message markOrderAsCollected(int orderID);

    Message executePeriodicOrder(int periodicOrderID);

    Message createPeriodicOrder(int supplierID, int branchID, DayOfWeek fixedDay, HashMap<Integer, Integer> productsAndAmount);
    Order getOrderByID(int orderID);

    HashMap<Integer, PeriodicOrder> getAllPeriodicOrderForToday();
    HashMap<Integer, PeriodicOrder> getAllPeriodicOrders();

    Message updateProductsInOrder(int orderID, HashMap<Integer, Integer> productsToAdd);

    Message removeProductsFromOrder(int orderID, ArrayList<Integer> productsToRemove);
}
