package DatabaseAccessLayer.DAO;

import PresentationLayer.ConfigReader;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public abstract class AbstractDAO<T> {
    private static final String URL = ConfigReader.getProperty("db.url");

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    public static void close(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                // Use logging framework to log the exception
                System.err.println("Failed to close connection: " + e.getMessage());
            }
        }
    }

    public abstract void add(T entity);

    public abstract void remove(T entity);

    public abstract void update(T entity);
}