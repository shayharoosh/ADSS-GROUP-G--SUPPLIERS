package DatabaseAccessLayer.DAO;

import DomainLayer.Classes.Item;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

public class ItemDAO extends AbstractDAO<Item> {
    private static ItemDAO instance = null;

    private ItemDAO() {

    }

    public static ItemDAO getInstance() {
        if (instance == null)
            instance = new ItemDAO();
        return instance;
    }

    // Override method

    @Override
    public void add(Item item) {
        String sql = "INSERT INTO items(id,DateOfArrival,DateOfExpiration,InStore,Defected,DescriptionOfDefect,makat) VALUES(?,?,?,?,?,?,?)";
        Connection conn = null;
        try {
            conn = ItemDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, item.getItemUniqueID());
                pstmt.setString(2, item.getDateOfArrival().toString());
                pstmt.setString(3, item.getExpirationDate().toString());
                pstmt.setBoolean(4, item.getItemLocation());
                pstmt.setBoolean(5, item.isDefect());
                pstmt.setString(6, item.getDefectDescription());
                pstmt.setInt(7, item.getItemMakat());
                pstmt.executeUpdate();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Insert failed, transaction rolled back: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            ItemDAO.close(conn);
        }

    }

    @Override
    public void remove(Item item) {
        String sql = "DELETE FROM items WHERE id=?";
        Connection conn = null;
        try {
            conn = ItemDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, item.getItemUniqueID());
                pstmt.executeUpdate();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Remove failed, transaction rolled back: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            ItemDAO.close(conn);
        }
    }

    @Override
    public void update(Item item) {
        String sql = "Update items set InStore = ?,Defected = ?,DescriptionOfDefect = ? WHERE id=?";
        Connection conn = null;
        try {
            conn = ItemDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setBoolean(1, item.getItemLocation());
                pstmt.setBoolean(2, item.isDefect());
                pstmt.setString(3, item.getDefectDescription());
                pstmt.setString(4, item.getItemUniqueID());
                pstmt.executeUpdate();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Update failed, transaction rolled back: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            ItemDAO.close(conn);
        }
    }


    // More methods


    public void removeItemsByMakat(int makat) {
        String sql = "DELETE FROM items WHERE makat=?";
        Connection conn = null;
        try {
            conn = ItemDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, makat);
                pstmt.executeUpdate();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Remove failed, transaction rolled back: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            ItemDAO.close(conn);
        }
    }

    public HashMap<String, Item> retrieveItemsIDHashMap() {
        String sql = "SELECT * FROM Items";
        Connection conn = null;
        HashMap<String, Item> items = new HashMap<>();
        try {
            conn = ProductDAO.connect();
            try (PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    String id = rs.getString("id");
                    String DateOfArrival = rs.getString("DateOfArrival");
                    String DateOfExpiration = rs.getString("DateOfExpiration");
                    boolean InStore = rs.getBoolean("InStore");
                    boolean Defected = rs.getBoolean("Defected");
                    String Description = rs.getString("DescriptionOfDefect");
                    int makat = rs.getInt("makat");
                    Item temp= new Item(id,makat,LocalDate.parse(DateOfArrival),LocalDate.parse(DateOfExpiration),InStore,Defected,Description);
                    temp.setDefectDescription(Description);
                    temp.setItemLocation(InStore);
                    temp.setDefect(Defected);
                    items.put(id, temp);
                }
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            ItemDAO.close(conn);
        }
        return items;
    }

    public HashMap<Integer, ArrayList<Item>> retrieveItemMakatHashMap() {
        HashMap<String, Item> items = retrieveItemsIDHashMap();
        HashMap<Integer, ArrayList<Item>> makatItems = new HashMap<>();
        for (Item item : items.values()) {
            if (!makatItems.containsKey(item.getItemMakat())) {
                makatItems.put(item.getItemMakat(), new ArrayList<>());
            }
            makatItems.get(item.getItemMakat()).add(item);
        }
        return makatItems;
    }
}
