package DatabaseAccessLayer.DAO;

import DomainLayer.Classes.Order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class OrderDAO extends AbstractDAO<Order> {
    private static OrderDAO instance = null;

    private OrderDAO() {
    }

    public static OrderDAO getInstance() {
        if (instance == null)
            instance = new OrderDAO();
        return instance;
    }

    // Override method

    @Override
    public void add(Order order) {
        String sql = "INSERT INTO orders (order_id,orderDate,orderStatus) VALUES (?,?,?)";
        Connection conn = null;
        try {
            conn = OrderDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, order.getOrderID());
                pstmt.setString(2, order.getOrderDate().toString());
                pstmt.setString(3, order.getStatus().toString());
                pstmt.executeUpdate();
                conn.commit(); // Commit transaction
            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Insert failed, transaction rolled back: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            OrderDAO.close(conn);
        }
    }

    @Override
    public void remove(Order order) {
        String sql = "DELETE FROM orders WHERE order_id=?";
        Connection conn = null;
        try {
            conn = OrderDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, order.getOrderID());
                pstmt.executeUpdate();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Remove failed, transaction rolled back: " + e.getMessage());
            }

        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            OrderDAO.close(conn);
        }
    }

    @Override
    public void update(Order order) {
    }

    // More methods


    public void removeOrder(int orderID) {
        String sql = "DELETE FROM orders WHERE order_id=?";
        Connection conn = null;
        try {
            conn = OrderDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, orderID);
                pstmt.executeUpdate();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Remove failed, transaction rolled back: " + e.getMessage());
            }

        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            OrderDAO.close(conn);
        }
    }

    public void updateOrder(int orderID, Order.OrderStatus status) {
        String sql = "UPDATE orders SET orderStatus=? WHERE order_id=?";
        Connection conn = null;
        try {
            conn = OrderDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, status.toString());
                pstmt.setInt(2, orderID);
                pstmt.executeUpdate();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            OrderDAO.close(conn);
        }
    }

    public ArrayList<String[]> getAllOrders() {
        String sql = "SELECT * FROM orders";
        Connection conn = null;
        ArrayList<String[]> orders = new ArrayList<>();
        try {
            conn = OrderDAO.connect();
            try (PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    String[] order = new String[3];
                    order[0] = rs.getString("order_id");
                    order[1] = rs.getString("orderDate");
                    order[2] = rs.getString("orderStatus");
                    orders.add(order);
                }


            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            OrderDAO.close(conn);
        }
        return orders;
    }

}
