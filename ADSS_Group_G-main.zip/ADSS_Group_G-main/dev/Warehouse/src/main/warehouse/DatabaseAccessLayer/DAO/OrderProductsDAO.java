package DatabaseAccessLayer.DAO;

import DomainLayer.Classes.Order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

public class OrderProductsDAO extends AbstractDAO<Order> {
    private static OrderProductsDAO instance;

    private OrderProductsDAO() {

    }

    public static OrderProductsDAO getInstance() {
        if (instance == null) {
            instance = new OrderProductsDAO();
        }
        return instance;
    }

    // Override methods

    @Override
    public void add(Order order) {
        String sql = "INSERT INTO orders_products (order_id,makat,amount) VALUES (?,?,?)";
        Connection conn = null;
        try {
            conn = OrderProductsDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                HashMap<Integer, Integer> map = new HashMap<>();
                map = order.getMakatToAmount();
                for (Integer key : map.keySet()) {
                    pstmt.setInt(1, order.getOrderID());
                    pstmt.setInt(2, key);
                    pstmt.setInt(3, map.get(key));
                    pstmt.executeUpdate();
                    conn.commit(); // Commit transaction
                }
            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Insert failed, transaction rolled back: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            OrderDAO.close(conn);
        }
    }

    @Override
    public void remove(Order order) {
        String sql = "DELETE FROM orders_products WHERE order_id=?";
        Connection conn = null;
        try {
            conn = OrderProductsDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, order.getOrderID());
                pstmt.executeUpdate();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            OrderProductsDAO.close(conn);
        }
    }

    @Override
    public void update(Order order) {
    }

    // More methods

    public void removeRecord(int orderID) {
        String sql = "DELETE FROM orders_products WHERE order_id=?";
        Connection conn = null;
        try {
            conn = OrderProductsDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, orderID);
                pstmt.executeUpdate();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            OrderProductsDAO.close(conn);
        }
    }

    public HashMap<Integer, HashMap<Integer, Integer>> getAllOrders() {
        String sql = "SELECT * FROM orders_products";
        Connection conn = null;
        HashMap<Integer, HashMap<Integer, Integer>> map = new HashMap<>();
        try {
            conn = OrderProductsDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    map.put(rs.getInt("order_id"), new HashMap<>());
                    map.get(rs.getInt("order_id")).put(rs.getInt("makat"), rs.getInt("amount"));
                }
            }

        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            OrderProductsDAO.close(conn);
        }
        return map;

    }
}
