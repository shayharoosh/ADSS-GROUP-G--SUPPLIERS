package DatabaseAccessLayer.DAO;

import DomainLayer.Classes.Location;
import DomainLayer.Classes.Product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

public class ProductDAO extends AbstractDAO<Product> {
    private static ProductDAO instance = null;

    private ProductDAO() {
    }

    public static ProductDAO getInstance() {
        if (instance == null) {
            instance = new ProductDAO();
        }
        return instance;
    }


    // Override methods

    @Override
    public void add(Product product) {
        String sql = "INSERT INTO products (makat,PName,CostPrice,SellPrice,minAmount,PSize,Manufacturer,Department,rowNumber,AmountInStore,AmountInWarehouse,Discount,subcategory_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
        Connection conn = null;
        try {
            conn = ProductDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, product.getMakat());
                pstmt.setString(2, product.getProductName());
                pstmt.setDouble(3, product.getCostPrice());
                pstmt.setDouble(4, product.getSellPrice());
                pstmt.setInt(5, product.getMinAmount());
                pstmt.setDouble(6, product.getSize());
                pstmt.setString(7, product.getProductManufacturerName());
                pstmt.setString(8, product.getLocation().getDepartment().getName());
                pstmt.setInt(9, product.getLocation().getRow());
                pstmt.setInt(10, product.getAmountInStore());
                pstmt.setInt(11, product.getAmountInWarehouse());
                pstmt.setDouble(12, product.getProductDiscount());
                pstmt.setInt(13, product.getCategoryID());
                pstmt.executeUpdate();
                conn.commit(); // Commit transaction
            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Insert failed, transaction rolled back: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            ProductDAO.close(conn);
        }
    }

    @Override
    public void remove(Product product) {
        String sql = "DELETE FROM products WHERE makat=?";
        Connection conn = null;
        try {
            conn = ProductDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, product.getMakat());
                pstmt.executeUpdate();
                conn.commit();

            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Remove failed, transaction rolled back: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            ProductDAO.close(conn);
        }
    }

    @Override
    public void update(Product product) {
        String sql = "UPDATE products SET minAmount=?,SellPrice=?,AmountInStore=?,AmountInWarehouse=?,discount=?,Department = ?,rowNumber = ? WHERE makat=?";
        Connection conn = null;
        try {
            conn = ProductDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, product.getMinAmount());
                pstmt.setDouble(2, product.getSellPrice());
                pstmt.setInt(3, product.getAmountInStore());
                pstmt.setInt(4, product.getAmountInWarehouse());
                pstmt.setDouble(5, product.getProductDiscount());
                pstmt.setString(6, product.getLocation().getDepartment().getName());
                pstmt.setInt(7, product.getLocation().getRow());
                pstmt.setInt(8, product.getMakat());
                pstmt.executeUpdate();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Update failed, transaction rolled back: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            ProductDAO.close(conn);
        }
    }


    // More methods


    public HashMap<Integer, Product> retrieveProductsByMakat() {
        String sql = "SELECT * FROM products";
        Connection conn = null;
        HashMap<Integer, Product> products = new HashMap<>();
        try {
            conn = ProductDAO.connect();
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    int makat = rs.getInt("makat");
                    String productName = rs.getString("PName");
                    double costPrice = rs.getDouble("CostPrice");
                    double sellPrice = rs.getDouble("SellPrice");
                    int minAmount = rs.getInt("minAmount");
                    double size = rs.getDouble("PSize");
                    String manufacturer = rs.getString("Manufacturer");
                    Location location = new Location(Location.Department.returnDepartment(rs.getString("Department")), rs.getInt("rowNumber"));
                    int AmountInStore = rs.getInt("AmountInStore");
                    int AmountInWarehouse = rs.getInt("AmountInWarehouse");
                    double discount = rs.getDouble("Discount");
                    int CategoryID = rs.getInt("subcategory_id");
                    Product product = new Product(productName, size, makat, CategoryID, manufacturer, costPrice, sellPrice, discount, minAmount);
                    product.setLocation(location);
                    product.setAmountInStore(AmountInStore);
                    product.setAmountInWarehouse(AmountInWarehouse);
                    products.put(makat, product);
                }
            } catch (SQLException e) {
                System.err.println("Retrieval Failed: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            ProductDAO.close(conn);
        }
        return products;
    }


}
