package DatabaseAccessLayer.DAO;

import DomainLayer.Classes.SubCategory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;


public class SubcategoryDAO extends AbstractDAO<SubCategory> {
    private static SubcategoryDAO instance = null;

    private SubcategoryDAO() {
    }

    public static SubcategoryDAO getInstance() {
        if (instance == null) {
            instance = new SubcategoryDAO();
        }
        return instance;
    }

    // Override methods

    @Override
    public void add(SubCategory subCategory) {
        String sql = "INSERT INTO subcategories(id,subcategory_name,category_name,discount) VALUES(?, ?, ?,?)";
        Connection conn = null;
        try {
            conn = SubcategoryDAO.connect();
            conn.setAutoCommit(false); // Start transaction

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, subCategory.getSubCategoryID());
                pstmt.setString(2, subCategory.getSubCategoryName());
                pstmt.setString(3, subCategory.getCategoryName());
                pstmt.setDouble(4, 0);
                pstmt.executeUpdate();
                conn.commit(); // Commit transaction
            } catch (SQLException e) {
                conn.rollback(); // Rollback transaction on error
                System.err.println("Insert failed, transaction rolled back: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            SubcategoryDAO.close(conn);
        }
    }

    @Override
    public void remove(SubCategory subCategory) {
        String sql = "DELETE FROM subcategories WHERE id = ?";
        Connection conn = null;
        try {
            conn = SubcategoryDAO.connect();
            conn.setAutoCommit(false); // Start transaction

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, subCategory.getSubCategoryID());
                pstmt.executeUpdate();
                conn.commit(); // Commit transaction
            } catch (SQLException e) {
                conn.rollback(); // Rollback transaction on error
                System.err.println(" failed, transaction rolled back: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            SubcategoryDAO.close(conn);
        }
    }

    @Override
    public void update(SubCategory subCategory) {
    }


    // More methods

    public HashMap<String, ArrayList<SubCategory>> retrieveCategorySubcategory() throws SQLException {
        HashMap<String, ArrayList<SubCategory>> CategoryToSubcategory = new HashMap<>();
        HashMap<Integer, SubCategory> templist = retrieveSubcategories();
        for (SubCategory subCategory : templist.values()) {
            if (!CategoryToSubcategory.containsKey(subCategory.getCategoryName())) {
                CategoryToSubcategory.put(subCategory.getCategoryName(), new ArrayList<>());
            }
            CategoryToSubcategory.get(subCategory.getCategoryName()).add(subCategory);
        }
        return CategoryToSubcategory;
    }

    public HashMap<Integer, SubCategory> retrieveSubcategories() throws SQLException {
        String sql = "SELECT id, subcategory_name, category_name,start_discount,end_discount,discount FROM subcategories";
        Connection conn = null;
        HashMap<Integer, SubCategory> subcategories = new HashMap<>();
        try {
            conn = SubcategoryDAO.connect();
            try (PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String subcategoryName = rs.getString("subcategory_name");
                    String categoryName = rs.getString("category_name");
                    String startDiscount = rs.getString("start_discount");
                    String endDiscount = rs.getString("end_discount");
                    double discount = rs.getDouble("discount");
                    SubCategory temp = new SubCategory(categoryName, id, subcategoryName);
                    if (startDiscount != null && endDiscount != null) {
                        temp.setDiscount(startDiscount, endDiscount, discount);
                    }
                    subcategories.put(id, temp);
                }
            } catch (SQLException e) {
                conn.rollback(); // Rollback transaction on error
                throw new SQLException("Retrieve operation failed", e);
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            SubcategoryDAO.close(conn);
        }
        return subcategories;
    }

    public void removeSubcategory(int subCategoryID) {
        String sql = "DELETE FROM subcategories WHERE id = ?";
        Connection conn = null;
        try {
            conn = SubcategoryDAO.connect();
            conn.setAutoCommit(false); // Start transaction

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, subCategoryID);
                pstmt.executeUpdate();
                conn.commit(); // Commit transaction
            } catch (SQLException e) {
                conn.rollback(); // Rollback transaction on error
                System.err.println(" failed, transaction rolled back: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            SubcategoryDAO.close(conn);
        }
    }

    public void setDiscount(int subCategoryID, double discount, String startDate, String endDate) {
        String sql = "UPDATE subcategories SET discount = ?, start_discount = ?,end_discount = ? WHERE id = ?";
        Connection conn = null;
        try {
            conn = SubcategoryDAO.connect();
            conn.setAutoCommit(false); // Start transaction

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setDouble(1, discount);
                pstmt.setString(2, startDate);
                pstmt.setString(3, endDate);
                pstmt.setInt(4, subCategoryID);
                pstmt.executeUpdate();
                conn.commit(); // Commit transaction
            } catch (SQLException e) {
                conn.rollback(); // Rollback transaction on error
                System.err.println(" failed, transaction rolled back: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
        } finally {
            SubcategoryDAO.close(conn);
        }
    }


}

