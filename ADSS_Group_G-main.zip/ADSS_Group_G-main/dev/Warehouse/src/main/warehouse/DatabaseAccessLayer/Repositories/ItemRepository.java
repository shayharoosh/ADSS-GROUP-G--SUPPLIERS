package DatabaseAccessLayer.Repositories;

import DatabaseAccessLayer.DAO.ItemDAO;
import DomainLayer.Classes.Item;

import java.util.ArrayList;
import java.util.HashMap;

public class ItemRepository implements Repository<Item> {
    private static ItemRepository instance = null;
    private final ItemDAO itemDAO;

    private ItemRepository() {
        itemDAO = ItemDAO.getInstance();
    }

    public static ItemRepository getInstance() {
        if (instance == null) {
            instance = new ItemRepository();
        }
        return instance;
    }

    @Override
    public void add(Item item) {
        itemDAO.add(item);
    }

    @Override
    public void remove(Item item) {
        itemDAO.remove(item);
    }

    @Override
    public void update(Item item) {
        itemDAO.update(item);
    }

    public void removeItemsByMakat(int makat) {
        itemDAO.removeItemsByMakat(makat);
    }

    public HashMap<String, Item> retrieveItemsIDHashMap() {
        return itemDAO.retrieveItemsIDHashMap();
    }

    public HashMap<Integer, ArrayList<Item>> retrieveItemMakatHashMap() {
        return itemDAO.retrieveItemMakatHashMap();
    }
}
