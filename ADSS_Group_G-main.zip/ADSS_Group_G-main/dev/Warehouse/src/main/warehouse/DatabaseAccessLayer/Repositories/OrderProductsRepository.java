package DatabaseAccessLayer.Repositories;

import DatabaseAccessLayer.DAO.OrderProductsDAO;
import DomainLayer.Classes.Order;

import java.util.HashMap;

public class OrderProductsRepository implements Repository<Order> {
    private static OrderProductsRepository instance = null;
    private final OrderProductsDAO orderProductsDAO;

    private OrderProductsRepository() {
        orderProductsDAO = OrderProductsDAO.getInstance();
    }

    public static OrderProductsRepository getInstance() {
        if (instance == null) {
            instance = new OrderProductsRepository();
        }
        return instance;
    }

    @Override
    public void add(Order order) {
        orderProductsDAO.add(order);
    }

    @Override
    public void remove(Order order) {
        orderProductsDAO.remove(order);
    }

    @Override
    public void update(Order order) {
        orderProductsDAO.update(order);
    }

    public void removeRecord(int orderID) {
        orderProductsDAO.removeRecord(orderID);
    }

    public HashMap<Integer, HashMap<Integer, Integer>> getAllOrders() {
        return orderProductsDAO.getAllOrders();
    }
}
