package DatabaseAccessLayer.Repositories;

import DatabaseAccessLayer.DAO.OrderDAO;
import DomainLayer.Classes.Order;

import java.util.ArrayList;

public class OrderRepository implements Repository<Order> {
    private static OrderRepository instance = null;
    private final OrderDAO orderDAO;

    private OrderRepository() {
        orderDAO = OrderDAO.getInstance();
    }

    public static OrderRepository getInstance() {
        if (instance == null) {
            instance = new OrderRepository();
        }
        return instance;
    }

    @Override
    public void add(Order order) {
        orderDAO.add(order);
    }

    @Override
    public void remove(Order order) {
        orderDAO.remove(order);
    }

    @Override
    public void update(Order order) {
        orderDAO.update(order);
    }


    public void removeOrderByID(int orderID) {
        orderDAO.removeOrder(orderID);
    }

    public void updateOrderStatus(int orderID, Order.OrderStatus status) {
        orderDAO.updateOrder(orderID, status);
    }

    public ArrayList<String[]> getAllOrders() {
        return orderDAO.getAllOrders();
    }
}
