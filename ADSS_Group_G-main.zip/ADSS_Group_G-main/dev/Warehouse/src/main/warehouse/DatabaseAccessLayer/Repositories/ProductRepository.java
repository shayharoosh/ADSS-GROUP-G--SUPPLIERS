package DatabaseAccessLayer.Repositories;

import DatabaseAccessLayer.DAO.ProductDAO;
import DomainLayer.Classes.Product;

import java.util.HashMap;

public class ProductRepository implements Repository<Product> {
    private static ProductRepository instance = null;
    private final ProductDAO productDAO;

    private ProductRepository() {
        productDAO = ProductDAO.getInstance();
    }

    public static ProductRepository getInstance() {
        if (instance == null) {
            instance = new ProductRepository();
        }
        return instance;
    }

    @Override
    public void add(Product product) {
        productDAO.add(product);
    }

    @Override
    public void remove(Product product) {
        productDAO.remove(product);
    }

    @Override
    public void update(Product product) {
        productDAO.update(product);
    }


    public HashMap<Integer, Product> retrieveProductsByMakat() {
        return productDAO.retrieveProductsByMakat();
    }
}
