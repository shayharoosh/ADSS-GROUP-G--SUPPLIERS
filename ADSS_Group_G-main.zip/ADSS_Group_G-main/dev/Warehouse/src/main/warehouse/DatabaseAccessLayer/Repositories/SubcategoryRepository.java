package DatabaseAccessLayer.Repositories;

import DatabaseAccessLayer.DAO.SubcategoryDAO;
import DomainLayer.Classes.SubCategory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

public class SubcategoryRepository implements Repository<SubCategory> {
    private static SubcategoryRepository instance = null;
    private final SubcategoryDAO subcategoryDAO;

    private SubcategoryRepository() {
        subcategoryDAO = SubcategoryDAO.getInstance();
    }

    public static SubcategoryRepository getInstance() {
        if (instance == null) {
            instance = new SubcategoryRepository();
        }
        return instance;
    }

    @Override
    public void add(SubCategory subCategory) {
        subcategoryDAO.add(subCategory);
    }

    @Override
    public void remove(SubCategory subCategory) {
        subcategoryDAO.remove(subCategory);
    }

    @Override
    public void update(SubCategory subCategory) {
        subcategoryDAO.update(subCategory);
    }

    public void removeSubcategory(int subCategoryID) {
        subcategoryDAO.removeSubcategory(subCategoryID);
    }

    public void setDiscount(int subCategoryID, double discount, String startDate, String endDate) {
        subcategoryDAO.setDiscount(subCategoryID, discount, startDate, endDate);
    }

    public HashMap<String, ArrayList<SubCategory>> retrieveCategorySubcategory() throws SQLException {
        return subcategoryDAO.retrieveCategorySubcategory();
    }

    public HashMap<Integer, SubCategory> retrieveSubcategories() throws SQLException {
        return subcategoryDAO.retrieveSubcategories();
    }
}
