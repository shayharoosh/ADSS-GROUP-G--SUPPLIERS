package DomainLayer.Classes;

public abstract class Category {

    protected final String CategoryName;

    /**
     * Constructs a new ProductCategory with the specified category name and category ID.
     *
     * @param CategoryName the name of the category
     */
    public Category(String CategoryName) {
        this.CategoryName = CategoryName.toLowerCase();
    }

    public String getCategoryName() {
        return this.CategoryName;
    }

    @Override
    public String toString() {
        return this.CategoryName;
    }
}



