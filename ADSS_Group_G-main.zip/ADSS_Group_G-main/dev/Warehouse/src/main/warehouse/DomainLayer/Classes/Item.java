package DomainLayer.Classes;

import java.time.LocalDate;


public class Item {
    private final String ItemUniqueID;
    private final int makat; // items makat, gets that value from ProductController
    private final LocalDate expirationDate;
    private final LocalDate dateOfArrival;
    /**
     * @param expirationDate is LocalDate of the date of expiration
     * @param isDefect is a boolean parameter for if item in defected
     * @param inStore boolean for if item in store or Warehouse
     */
    private boolean isDefect;
    private String defectDescription;
    private boolean InStore; //True if where Product location is, else if in warehouse
    private boolean isExpired;
    //private final int barcode; // this is our makat

    /**
     * @param makat          makat to connect item and product
     * @param expirationDate expiration date of product
     */
    public Item(int makat, LocalDate expirationDate) {
        if (makat < 0)
            throw new IllegalArgumentException("Cant Create item, makat doesnt makes sense");
        this.ItemUniqueID = RandomIdGenerator.getInstance().generateRandomId(); // generates random ProductID that hold 25 length String of numbers and words (e.g. 1as1das4a7w..)
        this.expirationDate = expirationDate;
        this.makat = makat;
        this.isDefect = false; // assume product gets in the store defect free
        this.InStore = false;
        this.isExpired = false;
        this.defectDescription = "";
        this.dateOfArrival = LocalDate.now();
    }

    public Item(String id,int makat,LocalDate Arrival,LocalDate Expiration,boolean InStore,boolean Defected,String Description) {
        if (makat < 0)
            throw new IllegalArgumentException("Cant Create item, makat doesnt makes sense");
        this.ItemUniqueID = id; // generates random ProductID that hold 25 length String of numbers and words (e.g. 1as1das4a7w..)
        this.expirationDate = Expiration;
        this.makat = makat;
        this.isDefect = Defected; // assume product gets in the store defect free
        this.InStore = InStore;
        this.isExpired = LocalDate.now().isAfter(Expiration);
        this.defectDescription = Description;
        this.dateOfArrival = Arrival;
    }

    @Override
    public String toString() {
        return String.format("ItemID: %s, Makat: %d, DateOfArrival: %s, ExpirationDate: %s, Defected: %b, DefectDescription: %s, Expired: %b, InStore: %b",
                this.ItemUniqueID, this.makat, this.dateOfArrival, this.expirationDate, this.isDefect, this.defectDescription, this.CheckIfExpired(), this.InStore);
    }


    public boolean isDefect() {
        return this.isDefect;
    }

    public void setDefect(boolean defect) {
        this.isDefect = defect;
    }

    public String getDefectDescription() {
        return this.defectDescription;
    }

    public void setDefectDescription(String defectDescription) {
        this.defectDescription = defectDescription;
    }

    /**
     * @return returns boolean if the ExpirationDate is before today's date
     */
    public boolean CheckIfExpired() {
        isExpired = LocalDate.now().isAfter(this.expirationDate);
        return isExpired;
    }

    public boolean getItemLocation() {
        return InStore;
    }

    public void setItemLocation(boolean inStore) {
        this.InStore = inStore;
    }

    public int getItemMakat() {
        return this.makat;
    }

    public LocalDate getExpirationDate() {
        return this.expirationDate;
    }

    public String getItemUniqueID() {
        return this.ItemUniqueID;
    }

    public LocalDate getDateOfArrival() {
        return this.dateOfArrival;
    }

    public String toCSV() {
        return String.format("%s,%s,%s,%s,%b,%s,%b,%b",
                this.getItemUniqueID(),
                this.getItemMakat(),
                this.getDateOfArrival(),
                this.getExpirationDate(),
                this.isDefect(),
                this.getDefectDescription(),
                this.CheckIfExpired(),
                this.getItemLocation());
    }
}
