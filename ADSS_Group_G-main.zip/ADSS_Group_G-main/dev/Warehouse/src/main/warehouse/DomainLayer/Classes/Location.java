package DomainLayer.Classes;

public class Location {
    private Department department;
    private int row;

    /**
     * @param department Where is it located
     * @param row        the row in the department, special case if department Undetermined then row=-1
     */
    public Location(Department department, int row) {
        if (row == 0 && department != Department.Warehouse || row != 0 && department == Department.Warehouse || row < 0)
            throw new IllegalArgumentException("location isnt valid!");
        this.department = department;
        this.row = row;
    }

    @Override
    public boolean equals(Object object) {
        if (object == null)
            return false;
        if (object.getClass() != this.getClass())
            return false;
        return this.department == ((Location) object).department && this.row == ((Location) object).row;
    }

    @Override
    public String toString() {
        if (this.department == Department.Warehouse)
            return "Warehouse";
        else
            return "Department: " + this.department.name + " " + "Row: " + this.row;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    /**
     * enum of Departments in supermarket, warehouse for when product just arrived or moved back to warehouse
     */
    public enum Department {
        Warehouse("Warehouse"),
        Produce("Produce"),
        Vegetables("Vegetables"),
        Dairy("Dairy"),
        Meat("Meat"),
        Fish("Fish"),
        Deli("Deli"),
        Bakery("Bakery"),
        Frozen("Frozen Foods"),
        Beverages("Beverages"),
        Snacks("Snacks"),
        Household("Household"),
        PersonalCare("PersonalCare"),
        Fruits("Fruits"),
        ;

        private final String name;

        Department(String name) {
            this.name = name;
        }

        public static Department returnDepartment(String name) {
            for (Department department : Department.values()) {
                if (department.getName().equalsIgnoreCase(name)) {
                    return department;
                }
            }
            return null;
        }

        public String getName() {

            return name;
        }
    }

}
