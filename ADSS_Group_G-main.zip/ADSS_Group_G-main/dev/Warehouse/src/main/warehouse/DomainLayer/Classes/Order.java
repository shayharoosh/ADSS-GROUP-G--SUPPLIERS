package DomainLayer.Classes;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Random;

public class Order {
    private final int orderID;
    private final LocalDate orderDate;
    private HashMap<Integer, Integer> makatToAmount;
    private OrderStatus status;

    public Order(HashMap<Integer, Integer> makatToAmount) {
        this.orderID = generateOrderID();
        this.orderDate = LocalDate.now();
        if (makatToAmount == null)
            throw new NullPointerException("makatToAmount is null");
        this.makatToAmount = makatToAmount;
        this.status = OrderStatus.PENDING; // Default status when an order is created
    }

    /**
     * For when creating order from database
     */
    public Order(int orderID, HashMap<Integer, Integer> makatToAmount, LocalDate orderDate, OrderStatus status) {
        if (orderID < 0)
            throw new IllegalArgumentException("orderID is negative!");
        this.orderID = orderID;

        this.orderDate = orderDate;
        if (makatToAmount == null)
            return;
            //throw new NullPointerException("makatToAmount is null"); // TODO : There is single order that got loaded every time we initiate the program.
        // TODO So it throws error every time the program is trying to load itself.
        this.makatToAmount = makatToAmount;
        this.status = status;
    }

    private int generateOrderID() {
        Random random = new Random();
        return random.nextInt(900000) + 100000;
    }

    public int getOrderID() {
        return orderID;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public HashMap<Integer, Integer> getMakatToAmount() {
        return makatToAmount;
    }

    public void setMakatToAmount(HashMap<Integer, Integer> makatToAmount) {
        this.makatToAmount = makatToAmount;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderID=" + orderID +
                ", orderDate=" + orderDate +
                ", makatToAmount=" + makatToAmount +
                ", status=" + status +
                '}';
    }


    public enum OrderStatus {
        DELIVERED,
        PENDING;

        @Override
        public String toString() {
            return this.name(); // Returns the name of the enum constant as a String
        }
    }
}