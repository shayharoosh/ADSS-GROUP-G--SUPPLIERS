package DomainLayer.Classes;

public class Product {


    private final String ProductName;
    private final int makat;
    private final double productSize;
    private final int categoryID;
    double productCostPrice;
    double productSellPrice;
    double productDiscount = 0.0;
    int currentAmountInWarehouse;
    int currentAmountInStore;
    int minAmount; // The client must set minimum amount of that product that he want to be at any given time in his store.
    String productManufacturerName;
    private Location locationInStore;


    /**
     * @param productName             name of product
     * @param productSize             product size
     * @param makat                   makat of product
     * @param categoryID              subcategory id
     * @param productManufacturerName manufacturer name
     * @param productCostPrice        cost price
     * @param productSellPrice        sell price before discount
     * @param discount                discount on sell price
     * @param minAmount               min amount of product
     */
    public Product(String productName, double productSize, int makat, int categoryID,
                   String productManufacturerName, double productCostPrice,
                   double productSellPrice, double discount, int minAmount) {
        if (discount < 0 || discount > 100 || productSize < 0 || productSize == 0 || makat < 0 || categoryID < 0 || productCostPrice < 0 || productSellPrice < 0 || minAmount < 0)
            throw new IllegalArgumentException("Cant create product!,arguments given are bad");
        // In case there is no such product in the system
        this.productSize = productSize;
        this.ProductName = productName.toLowerCase();
        this.makat = makat;
        this.categoryID = categoryID;
        this.currentAmountInWarehouse = 0;
        this.currentAmountInStore = 0;
        this.productCostPrice = productCostPrice;
        this.productDiscount = discount;

        this.productSellPrice = productSellPrice;
        if (this.productDiscount > 0) {
            this.productSellPrice = this.productSellPrice - (productSellPrice * (productDiscount / 100));
        }

        this.minAmount = minAmount;
        this.productManufacturerName = productManufacturerName.toLowerCase();
        this.locationInStore = new Location(Location.Department.Warehouse, 0);


    }

    public String getProductManufacturerName() {
        return this.productManufacturerName;
    }

    public double getProductDiscount() {
        return this.productDiscount;
    }

    public void setProductDiscount(double productDiscount) {
        if (productDiscount > 100 || productDiscount < 0)
            throw new IllegalArgumentException("Cant set productDiscount!,arguments given are bad");
        this.productDiscount = productDiscount;
    }

    public Location getLocation() {
        return this.locationInStore;
    }

    /*
        public double getProductSellPriceAfterDiscount(){
            if(this.productDiscount > 0){
                return this.productSellPrice-(productSellPrice*(productDiscount/100));
            }
            return this.productSellPrice;
        }
        */
    public void setLocation(Location location) {
        this.locationInStore = location;
    }

    public int getCategoryID() {
        return this.categoryID;
    }

    public double getCostPrice() {

        return this.productCostPrice;
    }

    //
    public void setCostPrice(double costPrice) {

        this.productCostPrice = costPrice;
    }

    //
    public int getMinAmount() {

        return minAmount;
    }

    //
    public void setMinAmount(int minAmount) {

        this.minAmount = minAmount;
    }

    //
    public int getAmountInStore() {

        return this.currentAmountInStore;
    }

    //
    public void setAmountInStore(int amountInStore) {

        this.currentAmountInStore = amountInStore;
    }

    //
    public int getAmountInWarehouse() {

        return this.currentAmountInWarehouse;
    }

    //
    public void setAmountInWarehouse(int amountInWarehouse) {

        this.currentAmountInWarehouse = amountInWarehouse;
    }

    //
    public double getSize() {

        return this.productSize;
    }

    //
    public double getSellPrice() {

        return this.productSellPrice;
    }

    //
    public void setSellPrice(double sellPrice) {
        if (sellPrice < 0)
            throw new IllegalArgumentException("Cant set sellPrice!,arguments given are bad");
        this.productSellPrice = sellPrice;
    }

    //
    public int getSubCategory() {

        return this.categoryID;
    }

    //
    public int getMakat() {

        return this.makat;
    }

    //
    public String getProductName() {

        return this.ProductName;
    }

    //
    public int getCurrentTotalAmount() {
        return this.currentAmountInStore + this.currentAmountInWarehouse;
    }

    public void IncreaseCurrentAmount(int amount, boolean Store) {
        if (Store)
            this.currentAmountInStore = this.currentAmountInStore + amount;
        else
            this.currentAmountInWarehouse = this.currentAmountInWarehouse + amount;
    }

    public void DecreaseCurrentAmount(int amount, boolean Store) {
        if (Store) {
            if (this.currentAmountInStore - amount < 0)
                throw new IllegalArgumentException("Cant decrease currentAmount!,arguments given are bad");
            this.currentAmountInStore = this.currentAmountInStore - amount;
            if (getAmountInWarehouse() < minAmount) {
                System.out.println("Alert: Amount Lower Than Min Amount");
            }
        } else {
            if (this.currentAmountInWarehouse - amount < 0)
                throw new IllegalArgumentException("Cant decrease currentAmount!,arguments given are bad");
            this.currentAmountInWarehouse = this.currentAmountInWarehouse - amount;
            if (getAmountInWarehouse() < minAmount) {
                System.out.println("Alert: Amount Lower Than Min Amount");
            }


        }
    }

    /**
     * @param amount  amount to move
     * @param toStore true for store false for warehouse
     */
    //TODO: moves number of items between store and warehouse
    public void MoveItemsBetweenStoreAndWarehouse(int amount, boolean toStore) {
        if (amount > this.getCurrentTotalAmount())
            throw new IllegalArgumentException("cant move more than existing num of products");
        if (toStore) {
            if (this.currentAmountInWarehouse - amount < 0)
                throw new IllegalArgumentException("Cant move such amount from warehouse to store!");
            this.currentAmountInStore = this.currentAmountInStore + amount;
            this.currentAmountInWarehouse = this.currentAmountInWarehouse - amount;
        } else {
            if (this.currentAmountInStore - amount < 0)
                throw new IllegalArgumentException("Cant move such amount from Store to warehouse!");
            this.currentAmountInStore = this.currentAmountInStore - amount;
            this.currentAmountInWarehouse = this.currentAmountInWarehouse + amount;
        }

    }

    @Override
    public boolean equals(Object obj) {
        if (obj.getClass() != this.getClass())
            return false;
        return (this.makat == ((Product) obj).getMakat());
    }

    @Override
    public String toString() {
        return String.format("ProductName: %s, Size: %.3f, Makat: %d, Manufacturar: %s, SubcategoryID: %d, Cost: %.2f, SellingPrice: %.2f(%.2f percent off), AmountInStore: %d, AmountInWarehouse: %d, TotalAmount:%d, MinAmount: %d, Location: " +
                this.getLocation().toString(), this.ProductName, this.productSize, this.makat, this.productManufacturerName, this.categoryID, this.productCostPrice, this.getSellPrice(), this.productDiscount, this.currentAmountInStore, this.currentAmountInWarehouse, this.getCurrentTotalAmount(), this.minAmount);
    }

    public String toCSV() {
        return String.format("%s,%.3f,%d,%s,%d,%.2f,%.2f,%.2f,%d,%d,%d,%d,%s,%d",
                this.getProductName(), this.getSize(), this.getMakat(), this.getProductManufacturerName(),
                this.getCategoryID(), this.getCostPrice(), this.getSellPrice(),
                this.getProductDiscount(), this.getAmountInStore(), this.getAmountInWarehouse(),
                this.getCurrentTotalAmount(), this.getMinAmount(), this.getLocation().getDepartment().getName(), this.getLocation().getRow());
    }

    public String toCSV(boolean deficiencies) {
        if (deficiencies) {
            return String.format("%s,%d,%s,%d,%d",
                    this.getProductName(), this.getMakat(), this.getProductManufacturerName(),
                    this.getAmountInWarehouse(), this.getMinAmount());
        }
        return toCSV();
    }

    public String toCSVonDeficiencies() {
        int toOrder = this.getMinAmount() * 3;
        return String.format("%s,%d,%s,%d,%d,%d",
                this.getProductName(), this.getMakat(), this.getProductManufacturerName(),
                this.getCurrentTotalAmount(), this.getMinAmount(), toOrder);
    }

//    private final String ProductName;
//    private final int makat;
//    private int categoryID;
//    double productCostPrice;
//    double productSellPrice;
//    double productDiscount;
//    int currentAmountInWarehouse;
//    int currentAmountInStore;
//    int minAmount; // The client must set minimum amount of that product that he want to be at any given time in his store.
//    private final double productSize;
//    String productManufacturerName;
//    private Location locationInStore;
//    private int maxAmountTotal;
}
