package DomainLayer.Classes;

import java.security.SecureRandom;

public class RandomIdGenerator {

    // Define the characters to be used in the ID
    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final int ID_LENGTH = 9;
    private static final SecureRandom RANDOM = new SecureRandom();

    // Singleton instance
    private static final RandomIdGenerator instance = new RandomIdGenerator();

    // Private constructor to prevent instantiation
    private RandomIdGenerator() {
    }

    /**
     * Gets the singleton instance of the RandomIdGenerator.
     *
     * @return the singleton instance
     */
    public static RandomIdGenerator getInstance() {
        return instance;
    }

    /**
     * Generates a random ID of length 4 consisting of numbers and letters.
     *
     * @return the generated random ID
     */
    public String generateRandomId() {
        StringBuilder id = new StringBuilder(ID_LENGTH);
        for (int i = 0; i < ID_LENGTH; i++) {
            int index = RANDOM.nextInt(CHARACTERS.length());
            id.append(CHARACTERS.charAt(index));
        }
        return id.toString();
    }
}
