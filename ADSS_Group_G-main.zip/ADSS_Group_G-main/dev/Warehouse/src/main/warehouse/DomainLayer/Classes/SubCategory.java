package DomainLayer.Classes;

import java.time.LocalDate;
import java.util.Objects;

public class SubCategory extends Category {
    private final String subCategoryName;
    private final int subCategoryID;
    private LocalDate startDiscount;
    private LocalDate endDiscount;
    private double discount = 0;


    /**
     * Constructs a new ProductSubCategory with the specified category name, category ID,
     * subcategory name, and subcategory size.
     *
     * @param CategoryName    the name of the category
     * @param subCategoryName the name of the subcategory
     */
    public SubCategory(String CategoryName, int subCategoryID, String subCategoryName) {
        super(CategoryName);
        this.subCategoryName = subCategoryName.toLowerCase();
        this.subCategoryID = subCategoryID;
        startDiscount = null;
        endDiscount = null;
        discount = 0.0;
    }

    public void setDiscount(String start, String end, double discount) {
        try {
            LocalDate startDiscount = LocalDate.parse(start);
            LocalDate endDiscount = LocalDate.parse(end);
            this.discount = discount;
            this.startDiscount = startDiscount;
            this.endDiscount = endDiscount;
        } catch (Exception e) {
            System.out.println("Error in date format");
        }
    }

    public double getDiscount() {
        if (discount == 0)
            return 0;
        LocalDate now = LocalDate.now();
        if (now.isAfter(startDiscount) && now.isBefore(endDiscount))
            return discount;
        else
            return 0;

    }

    public String[] getSubcategorieDiscountDates() {
        String[] dates = new String[2];
        dates[0] = startDiscount.toString();
        dates[1] = endDiscount.toString();
        return dates;
    }

    /**
     * Returns the name of the subcategory.
     *
     * @return the subcategory name
     */
    public String getSubCategoryName() {

        return this.subCategoryName;
    }

    public int getSubCategoryID() {
        return this.subCategoryID;
    }

    @Override
    public boolean equals(Object object) {
        if (object == null)
            return false;
        if (this.getClass() != object.getClass())
            return false;
        return this.subCategoryID == ((SubCategory) object).subCategoryID && Objects.equals(this.subCategoryName, ((SubCategory) object).subCategoryName);
    }

    @Override
    public String toString() {
        return String.format("Subcategory ID: %d, Subcategory name: %s, Category Name: %s, Discount Start Date: %s, Discount End Date: %s, Discount: %.3f", this.subCategoryID, this.subCategoryName, this.CategoryName, this.startDiscount, this.endDiscount, this.discount);
    }


}
