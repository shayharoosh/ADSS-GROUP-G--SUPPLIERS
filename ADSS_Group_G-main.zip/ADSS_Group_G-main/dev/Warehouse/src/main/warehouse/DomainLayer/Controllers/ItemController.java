package DomainLayer.Controllers;

import DatabaseAccessLayer.Repositories.ItemRepository;
import DomainLayer.Classes.Item;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

public class ItemController {
    private static ItemController instance = null;
    private final ItemRepository itemRepository;
    private HashMap<String, Item> itemById;
    private HashMap<Integer, ArrayList<Item>> itemsByMakat;


    private ItemController() {
        itemsByMakat = new HashMap<>();
        itemById = new HashMap<>();
        itemRepository = ItemRepository.getInstance();
    }

    public static ItemController getInstance() {
        if (instance == null) {
            instance = new ItemController();
        }
        return instance;
    }

    public void loadData() {
        itemById = itemRepository.retrieveItemsIDHashMap();
        itemsByMakat = itemRepository.retrieveItemMakatHashMap();
    }

    /**
     * @param makat          to connect between item and product
     * @param expirationDate of item
     * @return returns the item created, used for some functionality.
     */
    public Item addItemAndReturnIt(int makat, LocalDate expirationDate) {
        if (makat < 0)
            throw new IllegalArgumentException("Cant add item,Makat Invalid");
        Item TempItem = new Item(makat, expirationDate);
        itemById.put(TempItem.getItemUniqueID(), TempItem);
        if (!itemsByMakat.containsKey(makat)) {
            itemsByMakat.put(makat, new ArrayList<>());
        }
        itemsByMakat.get(makat).add(TempItem);
        itemRepository.add(TempItem);
        return TempItem;
    }

    public Item getItemByID(String itemId) {
        Item tempItem = itemById.get(itemId);
        if (tempItem == null)
            throw new IllegalArgumentException("This Item Doesnt Exist");
        return tempItem;
    }

    public ArrayList<Item> getItemsByMakat(int makat) {
        ArrayList<Item> list = itemsByMakat.get(makat);
        if (list == null)
            throw new IllegalArgumentException("This Makat Doesnt Exists");
        if (list.isEmpty())
            throw new IllegalArgumentException("no items from this makat");
        return list;
    }

    public int getItemMakatByID(String itemId) {
        Item tempItem = itemById.get(itemId);
        if (tempItem == null)
            throw new IllegalArgumentException("This Item Doesnt Exist");
        return tempItem.getItemMakat();
    }

    public void removeSpecificItem(String itemId) {
        Item tempItem = itemById.get(itemId);
        if (tempItem == null)
            throw new IllegalArgumentException("This item doesnt exist!");
        itemById.remove(itemId);
        itemsByMakat.get(tempItem.getItemMakat()).remove(tempItem);
        itemRepository.remove(tempItem);
    }

    public void removeItemsByProductID(int makat) {
        if (itemsByMakat.get(makat) == null)
            throw new IllegalArgumentException("This Makat Doesnt Exist");
        itemsByMakat.get(makat).clear();
        itemRepository.removeItemsByMakat(makat);
    }

    public ArrayList<Item> getAllItems() {
        return new ArrayList<Item>(itemById.values());
    }

    public boolean isItemExpired(String itemID) {
        Item tempItem = itemById.get(itemID);
        if (tempItem == null)
            throw new IllegalArgumentException("This item doesnt exist!");
        if (tempItem.CheckIfExpired())
            itemRepository.update(tempItem);
        return tempItem.CheckIfExpired();
    }

    public ArrayList<Item> getExpiredItemsList() {
        ArrayList<Item> TempList = new ArrayList<>();
        for (Item item : itemById.values()) {
            if (isItemExpired(item.getItemUniqueID()))
                TempList.add(item);
        }
        return TempList;
    }

    public ArrayList<Item> getExpiredItemsList(int makat) {
        ArrayList<Item> TempList = new ArrayList<>();
        for (Item item : itemById.values()) {
            if (isItemExpired(item.getItemUniqueID()) && item.getItemMakat() == makat)
                TempList.add(item);
        }
        return TempList;
    }

    public ArrayList<Item> getDefectedItemsList() {
        ArrayList<Item> TempList = new ArrayList<>();
        for (Item item : itemById.values()) {
            if (isItemDefected(item.getItemUniqueID()))
                TempList.add(item);
        }
        return TempList;
    }

    public ArrayList<Item> getDefectedItemsList(int makat) {
        ArrayList<Item> TempList = new ArrayList<>();
        for (Item item : itemById.values()) {
            if (isItemDefected(item.getItemUniqueID()) && item.getItemMakat() == makat)
                TempList.add(item);
        }
        return TempList;
    }

    public boolean isItemInStore(String itemID) {
        Item tempItem = itemById.get(itemID);
        if (tempItem == null)
            throw new IllegalArgumentException("This item doesnt exist!");
        return tempItem.getItemLocation();
    }

    public void setItemLocation(String itemID, boolean inStore) {
        Item tempItem = itemById.get(itemID);
        if (tempItem == null)
            throw new IllegalArgumentException("This item doesnt exist!");
        tempItem.setItemLocation(inStore);
        itemRepository.update(tempItem);
    }

    public int getItemMakat(String itemID) {
        Item tempItem = itemById.get(itemID);
        if (tempItem == null)
            throw new IllegalArgumentException("This item doesnt exist!");
        return tempItem.getItemMakat();
    }

    public boolean isItemDefected(String itemID) {
        Item tempItem = itemById.get(itemID);
        if (tempItem == null)
            throw new IllegalArgumentException("This item doesnt exist!");
        return tempItem.isDefect();
    }

    public void setItemDefect(String itemID, boolean isDefect, String description) {
        Item tempItem = itemById.get(itemID);
        if (tempItem == null)
            throw new IllegalArgumentException("This item doesnt exist!");
        tempItem.setDefect(isDefect);
        tempItem.setDefectDescription(description);
        itemRepository.update(tempItem);
    }


    public void ClearAllItems() {
        itemById.clear();
        itemsByMakat.clear();
    }


}