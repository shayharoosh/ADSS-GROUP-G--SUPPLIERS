package DomainLayer.Controllers;

import DatabaseAccessLayer.Repositories.OrderProductsRepository;
import DatabaseAccessLayer.Repositories.OrderRepository;
import DomainLayer.Classes.Order;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

public class OrderController {
    private static OrderController instance = null;
    private final HashMap<Integer, Order> ordersById;
    private final OrderRepository orderRepository;
    private final OrderProductsRepository orderProductsRepository;

    private OrderController() {
        ordersById = new HashMap<>();
        orderRepository = OrderRepository.getInstance();
        orderProductsRepository = OrderProductsRepository.getInstance();
    }

    public static OrderController getInstance() {
        if (instance == null) {
            instance = new OrderController();
        }
        return instance;
    }

    public void loadData() {
        ArrayList<String[]> orders = orderRepository.getAllOrders();
        HashMap<Integer, HashMap<Integer, Integer>> OrderProduct = orderProductsRepository.getAllOrders();
        for (String[] orderArray : orders) {
            Order order = new Order(Integer.parseInt(orderArray[0]), OrderProduct.get(Integer.parseInt(orderArray[0])), LocalDate.parse(orderArray[1]), Order.OrderStatus.valueOf(orderArray[2]));
            ordersById.put(order.getOrderID(), order);
        }
    }

    public Order addOrder(HashMap<Integer, Integer> makatToAmount) {
        Order order = new Order(makatToAmount);
        ordersById.put(order.getOrderID(), order);
        orderRepository.add(order);
        orderProductsRepository.add(order);
        return order;
    }


    public void addDeficienciesOrder(HashMap<Integer, Integer> makatToAmount) {
        if (makatToAmount == null) {
            throw new NullPointerException("makatToAmount is null");
        }
        Order order = new Order(makatToAmount);
        ordersById.put(order.getOrderID(), order);
        orderRepository.add(order);
        orderProductsRepository.add(order);
    }

    public Order getOrderById(int orderID) {
        Order order = ordersById.get(orderID);
        if (order == null) {
            throw new IllegalArgumentException("Order with ID " + orderID + " does not exist.");
        }
        return order;
    }

    public void removeOrderById(int orderID) {
        if (!ordersById.containsKey(orderID))
            throw new IllegalArgumentException("Order with ID " + orderID + " does not exist.");
        ordersById.remove(orderID);
        orderRepository.removeOrderByID(orderID);
        orderProductsRepository.removeRecord(orderID);
    }

    public void updateOrderStatus(int orderID, Order.OrderStatus status) {
        Order order = ordersById.get(orderID);
        if (order == null) {
            throw new IllegalArgumentException("Order with ID " + orderID + " does not exist.");
        }
        if(order.getStatus()==status)
            throw new RuntimeException("Order already has this status");
        order.setStatus(status);
        orderRepository.updateOrderStatus(orderID, status);
    }

    public ArrayList<Order> getAllOrders() {
        return new ArrayList<>(ordersById.values());
    }

    public ArrayList<Order> getOrdersByStatus(Order.OrderStatus status) {
        ArrayList<Order> orders = new ArrayList<>();
        for (Order order : ordersById.values()) {
            if (order.getStatus() == status) {
                orders.add(order);
            }
        }
        return orders;
    }

    public void clearAllOrders() {
        ordersById.clear();
    }


}
