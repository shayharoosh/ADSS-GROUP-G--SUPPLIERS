package DomainLayer.Controllers;

import DatabaseAccessLayer.DAO.ProductDAO;
import DatabaseAccessLayer.Repositories.ProductRepository;
import DomainLayer.Classes.Location;
import DomainLayer.Classes.Product;

import java.util.ArrayList;
import java.util.HashMap;

public class ProductController {
    //TODO CHECK FOR PRODUCT LOCATION WHEN ADDING
    private static ProductController instance = null;
    private HashMap<Integer, Product> ProductByMakat;
    private ProductDAO productDAO;
    private ProductRepository productRepository;

    private ProductController() {
        ProductByMakat = new HashMap<>();
        productDAO = ProductDAO.getInstance();
        productRepository = ProductRepository.getInstance();
    }

    public static ProductController getInstance() {
        if (instance == null) {
            instance = new ProductController();
        }
        return instance;
    }
    public void loadData() {
        ProductByMakat=productDAO.retrieveProductsByMakat();
    }


    // return the product by its key (e.g., makat, else null if its not in the hash TODO maybe throw some message to the user about it)
    public Product getProductByMakat(int makat) {
        Product TempProduct=ProductByMakat.get(makat);
            if (TempProduct == null)
                throw new IllegalArgumentException("Product doesnt exists!");
        return TempProduct;
    }

    // TODO: removed product sell price, need to be calculated according to the discount
    public void addProduct(String productName, double productSize, int makat, int categoryID, String productManufacturerName, double productCostPrice,double productSellPrice ,double discount, int minAmount ) {
        Product tempProduct=ProductByMakat.get(makat);
        if(tempProduct!=null)
            throw new IllegalArgumentException("Product already exists");
        tempProduct=new Product(productName,productSize,makat,categoryID,productManufacturerName,productCostPrice,productSellPrice,discount,minAmount);
        ProductByMakat.put(makat,tempProduct);
        productRepository.add(tempProduct);
    }
    public void removeProduct(int makat){
        Product TempProduct=ProductByMakat.get(makat);
        if(TempProduct==null)
            throw new IllegalArgumentException("Product doesnt exists!");
        ProductByMakat.remove(makat);
        productRepository.remove(TempProduct);
    }
    public void removeProductBySubcategoryID(int subcategoryID){
        for(Product tempProduct:ProductByMakat.values()){
            if(tempProduct.getCategoryID()==subcategoryID) {
                ProductByMakat.remove(tempProduct.getMakat());
                productRepository.remove(tempProduct);
            }

        }
    }

    public void setLocationOfProduct(int makat, String department,int row){
        Product TempProduct=ProductByMakat.get(makat);
        if(TempProduct==null)
            throw new IllegalArgumentException("Product doesnt exists!");
        if(TempProduct.getLocation().getDepartment().getName()==department&&TempProduct.getLocation().getRow()==row)
            throw new IllegalArgumentException("Product Already at that location!");
        Location location=new Location(Location.Department.returnDepartment(department),row);
        TempProduct.setLocation(location);
        productRepository.update(TempProduct);
    }
    public void setProdcutSellingPrice(int makat,double sellingPrice){
        Product TempProduct=ProductByMakat.get(makat);
        if(TempProduct==null)
            throw new IllegalArgumentException("There is not such product!");
        TempProduct.setSellPrice(sellingPrice);
        productRepository.update(TempProduct);
    }
    public void setProductDiscount(int makat,double DiscountPrice){
        Product TempProduct=ProductByMakat.get(makat);
        if(TempProduct==null)
            throw new IllegalArgumentException("There is not such product!");
        TempProduct.setProductDiscount(DiscountPrice);
        productRepository.update(TempProduct);
    }
    public void setProductDiscountBySubCategoryID(int subCategoryID,double discount){
        for(Product tempProduct:ProductByMakat.values()){
            if(tempProduct.getCategoryID()==subCategoryID){
                setProductDiscount(tempProduct.getMakat(),discount);
            }
        }
    }
    public Product setAmountInWarehouse(int makat,int amount){
        Product TempProduct=ProductByMakat.get(makat);
        if(TempProduct==null)
            throw new IllegalArgumentException("There is not such product!");
        TempProduct.setAmountInWarehouse(amount);
        if(TempProduct.getAmountInWarehouse()<TempProduct.getAmountInWarehouse())
            return TempProduct;
        return null;
    }

    public ArrayList<Product> getProductsInWarehouse(){
        ArrayList<Product> productsInWarehouse=new ArrayList<>();
        for(Product product:ProductByMakat.values()) {
            if(product.getLocation().getDepartment()== Location.Department.Warehouse)
                productsInWarehouse.add(product);
        }
        return productsInWarehouse;
    }
    public ArrayList<Product> getAllProducts(){
        return new ArrayList<>(ProductByMakat.values());
    }
    public ArrayList<Product> getProductsByCategory(int categoryID){
        ArrayList<Product> productsByCategory=new ArrayList<>();
        for(Product product:ProductByMakat.values()) {
            if(product.getCategoryID()==categoryID)
                productsByCategory.add(product);
        }
        return productsByCategory;
    }
    public int getProductMinAmount(int makat){
        Product product=ProductByMakat.get(makat);
        if (product==null)
            throw new IllegalArgumentException("There is not such product!");
        return product.getMinAmount();
    }

    public void IncreaseProductCurrentAmount(int makat,int amount,boolean Store){
        Product TempProduct=ProductByMakat.get(makat);
        if(TempProduct==null)
            throw new IllegalArgumentException("Product doesnt exists!");
        TempProduct.IncreaseCurrentAmount(amount,Store);
        productRepository.update(TempProduct);
    }
    public void DecreaseProductCurrentAmount(int makat,int amount,boolean Store){
        Product TempProduct=ProductByMakat.get(makat);
        if(TempProduct==null)
            throw new IllegalArgumentException("Product doesnt exists!");
        TempProduct.DecreaseCurrentAmount(amount,Store);
        productRepository.update(TempProduct);
    }
    public void MoveAmountBetweenStoreAndWarehouse(int makat,int amount,boolean toStore){
        Product TempProduct=ProductByMakat.get(makat);
        if(TempProduct==null)
            throw new IllegalArgumentException("Product doesnt exists!");
        TempProduct.MoveItemsBetweenStoreAndWarehouse(amount,toStore);
        productRepository.update(TempProduct);

    }

    public void ClearAllProducts(){
        this.ProductByMakat.clear();
    }



}




