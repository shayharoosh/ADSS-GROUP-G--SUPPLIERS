package DomainLayer.Controllers;

import DatabaseAccessLayer.Repositories.SubcategoryRepository;
import DomainLayer.Classes.SubCategory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SubCategoryController {
    private static SubCategoryController instance = null;
    private final SubcategoryRepository subcategoryRepository;
    private Map<String, ArrayList<SubCategory>> CategoryToSubCategoryList;
    private Map<Integer, SubCategory> subCategoryByIDs;

    // Private constructor to prevent instantiation
    private SubCategoryController() {
        subCategoryByIDs = new HashMap<>();
        CategoryToSubCategoryList = new HashMap<>();
        subcategoryRepository = SubcategoryRepository.getInstance();
    }

    // Public method to get the singleton instance
    public static SubCategoryController getInstance() {
        if (instance == null)
            instance = new SubCategoryController();
        return instance;
    }

    public void loadData() throws SQLException {
        subCategoryByIDs = subcategoryRepository.retrieveSubcategories();
        CategoryToSubCategoryList = subcategoryRepository.retrieveCategorySubcategory();
    }

    // Method to add a ProductSubCategory
    public void addSubCategory(String CategoryName, int subCategoryID, String subCategoryName) {
        if (subCategoryID < 0)
            throw new IllegalArgumentException("ID Cant be lower than 0!");
        if (this.subCategoryByIDs.containsKey(subCategoryID))
            throw new IllegalArgumentException("Subcategory already exists!");
        SubCategory subCategory = new SubCategory(CategoryName.toLowerCase(), subCategoryID, subCategoryName.toLowerCase());
        subcategoryRepository.add(subCategory);

        if (!CategoryToSubCategoryList.containsKey(CategoryName)) {
            ArrayList<SubCategory> subCategoryList = new ArrayList<>();
            CategoryToSubCategoryList.put(CategoryName.toLowerCase(), subCategoryList);
        }
        CategoryToSubCategoryList.get(CategoryName.toLowerCase()).add(subCategory);
        subCategoryByIDs.put(subCategoryID, subCategory);

    }

    // Method to get a ProductSubCategory by id
    public SubCategory getSubCategory(int id) {
        if (subCategoryByIDs == null)
            throw new IllegalArgumentException("No Subcategories Yet!");
        return subCategoryByIDs.get(id);
    }

    public SubCategory getSubCategory(String CategoryName) {
        for (SubCategory subCategory : subCategoryByIDs.values()) {
            if (subCategory.getSubCategoryName().equalsIgnoreCase(CategoryName)) {
                return subCategory;
            }
        }
        return null;
    }

    public ArrayList<SubCategory> getSubcategories(ArrayList<Integer> subCategoryIDs) {
        ArrayList<SubCategory> subCategoryList = new ArrayList<>();
        for (Integer subCategoryID : subCategoryIDs) {
            subCategoryList.add(subCategoryByIDs.get(subCategoryID));
        }
        return subCategoryList;
    }

    // Method to remove a ProductSubCategory by id
    public void removeSubCategory(int id) {
        if (subCategoryByIDs == null)
            throw new IllegalArgumentException("No Subcategories Yet!");
        SubCategory temp = subCategoryByIDs.get(id);
        subCategoryByIDs.remove(id);
        CategoryToSubCategoryList.get(temp.getCategoryName()).remove(temp);
        subcategoryRepository.removeSubcategory(id);
    }

    // Method to get all ProductSubCategories
    public ArrayList<SubCategory> getAllSubCategoriesOfCategory(String categoryName) {

        return CategoryToSubCategoryList.get(categoryName.toLowerCase());
    }

    public ArrayList<SubCategory> getTotalSubcategories() {
        ArrayList<SubCategory> ListOfSubcategories = new ArrayList<>();
        for (String temp : CategoryToSubCategoryList.keySet())
            ListOfSubcategories.addAll(CategoryToSubCategoryList.get(temp));
        return ListOfSubcategories;
    }

    public void setDiscount(int id, String start_date, String end_date, double discount) {
        if (subCategoryByIDs == null)
            throw new IllegalArgumentException("No Subcategories Yet!");
        SubCategory temp = subCategoryByIDs.get(id);
        temp.setDiscount(start_date, end_date, discount);
        subcategoryRepository.setDiscount(id, discount, start_date, end_date);
    }

    public void ClearAllSubcategories() {
        this.subCategoryByIDs.clear();
        this.CategoryToSubCategoryList.clear();
    }
}

