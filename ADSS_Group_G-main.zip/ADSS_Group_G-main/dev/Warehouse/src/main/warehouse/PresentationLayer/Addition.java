package PresentationLayer;

import ServiceLayer.ActionsServices.AdditionService;

import java.time.LocalDate;
import java.util.HashMap;

public class Addition extends UserInterface {
    private final AdditionService additionService = AdditionService.getInstance();

    @Override
    public void run() {
        PL();
        System.out.println("What would you like to add? (Cant add products without subcategories, cant " +
                "add items without products)");
        System.out.println("1.Add Subcategory");
        System.out.println("2.Add Product");
        System.out.println("3.Add Items");
        System.out.println("4.Add New Order");
        System.out.println("5.Return");
        PL();

        choice = sc.nextInt();
        switch (choice) {
            case 1:
                addSubcategory();
                break;
            case 2:
                addProduct();
                break;
            case 3:
                addItems();
                break;
            case 4:
                addNewOrder();
                break;
            case 5:
                break;

        }
    }

    private void PL() {
        System.out.println("--------------------------------------------------------------------");
    }

    private void addSubcategory() {
        sc.nextLine(); //So it will eat the \n from previous nextInt
        System.out.println("Enter Category Name");
        String CategoryName = sc.nextLine();
        System.out.println("Subcategory ID");
        int ID = sc.nextInt();
        sc.nextLine(); //So it will eat the \n from previous nextInt
        System.out.println("Subcategory Name");
        String subcategoryName = sc.nextLine();
        try {
            additionService.addSubcategory(CategoryName, ID, subcategoryName);
            System.out.println("Subcategory added successfully");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Would you like to try again?");
            System.out.println("1 For Y 2 For N");
            choice = sc.nextInt();
            if (choice == 1)
                addSubcategory();
        }
        this.run();
    }

    private void addProduct() {
        sc.nextLine();
        System.out.println("Enter Product Name");
        String ProductName = sc.nextLine();
        System.out.println("Enter Size (liquid in liter else in kg)");
        double Size = sc.nextDouble();
        System.out.println("Enter Makat");
        int makat = sc.nextInt();
        System.out.println("Enter SubcategoryID");
        int categoryID = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter manufacturer");
        String manufacturer = sc.nextLine();
        System.out.println("Enter Cost Price");
        double costPrice = sc.nextDouble();
        System.out.println("Enter Selling Price");
        double sellPrice = sc.nextDouble();
        System.out.println("Enter discount in percentage if wanted (e.g., 10, 7.5, 22.5), else press 0");
        double discount = sc.nextDouble();
        System.out.println("Enter min amount of product");
        int minamount = sc.nextInt();
        sc.nextLine();

        try {
            additionService.addProduct(ProductName, Size, makat, categoryID, manufacturer, costPrice, sellPrice, discount, minamount);
            System.out.println("Product added successfully");
            System.out.println("Would you like to add items from that product ? (1 = Yes, 0 = No)");
            int ans = sc.nextInt();
            if (ans == 1) {
                addItems(makat);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Would you like to try again?");
            System.out.println("1 For Y 2 For N");
            choice = sc.nextInt();
            if (choice == 1)
                addProduct();
        }
        this.run();

    }

    private void addItems(int makat) {
        System.out.println("amount of items added?");
        int amount = sc.nextInt();
        sc.nextLine();
        System.out.println("what is the expiration date of the items?");
        System.out.println("Year");
        String expirationDateYear = sc.nextLine();
        System.out.println("Month");
        String expirationDateMonth = sc.nextLine();
        System.out.println("Day");
        String expirationDateDay = sc.nextLine();
        PL();
        System.out.println("Would you like to move the items directly to the store? (1 = Yes, 0 = No)");
        choice = sc.nextInt();
        try {
            additionService.addItem(amount, makat, LocalDate.parse(expirationDateYear + "-" + expirationDateMonth + "-" + expirationDateDay), choice == 1);
            System.out.println("Items added successfully");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Would you like to try again?");
            System.out.println("1 For Y 2 For N");
            choice = sc.nextInt();
            addItems(makat);

        }
    }


    private void addItems() {
        System.out.println("What is the makat of the items?");
        int makat = sc.nextInt();
        System.out.println("amount of items added?");
        int amount = sc.nextInt();
        sc.nextLine();
        System.out.println("what is the expiration date of the items?");
        System.out.println("Year");
        String expirationDateYear = sc.nextLine();
        System.out.println("Month");
        String expirationDateMonth = sc.nextLine();
        System.out.println("Day");
        String expirationDateDay = sc.nextLine();
        PL();
        System.out.println("Would you like to move the items directly to the store?");
        System.out.println("1 = Yes, 0 = No, move them to the warehouse");
        PL();
        int toStore = sc.nextInt();
        try {
            additionService.addItem(amount, makat, LocalDate.parse(expirationDateYear + "-" + expirationDateMonth + "-" + expirationDateDay), toStore == 1);
            System.out.println("Items added successfully");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Would you like to try again?");
            System.out.println("1 For Y 2 For N");
            choice = sc.nextInt();
            if (choice == 1) {
                addItems();
            }
        }
        this.run();
    }

    private void addNewOrder() {
        System.out.println("How many products would you like to order for?");
        int amount = sc.nextInt();
        sc.nextLine();
        HashMap<Integer, Integer> map = new HashMap<>();
        for (int i = amount; i > 0; i--) {
            System.out.println("Enter product makat");
            int makat = sc.nextInt();
            sc.nextLine();
            System.out.println("Enter product amount");
            int Pamount = sc.nextInt();
            sc.nextLine();
            map.put(makat, Pamount);
        }
        additionService.addNewOrder(map);
        this.run();
    }
}