package PresentationLayer;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Properties;

public class ConfigReader {

    private static final Properties properties = new Properties();
    private static final String USER_CONFIG_FILE = "config.properties";
    private static String userConfigPath;

    static {
        loadProperties();
    }

    private ConfigReader() {
    }

    private static void loadProperties() {
        userConfigPath = System.getProperty("user.dir") + File.separator + USER_CONFIG_FILE;
        Path userConfigFile = Paths.get(userConfigPath);

        if (!Files.exists(userConfigFile)) {
            createUserConfigFromDefault();
        }

        try (InputStream input = new FileInputStream(userConfigPath)) {
            properties.load(input);
            System.out.println("Loaded user config from: " + userConfigPath);
        } catch (IOException ex) {
            System.out.println("Error loading user config, falling back to default");
            loadDefaultProperties();
        }
    }

    private static void createUserConfigFromDefault() {
        try (InputStream defaultInput = ConfigReader.class.getClassLoader().getResourceAsStream("config.properties");
             OutputStream userOutput = new FileOutputStream(userConfigPath)) {

            if (defaultInput == null) {
                System.out.println("Unable to find default config.properties");
                return;
            }

            Properties defaultProps = new Properties();
            defaultProps.load(defaultInput);
            defaultProps.store(userOutput, "User configuration created from default");
            System.out.println("Created user config at: " + userConfigPath);
        } catch (IOException ex) {
            System.out.println("Error creating user config from default");
            ex.printStackTrace();
        }
    }

    private static void loadDefaultProperties() {
        try (InputStream input = ConfigReader.class.getClassLoader().getResourceAsStream("config.properties")) {
            if (input == null) {
                System.out.println("Sorry, unable to find default config.properties");
            } else {
                properties.load(input);
                System.out.println("Loaded default config from resources");
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static String getProperty(String key) {
        return properties.getProperty(key);
    }

    public static void setProperty(String key, String value) {
        properties.setProperty(key, value);
        saveProperties();
    }

    private static void saveProperties() {
        try (OutputStream output = new FileOutputStream(userConfigPath)) {
            properties.store(output, "Updated properties");
            System.out.println("Properties saved to: " + userConfigPath);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static ArrayList<Integer> getDaysOfDelivery() {
        ArrayList<Integer> daysOfDelivery = new ArrayList<>();
        String daysString = properties.getProperty("daysOfDelivery");
        if (daysString != null && !daysString.isEmpty()) {
            String[] daysArray = daysString.split(",");
            for (String day : daysArray) {
                daysOfDelivery.add(Integer.parseInt(day.trim()));
            }
        }
        return daysOfDelivery;
    }
}