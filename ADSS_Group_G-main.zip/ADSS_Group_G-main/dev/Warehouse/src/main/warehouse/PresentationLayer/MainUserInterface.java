package PresentationLayer;


import ServiceLayer.ActionsServices.InitiatorService;
import ServiceLayer.ActionsServices.ReportService;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;

public class MainUserInterface extends UserInterface {
    private static final InitiatorService initiatorService = InitiatorService.getInstance();
    UserInterface userInterface;

    public static void main(String[] args) throws SQLException, IOException {
        PL();
        printSupermarketArt();
        PL();
        /*
        System.out.println("Would you like to load from saved data or start a new database?");
        System.out.println("1 for Load 2 for New");
        choice = sc.nextInt();
        initiatorService.initiate(choice);

        String day = LocalDate.now().getDayOfWeek().name();
        if (choice == 1) {
            PL();
            try {
                if (day.equals("MONDAY") || day.equals("THURSDAY")) {
                    System.out.printf("--- Generating automatic system report on All Items for %s---\n", day.toLowerCase());
                    ReportService.getInstance().generateReportOnAllItems();
                }
                System.out.println("--- Generating automatic system report on Expired and Defected Items ---");
                ReportService.getInstance().generateReportOnExpiredItems();
                ReportService.getInstance().generateReportOnDefectedItems();
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
*/

        MainUserInterface mainUI = new MainUserInterface();
        mainUI.run();
    }

    private static void PL() {
        System.out.println("--------------------------------------------------------------------");
    }

    public static void printSupermarketArt() {
        System.out.println(
                "         _____________________________\n" +
                        "        /                             \\\n" +
                        "       /                               \\\n" +
                        "      /_________________________________\\\n" +
                        "      |                                 |\n" +
                        "      |     SUPERMARKET LEE System      |\n" +
                        "      |                                 |\n" +
                        "      |   _______________   __________  |\n" +
                        "      |  |               | |          | |\n" +
                        "      |  |               | |          | |\n" +
                        "      |  |               | |          | |\n" +
                        "      |  |               | |          | |\n" +
                        "      |  |_______________| |__________| |\n" +
                        "      |                                 |\n" +
                        "      |_________________________________|\n" +
                        "     /___________________________________\\\n" +
                        "    /_____________________________________\\\n"
        );
    }

    public static void printSupermarketArtStart() {
        System.out.println(
                "  _____________ \n" +
                        " /             \\\n" +
                        "/               \\\n" +
                        "|               |\n" +
                        "|               |\n" +
                        "|  ___________  |\n" +
                        "| | Supermarket |\n" +
                        "| |    Lee      |\n" +
                        "| |   System    |\n" +
                        "| |             |\n" +
                        "| |___________| |\n" +
                        "|               |\n" +
                        "|_______________|\n"
        );
    }

    public void run() {
        PL();
        printSupermarketArtStart();
        PL();
        System.out.println("Enter your choice:");
        System.out.println("1.Add Order, Category, Product Or Item");
        System.out.println("2.Remove Category, Product Or Item");
        System.out.println("3.Generate Reports");
        System.out.println("4.Change Status");
        System.out.println("5.Set configuration of System");
        System.out.println("6.Exit");
        PL();
        choice = sc.nextInt();
        switch (choice) {
            case 1:
                Add();
                break;
            case 2:
                Remove();
                break;
            case 3:
                reports();
                break;
            case 4:
                Status();
                break;
            case 5:
                Configurations();
                break;
            case 6:
                Exit();
                break;


        }
    }

    public void Add() {
        userInterface = new Addition();
        userInterface.run();
        this.run();
    }

    public void Remove() {
        userInterface = new Remove();
        userInterface.run();
        this.run();

    }

    public void reports() {
        userInterface = new Reports();
        userInterface.run();
        this.run();
    }

    public void Status() {
        userInterface = new Status();
        userInterface.run();
        this.run();
    }

    public void Configurations() {
        PL();
        System.out.println("What would you like to do?");
        System.out.println("1.Change output files directory");
        System.out.println("2.Change DB url");
        System.out.println("3.Return");
        PL();
        choice = sc.nextInt();
        String path;
        switch (choice) {
            case 1:
                System.out.println("Enter full path to output files directory");
                sc.nextLine();
                path = sc.nextLine();
                ConfigReader.setProperty("output.dir", path);
                break;
            case 2:
                System.out.println("Enter full URL path to DB i.e jdbc\\:sqlite\\:/inventory.db");
                sc.nextLine();
                path = sc.nextLine();
                ConfigReader.setProperty("db.url", path);
                break;
            case 3:
                break;
        }
        this.run();
    }

    public void Exit() {
        System.out.println("Thank you and goodbye!");
        PL();
        System.exit(0);
    }
}
