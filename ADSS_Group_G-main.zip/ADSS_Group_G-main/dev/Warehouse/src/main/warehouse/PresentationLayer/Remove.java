package PresentationLayer;

import ServiceLayer.ActionsServices.RemoveService;

public class Remove extends UserInterface {
    private final RemoveService removeService = RemoveService.getInstance();

    @Override
    public void run() {
        PL();
        System.out.println("What would you like to remove? (Removing Subcategory will remove the product with it's items " +
                "and removing a product will remove all related items)");
        System.out.println("1.Remove Subcategory");
        System.out.println("2.Remove Product");
        System.out.println("3.Remove Items");
        System.out.println("4.Return");
        PL();
        choice = sc.nextInt();
        switch (choice) {
            case 1:
                removeSubcategory();
                break;
            case 2:
                removeProduct();
                break;
            case 3:
                removeItems();
                break;
            case 4:
                break;
        }
    }

    private void PL() {
        System.out.println("--------------------------------------------------------------------");
    }

    private void removeSubcategory() {
        System.out.println("Enter Subcategory ID");
        int subcategoryID = sc.nextInt();
        try {
            removeService.removeSubcategory(subcategoryID);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Would you like to try again?");
            System.out.println("1 For Y 2 For N");
            choice = sc.nextInt();
            if (choice == 1)
                this.removeSubcategory();
        }
        this.run();

    }

    private void removeProduct() {
        System.out.println("Enter Product makat");
        int productID = sc.nextInt();
        try {
            removeService.removeProduct(productID);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Would you like to try again?");
            System.out.println("1 For Y 2 For N");
            choice = sc.nextInt();
            if (choice == 1)
                this.removeProduct();
            System.out.println("Removed product successfully !");
        }
        this.run();

    }

    private void removeItems() {
        System.out.println("Enter Items ID");
        try {
            String itemsID = sc.nextLine();
            sc.nextLine();
            removeService.removeItem(itemsID);
            System.out.println("Remove the item successfully !");

        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Would you like to try again?");
            System.out.println("1 For Y 2 For N");
            choice = sc.nextInt();
            if (choice == 1)
                this.removeItems();
        }

        this.run();

    }
}
