package PresentationLayer;


import ServiceLayer.ActionsServices.ReportService;

import java.util.ArrayList;

public class Reports extends UserInterface {
    private final ReportService reportService = ReportService.getInstance();

    private void PL() {
        System.out.println("--------------------------------------------------------------------");
    }

    @Override
    public void run() {
        PL();
        System.out.println("What report would you like to generate?");
        System.out.println("1.Report on all items");
        System.out.println("2.Report on expired items");
        System.out.println("3.Report on defect items");
        System.out.println("4.Report on All Products");
        System.out.println("5.All Around report by Subcategory");
        System.out.println("6.Report by Subcategory");
        System.out.println("7.Report by Product");
        System.out.println("8.Return");
        PL();

        choice = sc.nextInt();
        try {
            switch (choice) {
                case 1:
                    reportService.generateReportOnAllItems();
                    break;
                case 2:
                    reportService.generateReportOnExpiredItems();
                    break;
                case 3:
                    reportService.generateReportOnDefectedItems();
                    break;
                case 4:
                    reportService.generateReportOnAllProducts();
                    break;
                case 5:
                    reportService.generateReportOnShop();
                    break;
                case 6:
                    System.out.println("Enter subcategories id's");
                    ArrayList<Integer> idList = new ArrayList<>();
                    while (true) {
                        sc.nextLine();
                        idList.add(sc.nextInt());
                        System.out.println("Add More?");
                        System.out.println("1 for Y 2 for N");
                        choice = sc.nextInt();
                        if (choice == 2)
                            break;
                        System.out.println("Enter subcategories id's");
                    }
                    try {
                        reportService.generateReportOnProductsBySubcategory(idList);

                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 7:
                    System.out.println("Enter Products makat");
                    ArrayList<Integer> Makatlist = new ArrayList<>();
                    while (true) {
                        sc.nextLine();
                        Makatlist.add(sc.nextInt());
                        System.out.println("Add More?");
                        System.out.println("1 for Y 2 for N");
                        choice = sc.nextInt();
                        if (choice == 2)
                            break;
                        System.out.println("Enter products makat");
                    }
                    try {
                        reportService.generateReportOnProductByItems(Makatlist);

                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 8:
                    break;
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Would you like to try again?");
            System.out.println("1 For Y 2 For N");
            choice = sc.nextInt();
            if (choice == 1)
                this.run();
        }

    }
}
