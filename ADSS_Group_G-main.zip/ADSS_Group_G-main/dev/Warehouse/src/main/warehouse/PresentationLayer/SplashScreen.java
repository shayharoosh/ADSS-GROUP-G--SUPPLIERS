package PresentationLayer;

import javax.swing.*;
import java.awt.*;

public class SplashScreen extends JWindow {
    private final int duration;

    public SplashScreen(int duration) {
        this.duration = duration;
    }

    public void showSplash() {
        JPanel content = (JPanel) getContentPane();
        content.setBackground(Color.white);

        int width = 650;
        int height = 275;
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (screen.width - width) / 2;
        int y = (screen.height - height) / 2;
        setBounds(x, y, width, height);

        JLabel welcome = new JLabel("Welcome to Supermarket Lee System", JLabel.CENTER);
        welcome.setFont(new Font("Sans-Serif", Font.BOLD, 18));
        welcome.setForeground(new Color(156, 20, 20)); // Red color
        JLabel label = new JLabel(new ImageIcon("C:\\Users\\gavvi\\Desktop\\Courses\\Second Semester\\Nituz\\ADSS_Group_G_\\ADSS_Group_G\\Warehouse\\splash_image.png"));
        JLabel copyrt = new JLabel("Copyright 2024, Supermarket Lee System", JLabel.CENTER);
        copyrt.setFont(new Font("Sans-Serif", Font.BOLD, 12));

        JProgressBar progressBar = new JProgressBar();
        progressBar.setMaximum(100);
        progressBar.setStringPainted(true);

        content.setLayout(new BorderLayout());
        content.add(welcome, BorderLayout.NORTH);
        content.add(label, BorderLayout.CENTER);
        content.add(copyrt, BorderLayout.SOUTH);
        content.add(progressBar, BorderLayout.PAGE_END);
        Color oraRed = new Color(156, 20, 20, 255);
        content.setBorder(BorderFactory.createLineBorder(oraRed, 10));

        setVisible(true);

        // The next section activates the progress bar
        for (int i = 0; i <= 100; i++) {
            final int percent = i;
            try {
                SwingUtilities.invokeLater(() -> progressBar.setValue(percent));
                Thread.sleep(duration / 100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        setVisible(false);
    }

    public void showSplashAndExit() {
        showSplash();
        System.exit(0);
    }
}
