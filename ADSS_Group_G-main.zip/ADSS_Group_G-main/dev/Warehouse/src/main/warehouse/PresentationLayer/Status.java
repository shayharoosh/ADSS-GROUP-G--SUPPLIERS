package PresentationLayer;

import DomainLayer.Classes.Item;
import DomainLayer.Classes.Order;
import ServiceLayer.ActionsServices.OrderService;
import ServiceLayer.ActionsServices.StatusService;
import ServiceLayer.ClassesServices.ItemService;

import java.util.ArrayList;
import java.util.HashMap;

public class Status extends UserInterface {
    private static final StatusService statusService = StatusService.getInstance();

    //private final Scanner scanner = new Scanner(System.in);
    private static void PL() {
        System.out.println("--------------------------------------------------------------------");
    }

    @Override
    public void run() {
        PL();
        System.out.println("What would you like to update?");
        System.out.println("1.Subcategory");
        System.out.println("2.Product");
        System.out.println("3.Item");
        System.out.println("4.Storage");
        System.out.println("5.Order");
        System.out.println("6.Change delivery days");
        System.out.println("7.Return");
        PL();
        choice = sc.nextInt();
        switch (choice) {
            case 1:
                subcategories();
                break;
            case 2:
                products();
                break;
            case 3:
                items();
                break;
            case 4:
                storage();
                break;
            case 5:
                orders();
                break;

            case 6:
                updateDeliveryDays();
                break;
            case 7:
                break;
        }
    }
    public void orders(){
        PL();
        System.out.println("Orders Section");
        PL();
        System.out.println("1.Change order status");
        System.out.println("2.Add products From arrived order");
        System.out.println("3.exit");
        while(true){
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter Order ID:");
                    int orderID = sc.nextInt();
                    System.out.println("Enter Status, 1 for delivered 2 for pending");
                    if(sc.nextInt() == 1){
                        statusService.setOrderStatus(orderID,"Delivered");
                    }
                    else if(sc.nextInt() == 2){
                        statusService.setOrderStatus(orderID,"Pending");
                    }
                    break;
                case 2:
                    System.out.println("NOT RELEVANT");
                    break;
                case 3:
                    break;
            }
        }

    }

    public void storage() {
        PL();
        System.out.println("Warehouse Storage Update Section");
        PL();
        //ArrayList<AbstractMap.SimpleEntry<Integer, Integer>> makatToAmountInWH = new ArrayList<>();
        HashMap<Integer, Integer> makatToAmountInWH = new HashMap<>();
        while (true) {
            System.out.println("Enter product makat:");
            int makat = sc.nextInt();

            System.out.println("Enter product amount in warehouse:");
            int amount = sc.nextInt();

            makatToAmountInWH.put(makat, amount);
            System.out.println("Do you want to add another product? (y/n):");
            String choice = sc.next();

            if (choice.equalsIgnoreCase("n")) {
                break;
            }
        }
        if (!makatToAmountInWH.isEmpty()) {
            statusService.updateStorage(makatToAmountInWH);
            System.out.println("Warehouse storage updated successfully.");
        } else {
            System.out.println("No updates made to warehouse storage.");
        }
        this.run();
    }

    private void updateDeliveryDays() {
        ArrayList<Integer> deliveryDays = new ArrayList<>();
        int d = 0;
        System.out.println("Please select the days for scheduled order arrivals:");
        while (true) {
            System.out.println("Select day: (1 == Sunday, 2 == Monday ...) or press 0 for exit");
            d = sc.nextInt();
            if (d == 0)
                break;
            else if (d < 0 || d > 7) {
                System.out.println("Please enter a valid day");
                continue;
            }
            deliveryDays.add(d);
        }
        StringBuilder toConfig = new StringBuilder();
        for (Integer day : deliveryDays) {
            toConfig.append(day).append(",");
        }
        try {
            toConfig.deleteCharAt(toConfig.length() - 1);
            ConfigReader.setProperty("daysOfDelivery", toConfig.toString());
            System.out.println("Days added are: " + toConfig);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        this.run();
    }

    private void subcategories() {
        System.out.println("THIS IS A WORK IN PROGRESS");
        System.out.println("What would you like to update?");
        System.out.println("1.Subcategory discount");
        choice = sc.nextInt();
        try {
            switch (choice) {
                case 1:
                    System.out.println("Enter category id");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter Start Date for Discount in this format yyyy-mm-dd");
                    String startDate = sc.nextLine();
                    System.out.println("Enter End Date for Discount in this format yyyy-mm-dd");
                    String endDate = sc.nextLine();
                    double discount = sc.nextDouble();
                    sc.nextLine();
                    statusService.setSubCategoryDiscount(id, startDate, endDate, discount);
                    break;

            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        this.run();
    }

    private void products() {
        System.out.println("What would you like to do?");
        System.out.println("1.Change Product Sell Price");
        System.out.println("2.Change Product Discount");
        System.out.println("3.Set New Location In Store For Product");
        choice = sc.nextInt();
        System.out.println("Enter product's makat");
        int makat = sc.nextInt();
        try {
            switch (choice) {
                case 1:
                    System.out.println("Enter product Sell price");
                    statusService.setProductSellPrice(makat, sc.nextDouble());
                    break;
                case 2:
                    System.out.println("Enter product Discount");
                    statusService.setProductDiscount(makat, sc.nextDouble());
                    break;
                case 3:
                    System.out.println("Enter Department");
                    String department = sc.nextLine();
                    System.out.println("Enter row");
                    int row = sc.nextInt();
                    statusService.setProductLocation(makat, department, row);
                    break;

            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        this.run();
    }

    private void items() {
        System.out.println("What would you like to do?");
        System.out.println("1.Change Item location");
        System.out.println("2.Change Item defect status");
        System.out.println("3.Check if item expired");
        choice = sc.nextInt();
        System.out.println("Enter item's id");
        sc.nextLine();
        String itemId = sc.nextLine();
        Item currItem = ItemService.getInstance().getItemByItemID(itemId);
        try {
            switch (choice) {
                case 1:
                    System.out.println("Where to?");
                    System.out.println("1.To Store");
                    System.out.println("2.To Warehouse");
                    choice = sc.nextInt();
                    boolean status;
                    status = choice == 1;
                    statusService.setItemLocation(itemId, status);
                    break;
                case 2:
                    String description;
                    System.out.println("Enter item's defect description");
                    description = sc.nextLine();
                    statusService.setItemDefectStatus(itemId, true, description);
                    System.out.println("Updated defect status successfully !");
                    System.out.println("Item details:");
                    System.out.println(currItem);
                    break;
                case 3:
                    Boolean ans = statusService.CheckIfItemIsExpired(itemId);
                    if(ans) {
                        System.out.println("Item is expired!\nItem details:");
                        System.out.println(currItem);
                    }
                    else{
                        System.out.println("Item is not expired!\nItem details:");
                        System.out.println(currItem);
                    }
                    break;

            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        this.run();
    }

}
