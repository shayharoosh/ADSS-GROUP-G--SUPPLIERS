package PresentationLayer;

import java.util.Scanner;

public abstract class UserInterface {
    static int choice;
    static Scanner sc = new Scanner(System.in);


    public abstract void run();
}
