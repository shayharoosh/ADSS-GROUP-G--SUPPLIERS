package ServiceLayer.ActionsServices;

import ServiceLayer.ClassesServices.ItemService;
import ServiceLayer.ClassesServices.ProductService;
import ServiceLayer.ClassesServices.SubCategoryService;

public abstract class ActionService {
    protected ItemService itemService;
    protected ProductService productService;
    protected SubCategoryService subCategoryService;

    protected ActionService() {
        itemService = ItemService.getInstance();
        productService = ProductService.getInstance();
        subCategoryService = SubCategoryService.getInstance();
    }
}
