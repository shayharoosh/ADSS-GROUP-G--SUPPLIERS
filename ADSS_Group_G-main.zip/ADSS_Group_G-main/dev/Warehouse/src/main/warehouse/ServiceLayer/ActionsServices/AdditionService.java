package ServiceLayer.ActionsServices;

import java.time.LocalDate;
import java.util.HashMap;

public class AdditionService extends ActionService {
    private static AdditionService instance = null;

    private AdditionService() {

    }

    public static AdditionService getInstance() {
        if (instance == null) {
            instance = new AdditionService();
        }
        return instance;
    }

    public void addSubcategory(String CategoryName, int subCategoryID, String subCategoryName) {
        subCategoryService.AddSubCategory(CategoryName, subCategoryID, subCategoryName);
    }

    public void addProduct(String productName, double productSize, int makat, int subcategoryID, String productManufacturerName, double productCostPrice, double productSellPrice, double discount, int minAmount) {
        if (!subCategoryService.CheckSubcategoryExist(subcategoryID))
            throw new IllegalArgumentException("Subcategory doesnt exist!, check categoryId for mistake or create new category");
        try {
            productService.addProduct(productName, productSize, makat, subcategoryID, productManufacturerName, productCostPrice, productSellPrice, discount, minAmount);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void addItem(int amount, int makat, LocalDate expirationDate, boolean toStore) {
        if (!productService.checkProductExists(makat))
            throw new IllegalArgumentException("No Such Product Exists!");
        productService.IncreaseProductCurrentAmount(makat, amount, toStore);
        itemService.addItem(amount, makat, expirationDate, toStore);
    }

    public void addNewOrder(HashMap<Integer, Integer> productAmount) {
        for (Integer productID : productAmount.keySet()) {
            if (productService.checkProductExists(productID))
                throw new IllegalArgumentException("No Such Product Exists!");
            OrderService.getInstance().addOrderByHand(productAmount);
        }
    }
}
