package ServiceLayer.ActionsServices;


import PresentationLayer.ConfigReader;
import ServiceLayer.ClassesServices.ItemService;
import ServiceLayer.ClassesServices.ProductService;
import ServiceLayer.ClassesServices.SubCategoryService;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

public class InitiatorService {
    private static InitiatorService instance;

    private InitiatorService() {
    }

    public static InitiatorService getInstance() {
        if (instance == null) {
            instance = new InitiatorService();
        }
        return instance;
    }

    public void initiate(int choice) throws SQLException {
        try {
            if (choice == 1) {
                LoadDataFromDisk();
            } else
                createDBandTable();
            System.out.println("Operation Completed Successfully");
            FixedDaysOfOrders(ConfigReader.getDaysOfDelivery());
        } catch (Exception e) {
            System.err.println("There was a problem: " + e.getMessage());
        }

    }

    public void LoadDataFromDisk() throws SQLException {
        SubCategoryService.getInstance().loadData();
        ProductService.getInstance().loadData();
        ItemService.getInstance().loadData();
        OrderService.getInstance().loadData();
    }

    public void FixedDaysOfOrders(ArrayList<Integer> daysOfWeek) {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                Calendar calendar = Calendar.getInstance();
                int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
                // Notify supplier a day before the selected days
                for (int day : daysOfWeek) {
                    int dayBefore = (day == Calendar.SUNDAY) ? Calendar.SATURDAY : day - 1;

                    if (dayOfWeek == dayBefore) {
                        // check if current day is one of the fixed delivery day, if it is, generate new order
                        // note : we notified the supplier day before ! (generated report, Keren said that in the new docx file)
                        OrderService.getInstance().notifySupplier();
                        break;
                    } else if (dayOfWeek == day) {
                        try {
                            ReportService.getInstance().generateReportOnDeficiencies();
                            OrderService.getInstance().generateOrder();
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                        break;
                    }
                }
            }
        }, 0, 24 * 60 * 60 * 1000); // Check once every day (24 hours in milliseconds)
    }

    public void createDBandTable() throws SQLException, IOException {
        deleteExistingDatabase();
        createReportDirectory();
        createOrderDirectory();
        createNewDatabase();
        createNewSubcategoriesTable();
        createNewProductsTable();
        createNewItemsTable();
        createNewOrdersTable();
        createOrdersProductsTable();
    }

    public void createReportDirectory() {
        String directoryPath = System.getProperty("user.dir") + File.separator + "\\Reports";
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdir();
        }
    }
    public void createOrderDirectory() {
        String directoryPath = System.getProperty("user.dir") + File.separator + "\\Orders";
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdir();
        }
    }

    public void deleteExistingDatabase() throws IOException {
        String directoryPath = System.getProperty("user.dir") + File.separator + ConfigReader.getProperty("db.dir");
        if (Files.exists(Paths.get(directoryPath))) {
            // Delete the file inside the folder
            if (Files.deleteIfExists(Paths.get(directoryPath).resolve("inventory.db")))
                System.out.println("Database Deleted Successfully");
        }
    }

    public void createNewDatabase() {
        String url = ConfigReader.getProperty("db.url");
        String directoryPath = System.getProperty("user.dir") + File.separator + ConfigReader.getProperty("db.dir");
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdir();
        }
        try (Connection conn = DriverManager.getConnection(url)) {
            if (conn != null) {
                System.out.println("A new database has been created.");
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    public void createNewSubcategoriesTable() {
        String url = ConfigReader.getProperty("db.url");
        String createSubcategoriesTable = "CREATE TABLE IF NOT EXISTS subcategories ("
                + " id INTEGER PRIMARY KEY,"
                + " subcategory_name TEXT NOT NULL,"
                + " category_name TEXT NOT NULL,"
                + " start_discount TEXT,"
                + " end_discount TEXT,"
                + " discount DOUBLE NOT NULL,"
                + " FOREIGN KEY (category_name) REFERENCES categories (category_name)"
                + ");";
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement()) {
            // create new tables
            stmt.execute(createSubcategoriesTable);
            System.out.println("Subcategory Table created.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    public void createNewProductsTable() {
        String url = ConfigReader.getProperty("db.url");

        String createProductsTable = "CREATE TABLE IF NOT EXISTS products ("
                + " makat INTEGER PRIMARY KEY,"
                + " PName TEXT NOT NULL,"
                + " CostPrice DOUBLE NOT NULL,"
                + " SellPrice DOUBLE NOT NULL,"
                + " minAmount INTEGER NOT NULL,"
                + " PSize DOUBLE NOT NULL,"
                + " Manufacturer TEXT NOT NULL,"
                + "Department Text NOT NULL,"
                + "rowNumber INTEGER NOT NULL,"
                + "AmountInStore INTEGER NOT NULL,"
                + "AmountInWarehouse INTEGER NOT NULL,"
                + "Discount DOUBLE NOT NULL,"
                + " subcategory_id INTEGER,"
                + " FOREIGN KEY (subcategory_id) REFERENCES subcategories (subcategory_id)"
                + ");";
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement()) {
            // create new tables
            stmt.execute(createProductsTable);
            System.out.println("Product Table created.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void createNewItemsTable() {
        String url = ConfigReader.getProperty("db.url");
        String createItemsTable = "CREATE TABLE IF NOT EXISTS items ("
                + " id TEXT PRIMARY KEY,"
                + " DateOfArrival TEXT NOT NULL,"
                + " DateOfExpiration TEXT NOT NULL,"
                + " InStore BOOLEAN NOT NULL,"
                + " Defected BOOLEAN NOT NULL,"
                + " DescriptionOfDefect TEXT ,"
                + " makat INTEGER,"
                + " FOREIGN KEY (makat) REFERENCES products (makat)"
                + ");";
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement()) {
            // create new tables
            stmt.execute(createItemsTable);
            System.out.println("Item Table created.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void createNewOrdersTable() {
        String url = ConfigReader.getProperty("db.url");
        String createOrdersTable = "CREATE TABLE IF NOT EXISTS orders ("
                + " order_id INTEGER PRIMARY KEY,"
                + " orderDate TEXT NOT NULL,"
                + " orderStatus TEXT NOT NULL"
                + ");";
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement()) {
            // create new tables
            stmt.execute(createOrdersTable);
            System.out.println("Order Table created.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void createOrdersProductsTable() {
        String url = ConfigReader.getProperty("db.url");
        String createOrdersProductsTable = "CREATE TABLE IF NOT EXISTS orders_products ("
                + " order_id INTEGER NOT NULL,"
                + " makat INTEGER NOT NULL,"
                + " amount INTEGER NOT NULL,"
                + " PRIMARY KEY (order_id,makat)"
                + " FOREIGN KEY (order_id) REFERENCES orders(order_id) "
                + " FOREIGN KEY (makat) REFERENCES products(makat)"
                + ");";
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement()) {
            // create new tables
            stmt.execute(createOrdersProductsTable);
            System.out.println("Order To Product Table created.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }
}
