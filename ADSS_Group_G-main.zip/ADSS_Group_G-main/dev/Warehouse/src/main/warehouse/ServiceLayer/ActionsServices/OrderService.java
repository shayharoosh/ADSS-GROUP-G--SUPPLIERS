package ServiceLayer.ActionsServices;

import DomainLayer.Classes.Order;
import DomainLayer.Classes.Product;
import DomainLayer.Controllers.OrderController;

import java.io.IOException;
import java.time.LocalDate;
//import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ThreadLocalRandom;

public class OrderService extends ActionService {
    private static OrderService instance = null;
    private final OrderController orderController;

    private OrderService() {
        orderController = OrderController.getInstance();
    }

    public static OrderService getInstance() {
        if (instance == null) {
            instance = new OrderService();
        }
        return instance;
    }

    public void loadData() {
        orderController.loadData();
    }
    public static LocalDate getRandomDate(LocalDate startDate, LocalDate endDate) {
        long daysBetween = endDate.toEpochDay() - startDate.toEpochDay();
        long randomDays = ThreadLocalRandom.current().nextLong(daysBetween + 1); // +1 to include end date
        return startDate.plusDays(randomDays);
    }


    /*
    public static LocalDate getRandomDate(LocalDate startDate, LocalDate endDate) {
        long daysBetween = ChronoUnit.DAYS.between(startDate, endDate);
        long randomDays = ThreadLocalRandom.current().nextLong(daysBetween + 1); // +1 to include end date
        return startDate.plusDays(randomDays);
    }


     */
    public void addOrderByHand(HashMap<Integer, Integer> productAmount) {
        try {
            Order order = orderController.addOrder(productAmount);
            ReportService.getInstance().generateReportOnOrder(order);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    //TODO when possible, send this to supplier
    public void notifySupplier() {
        try {
            ReportService.getInstance().generateReportOnDeficiencies();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void generateOrder() throws IOException {
        ArrayList<Product> products = productService.getAllProducts();
        HashMap<Integer, Integer> productHashMap = new HashMap<>();

        for (Product product : products) {
            if (product.getCurrentTotalAmount() < product.getMinAmount()) {
                productHashMap.put(product.getMakat(), product.getMinAmount() * 3);
            }
        }

        Order order = orderController.addOrder(productHashMap);
        ReportService.getInstance().generateReportOnOrder(order);
    }
    public void updateOrderStatus(int orderID, Order.OrderStatus orderStatus) {
        try {
            orderController.updateOrderStatus(orderID, orderStatus);
//            HashMap<Integer,Integer> map=orderCon...............................troller.getOrderById(orderID).getMakatToAmount();
//            for (Integer key : map.keySet()) {
//                int amountToAdd=map.get(key);
//               AdditionService.getInstance().addItem(amountToAdd,key,getRandomDate(LocalDate.now(),LocalDate.now().plusMonths(3)),false);
//          }
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
    public Order getOrderByID(int orderID) {
       Order order =orderController.getOrderById(orderID);
       if(order==null){
           throw new RuntimeException("Order not found");
       }
       return order;
    }

    // After integration with supplier module, we will be able to send the csv file directly to them.
    // For now, we'll just generate report for the client about the order and notify him as well.
    public void generateOrderDueToDeficiencies(ArrayList<Integer> deficienciesProductsMakat) {
        HashMap<Integer, Integer> ProductToAmounts = new HashMap<>();
        try {
            for (int makat : deficienciesProductsMakat)
                ProductToAmounts.put(makat, 3 * productService.getProductMinAmount(makat)); // order 2x of the minimum amount that the client wants from that product.
            Order order = orderController.addOrder(ProductToAmounts);  //TODO WHEN POSSIBLE SEND THE ORDER TO THE SUPPLIERS
            ReportService.getInstance().generateReportOnOrder(order); // generate report to the client about the current order
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
