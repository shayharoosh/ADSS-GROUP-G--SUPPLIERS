package ServiceLayer.ActionsServices;

import DomainLayer.Classes.Item;
import DomainLayer.Classes.Product;

import java.util.ArrayList;

public class RemoveService extends ActionService {
    private static RemoveService instance;

    private RemoveService() {

    }

    public static RemoveService getInstance() {
        if (instance == null) {
            instance = new RemoveService();
        }
        return instance;
    }

    public void removeSubcategory(int subcategoryId) {
        ArrayList<Product> products = productService.getProductsBySubcategoryID(subcategoryId);
        for (Product product : products) {
            itemService.removeItemByProductID(product.getMakat());
        }
        productService.removeProductBySubcategoryID(subcategoryId);
        subCategoryService.removeSubCategory(subcategoryId);
    }

    public void removeProduct(int productId) {
        itemService.removeItemByProductID(productId);
        productService.removeProduct(productId);
    }

    public void removeItem(String itemId) {
        Item item = itemService.getItemByItemID(itemId);
        if (item == null)
            throw new RuntimeException("Item not found");
        productService.DecreaseProductCurrentAmount(item.getItemMakat(), 1, item.getItemLocation());
        itemService.removeItemByItemID(itemId);
    }

}
