package ServiceLayer.ActionsServices;

import DomainLayer.Classes.Item;
import DomainLayer.Classes.Order;
import DomainLayer.Classes.Product;
import DomainLayer.Classes.SubCategory;
import PresentationLayer.ConfigReader;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

public class ReportService extends ActionService {
    private static ReportService instance = null;

    private ReportService() {

    }

    public static ReportService getInstance() {
        if (instance == null) {
            instance = new ReportService();
        }
        return instance;
    }

    public void generateReportOnAllItems() {
        String toCsv = null;
        String directoryPath = ConfigReader.getProperty("output.dir") + File.separator + "Reports";
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdir();
        }
        String reportName = "AllItemsReport_" + LocalDate.now() + ".csv";
        String filepath = directoryPath + File.separator + reportName;
        try (FileWriter fileWriter = new FileWriter(filepath)) {
            fileWriter.write("ItemID,Makat,DateOfArrival,ExpirationDate,Defected,DefectDescription,Expired,InStore\n");
            ArrayList<Item> items = itemService.getAllItems();
            if (items == null || items.isEmpty()) {
                throw new RuntimeException("No items found");
            }
            for (Item item : items) {
                fileWriter.write(item.toCSV() + "\n");
            }

        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    public void generateReportOnExpiredItems() throws IOException {
        String directoryPath = ConfigReader.getProperty("output.dir") + File.separator + "Reports";
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdir();
        }
        String reportName = "ExpiredItemsReport_" + LocalDate.now() + ".csv";
        String filepath = directoryPath + File.separator + reportName;
        try (FileWriter writer = new FileWriter(filepath)) {
            writer.write("ItemID,Makat,DateOfArrival,ExpirationDate,Defected,DefectDescription,Expired,InStore\n");
            ArrayList<Item> items = itemService.getExpiredItems();
            for (Item item : items)
                writer.write(item.toCSV() + "\n");

        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    public void generateReportOnDefectedItems() throws IOException {
        String toCsv = null;
        String directoryPath = ConfigReader.getProperty("output.dir") + File.separator + "Reports";
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdir();
        }
        String reportName = "DefectedItemsReport_" + LocalDate.now() + ".csv";
        String filepath = directoryPath + File.separator + reportName;
        try (FileWriter writer = new FileWriter(filepath)) {
            writer.write("ItemID,Makat,DateOfArrival,ExpirationDate,Defected,DefectDescription,Expired,InStore\n");
            ArrayList<Item> items = itemService.getDefectedItems();
            for (Item item : items) {
                writer.write(item.toCSV() + "\n");
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }
    public void generateForUseCase(){
        String directoryPath = ConfigReader.getProperty("output.dir") + File.separator + "UseCase";

    }

    // Method gets Order object and writes it into CSV file
    public void generateReportOnOrder(Order order) throws IOException {
        String directoryPath = ConfigReader.getProperty("output.dir") + File.separator + "Orders";
        if(order.getStatus()== Order.OrderStatus.PENDING)
            directoryPath = directoryPath + File.separator + "PendingOrders";
        else
            directoryPath = directoryPath + File.separator + "DeliveredOrders";
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdir();
        }
        String reportName = "WarehouseOrderReport_"+ order.getOrderID() + LocalDate.now() + ".csv";
        String filepath = directoryPath + File.separator + reportName;

        try (FileWriter writer = new FileWriter(filepath)) {
            writer.write("ProductName,Manufacturer,Makat,Amount\n");
            HashMap<Integer, Integer> map = order.getMakatToAmount();
            for (Integer makat : map.keySet()) {
                Product p = productService.getProductByMakat(makat);
                writer.write(p.getProductName() + "," + p.getProductManufacturerName() + "," + makat + "," + map.get(makat) + "\n");
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    public void generateReportOnDeficiencies() throws IOException {
        String directoryPath = ConfigReader.getProperty("output.dir") + File.separator + "Reports";
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdir();
        }
        ArrayList<Product> products = productService.getAllProducts();
        String reportName = "ProductDeficienciesReport_" + LocalDate.now() + ".csv";
        String filepath = directoryPath + File.separator + reportName;
        try (FileWriter writer = new FileWriter(filepath)) {
            writer.write("Name,Makat,Manufacturer,TotalAmount,MinAmount,toOrder\n");
            for (Product product : products) {
                // check whether there is deficiencies in current product
                if (product.getCurrentTotalAmount() < product.getMinAmount())
                    writer.write(product.toCSVonDeficiencies() + "\n");
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    public void generateReportOnDeficienciesInWarehouse() throws IOException {
        String directoryPath = ConfigReader.getProperty("output.dir") + File.separator + "Reports";
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdir();
        }
        ArrayList<Product> products = productService.getAllProducts();
        String reportName = "WarehouseDeficienciesReport_" + LocalDate.now() + ".csv";
        String filepath = directoryPath + File.separator + reportName;
        try (FileWriter writer = new FileWriter(filepath)) {
            writer.write("Name,Makat,MissingAmount\n");
            for (Product product : products) {
                if (product.getAmountInWarehouse() < product.getMinAmount()) {
                    writer.write(product.getProductName() + "," + product.getMakat() + "," + (product.getMinAmount() - product.getAmountInWarehouse()) + "\n");
                }
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    public void generateReportOnAllProducts() throws IOException {
        String directoryPath = ConfigReader.getProperty("output.dir") + File.separator + "Reports";
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdir();
        }
        ArrayList<Product> products = productService.getAllProducts();
        String reportName = "ProductsReport_" + LocalDate.now() + ".csv";
        String filepath = directoryPath + File.separator + reportName;
        try (FileWriter writer = new FileWriter(filepath)) {
            writer.write("Name,Size,Makat,Manufacturer,CategoryID,CostPrice,SellPriceAfterDiscount,Discount,AmountInStore,AmountInWarehouse,TotalAmount,MinAmount,Department,Row\n");
            for (Product product : products) {
                writer.write(product.toCSV() + "\n");
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }


    public void generateReportOnProductsBySubcategory(ArrayList<Integer> list) throws IOException {
        String directoryPath = ConfigReader.getProperty("output.dir") + File.separator + "Reports" + File.separator + "ProductsBySubcategory";
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdir();
        }
        try {
            ArrayList<SubCategory> subCategories = subCategoryService.getSubCategories(list);
            for (SubCategory subCategory : subCategories) {
                String reportName = subCategory.getSubCategoryName() + "Report_" + LocalDate.now() + ".csv";
                String filepath = directoryPath + File.separator + reportName;
                ArrayList<Product> products = productService.getProductsBySubcategoryID(subCategory.getSubCategoryID());
                try (FileWriter writer = new FileWriter(filepath)) {
                    writer.write("Name,Size,Makat,Manufacturer,CategoryID,CostPrice,SellPriceAfterDiscount,Discount,AmountInStore,AmountInWarehouse,TotalAmount,MinAmount,Department,Row\n");
                    for (Product product : products) {
                        writer.write(product.toCSV() + "\n");
                    }
                }
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    public void generateReportOnProductByItems(ArrayList<Integer> list) throws IOException {
        String directoryPath = ConfigReader.getProperty("output.dir") + File.separator + "Reports" + File.separator + "ItemsByProducts";
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdir();
        }
        try {
            ArrayList<Product> products = productService.getProducts(list);
            for (Product product : products) {
                String reportName = product.getProductName() + "Report_" + LocalDate.now() + ".csv";
                String filepath = directoryPath + File.separator + reportName;
                ArrayList<Item> items = itemService.getItemsByMakat(product.getMakat());
                try (FileWriter writer = new FileWriter(filepath)) {
                    writer.write("ItemID,Makat,DateOfArrival,ExpirationDate,Defected,DefectDescription,Expired,InStore\n");
                    for (Item item : items) {
                        writer.write(item.toCSV() + "\n");
                    }
                }

            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    public void generateReportOnShop() throws IOException {
        String toCsv = null;
        String directoryPath = ConfigReader.getProperty("output.dir") + File.separator + "Reports";
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdir();
        }
        String reportName = "ShopReport_" + LocalDate.now() + ".csv";
        String filepath = directoryPath + File.separator + reportName;
        try (FileWriter fileWriter = new FileWriter(filepath)) {
            fileWriter.write("SubcategoryID,SubcategoryName,TotalAmountOfProducts,TotalAmountOfItems,AmountOfDefectedItems,AmountOfExpiredItems,DiscountStartDate,DiscountEndDate,CurrentDiscount\n");
            ArrayList<SubCategory> subCategories = subCategoryService.retrieveAllSubcategories();
            for (SubCategory subCategory : subCategories) {
                ArrayList<Product> products = productService.getProductsBySubcategoryID(subCategory.getSubCategoryID());
                if (products == null || products.isEmpty()) {
                    continue;
                }
                int amountOfProducts = products.size();
                int AmountOfItems = 0;
                int AmountOfExpiredItems = 0;
                int AmountOfDefectedItems = 0;
                for (Product product : products) {
                    ArrayList<Item> itemlist = itemService.getItemsByMakat(product.getMakat());
                    if (itemlist == null || itemlist.isEmpty()) {
                        continue;
                    }
                    AmountOfItems += itemlist.size();
                    AmountOfExpiredItems += (int) itemlist.stream().filter(Item::CheckIfExpired).count();
                    AmountOfDefectedItems += (int) itemlist.stream().filter(Item::isDefect).count();
                }
                toCsv = String.format("%d,%s,%d,%d,%d,%d,%s,%s,%.3f", subCategory.getSubCategoryID(), subCategory.getSubCategoryName(), amountOfProducts
                        , amountOfProducts, AmountOfItems, AmountOfDefectedItems, AmountOfExpiredItems,
                        subCategory.getSubcategorieDiscountDates()[0], subCategory.getSubcategorieDiscountDates()[1],
                        subCategory.getDiscount());
                fileWriter.write(toCsv + "\n");
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }
}
