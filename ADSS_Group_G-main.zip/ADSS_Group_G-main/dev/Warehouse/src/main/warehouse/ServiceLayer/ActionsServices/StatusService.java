package ServiceLayer.ActionsServices;

import DomainLayer.Classes.Location;
import DomainLayer.Classes.Order;
import DomainLayer.Classes.Product;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;


public class StatusService extends ActionService {
    private static StatusService instance = null;

    private StatusService() {
    }

    public static StatusService getInstance() {
        if (instance == null) {
            instance = new StatusService();
        }
        return instance;
    }

    public void updateStorageAfterReceivingOrderFromSuppliers(){




    }

    public void updateStorage(HashMap<Integer, Integer> makatToAmountInWH) {
        ArrayList<Integer> deficienciesProductsMakat = new ArrayList<>();

        // update products amount in warehouse & verify their capacity
        try {
            for (Integer makat : makatToAmountInWH.keySet()) {
                // set product amount in warehouse to the value that the storekeeper reported
                Product currProduct = productService.getProductByMakat(makat);
                currProduct.setAmountInWarehouse(makatToAmountInWH.get(makat));
                System.out.println(currProduct);
                if (currProduct.getAmountInWarehouse() < currProduct.getMinAmount())
                    deficienciesProductsMakat.add(makat);
            }
            PL();
            // check if there is any deficiencies in the warehouse,
            if (!deficienciesProductsMakat.isEmpty()) {
                System.out.println("There are deficiencies in storage! The system will now generate order automatically due to deficiencies!");
                OrderService.getInstance().generateOrderDueToDeficiencies(deficienciesProductsMakat);
                ReportService.getInstance().generateReportOnDeficienciesInWarehouse();
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void setSubCategoryDiscount(int subcategoryID, String start_date, String end_date, double discount) {
        subCategoryService.setSubCategoryDiscount(subcategoryID, start_date, end_date, discount);
        productService.setProductDiscountBySubcategoryID(subcategoryID, discount);

    }

    public void setProductDiscount(int makat, double discount) {
        productService.setProductDiscount(makat, discount);
    }

    public void setProductSellPrice(int makat, double discount) {
        productService.setProductSellPrice(makat, discount);
    }

    public void setItemDefectStatus(String itemID, boolean status, String description) {
        itemService.setItemDefectStatus(itemID, status, description);
    }

    public void setProductLocation(int makat, String location, int row) {
        productService.setProductLocation(makat, location, row);
    }

    public boolean CheckIfItemIsExpired(String itemID) {
        try {
            return itemService.CheckIfItemIsExpired(itemID);

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return false;
    }

    public void setItemLocation(String itemID, boolean toStore) {
        try {
            Product product = productService.getProductByMakat(itemService.getItemByItemID(itemID).getItemMakat());
            if (toStore) {
                if (product.getLocation().getDepartment() == Location.Department.Warehouse) {
                    System.err.println("Cant Move Item to Store!, Product location hasn't been assigned yet");
                    return;
                }
            }
            itemService.setItemLocation(itemID, toStore);
            productService.IncreaseProductCurrentAmount(product.getMakat(), 1, toStore);
            productService.DecreaseProductCurrentAmount(product.getMakat(), 1, !toStore);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
    public void setOrderStatus(int orderID,String status){
        OrderService orderService= OrderService.getInstance();
        if(status.equals("Pending"))
            orderService.updateOrderStatus(orderID, Order.OrderStatus.PENDING );
        else
            orderService.updateOrderStatus(orderID, Order.OrderStatus.DELIVERED);
    }
    private static void PL() {
        System.out.println("--------------------------------------------------------------------");
    }
}
