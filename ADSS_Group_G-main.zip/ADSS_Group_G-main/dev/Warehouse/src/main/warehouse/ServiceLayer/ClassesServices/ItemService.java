package ServiceLayer.ClassesServices;

import DomainLayer.Classes.Item;
import DomainLayer.Controllers.ItemController;
import DomainLayer.Controllers.ProductController;

import java.time.LocalDate;
import java.util.ArrayList;

public class ItemService {
    private static ItemService instance;
    private final ItemController itemController;

    private ItemService() {
        itemController = ItemController.getInstance();
    }

    public static ItemService getInstance() {
        if (instance == null) {
            instance = new ItemService();
        }
        return instance;
    }
    //FOR TESTING PURPOSE ONLY!!!
    public ItemService(ItemController itemController) {
        this.itemController = itemController;
    }

    public void loadData() {
        itemController.loadData();
    }

    public void addItem(int amount, int makat, LocalDate expirationDate, boolean toStore) {
        Item tempItem;
        while (amount > 0) {
            tempItem = itemController.addItemAndReturnIt(makat, expirationDate);
            itemController.setItemLocation(tempItem.getItemUniqueID(), toStore);
            amount--;
        }
    }

    public void removeItemByProductID(int productID) {
        itemController.removeItemsByProductID(productID);
    }

    public void removeItemByItemID(String itemID) {
        itemController.removeSpecificItem(itemID);
    }

    public Item getItemByItemID(String itemID) {
        return itemController.getItemByID(itemID);
    }

    public ArrayList<Item> getItemsByMakat(int makat) {
        return itemController.getItemsByMakat(makat);
    }

    public ArrayList<Item> getAllItems() {
        return itemController.getAllItems();
    }

    public ArrayList<Item> getExpiredItems() {
        return itemController.getExpiredItemsList();
    }

    public ArrayList<Item> getDefectedItems() {
        return itemController.getDefectedItemsList();
    }

    public void setItemDefectStatus(String itemID, boolean status, String description) {
        try {
            itemController.setItemDefect(itemID, status, description);

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public boolean CheckIfItemIsExpired(String itemID) {
        return itemController.isItemExpired(itemID);
    }

    public void setItemLocation(String itemID, boolean toStore) {
        itemController.setItemLocation(itemID, toStore);
    }

}
