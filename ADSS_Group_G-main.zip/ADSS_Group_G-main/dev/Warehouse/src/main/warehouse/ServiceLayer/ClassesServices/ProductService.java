package ServiceLayer.ClassesServices;

import DomainLayer.Classes.Product;
import DomainLayer.Controllers.ProductController;

import java.util.ArrayList;

public class ProductService {
    private static ProductService instance = null;
    private final ProductController productController;

    public ProductService() {
        productController = ProductController.getInstance();
    }

    //ONLY FOR TESTING PURPOSE!!!!!!!!!!!!!!!!!!!!!
    public ProductService(ProductController productController) {
        this.productController = productController;
    }
    public static ProductService getInstance() {
        if (instance == null) {
            instance = new ProductService();
        }
        return instance;
    }

    public void loadData() {
        productController.loadData();
    }

    public void addProduct(String productName, double size, int makat, int subcategoryid, String manufacturer, double costPrice, double sellPrice, double discount, int minAmount) {
        productController.addProduct(productName, size, makat, subcategoryid, manufacturer, costPrice, sellPrice, discount, minAmount);
    }

    public void removeProduct(int makat) {
        try {
            productController.removeProduct(makat);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void removeProductBySubcategoryID(int subcategoryid) {
        try {
            productController.removeProductBySubcategoryID(subcategoryid);

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void setProductDiscountBySubcategoryID(int subcategoryid, double discount) {
        productController.setProductDiscountBySubCategoryID(subcategoryid, discount);
    }

    public void setProductDiscount(int makat, double discount) {
        productController.setProductDiscount(makat, discount);
    }

    public void setProductSellPrice(int makat, double sellPrice) {
        productController.setProdcutSellingPrice(makat, sellPrice);
    }

    public void setProductLocation(int makat, String location, int row) {
        try {
            productController.setLocationOfProduct(makat, location, row);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public Product setAmountInWarehouse(int makat, int amount) {
        return productController.setAmountInWarehouse(makat, amount);
    }

    public boolean checkProductExists(int makat) {
        return productController.getProductByMakat(makat) != null;
    }

    public void IncreaseProductCurrentAmount(int makat, int amount, boolean toStore) {
        try {
            productController.IncreaseProductCurrentAmount(makat, amount, toStore);

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void DecreaseProductCurrentAmount(int makat, int amount, boolean toStore) {
        try {
            productController.DecreaseProductCurrentAmount(makat, amount, toStore);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public ArrayList<Product> getProductsBySubcategoryID(int subcategoryid) {
        return productController.getProductsByCategory(subcategoryid);
    }

    public Product getProductByMakat(int makat) {
        try {
            return productController.getProductByMakat(makat);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return null;
    }

    public ArrayList<Product> getAllProducts() {
        return productController.getAllProducts();
    }

    public int getProductMinAmount(int makat) {
        return productController.getProductMinAmount(makat);
    }

    public ArrayList<Product> getProducts(ArrayList<Integer> list) {
        ArrayList<Product> products = new ArrayList<>();
        for (Integer i : list) {
            products.add(getProductByMakat(i));
        }
        return products;
    }

}
