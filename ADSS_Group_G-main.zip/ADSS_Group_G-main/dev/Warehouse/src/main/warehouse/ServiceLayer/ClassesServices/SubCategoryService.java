package ServiceLayer.ClassesServices;

import DomainLayer.Classes.SubCategory;
import DomainLayer.Controllers.ItemController;
import DomainLayer.Controllers.SubCategoryController;

import java.sql.SQLException;
import java.util.ArrayList;

public class SubCategoryService {
    private static SubCategoryService instance = null;
    private final SubCategoryController subCategoryController;

    private SubCategoryService() {
        subCategoryController = SubCategoryController.getInstance();
    }

    public static SubCategoryService getInstance() {
        if (instance == null) {
            instance = new SubCategoryService();
        }
        return instance;
    }
    //FOR TESTING PURPOSE ONLY!!!
    public SubCategoryService(SubCategoryController subCategoryController) {
        this.subCategoryController = subCategoryController;
    }

    public void loadData() throws SQLException {
        subCategoryController.loadData();
    }

    public boolean CheckSubcategoryExist(int subcategoryId) {
        return subCategoryController.getSubCategory(subcategoryId) != null;
    }

    public void AddSubCategory(String CategoryName, int subCategoryID, String subCategoryName) {
        try {
            subCategoryController.addSubCategory(CategoryName, subCategoryID, subCategoryName);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void removeSubCategory(int subCategoryID) {
        subCategoryController.removeSubCategory(subCategoryID);
    }

    public void setSubCategoryDiscount(int subcategoryID, String start_date, String end_date, double discount) {
        subCategoryController.setDiscount(subcategoryID, start_date, end_date, discount);
    }

    public ArrayList<SubCategory> retrieveAllSubcategories() {
        return subCategoryController.getTotalSubcategories();
    }

    public ArrayList<SubCategory> getSubCategories(ArrayList<Integer> subCategoryIDs) {
        return subCategoryController.getSubcategories(subCategoryIDs);
    }
}
