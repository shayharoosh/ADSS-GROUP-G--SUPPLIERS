import ServiceLayer.ActionsServices.StatusService;
import suppliers.DataAccessLayer.Database;
import suppliers.PresentationLayer.Cli;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

public class CombinedCliUseCase {
    private static final StatusService statusService = StatusService.getInstance();
    private static final WarehouseOrderReader warehouseOrderReader = WarehouseOrderReader.getInstance();
    private static final SuppliersOrderReader suppliersOrderReader = SuppliersOrderReader.getInstance();
    private static final Cli cli = new Cli();

    public void run() throws IOException {

        PL();
        System.out.println("Enter your Choice:");
        System.out.println("1.Update Storage");
        System.out.println("2.Read Order For Supplier & Create Order For Supplier");
        System.out.println("3.Read Order For Warehouse");
        System.out.println("4.Exit");
        PL();
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                System.out.println("Warehouse Storage Update Section");
                HashMap<Integer, Integer> makatToAmountInWH = new HashMap<>();
                while (true) {
                    System.out.println("Enter product makat:");
                    int makat = sc.nextInt();

                    System.out.println("Enter product amount in warehouse:");
                    int amount = sc.nextInt();

                    makatToAmountInWH.put(makat, amount);
                    System.out.println("Do you want to add another product? (y/n):");
                    String choice_ = sc.next();

                    if (choice_.equalsIgnoreCase("n")) {
                        break;
                    }
                }
                if (!makatToAmountInWH.isEmpty()) {
                    statusService.updateStorage(makatToAmountInWH);
                    System.out.println("Warehouse storage updated successfully.");
                } else {
                    System.out.println("No updates made to warehouse storage.");
                }
                this.run();
                break;

            case 2:
                System.out.println("Want to load the data or it loaded already? (enter yes/no):");
                String loadData = sc.next();
                if (loadData.equalsIgnoreCase("yes")) {
                    cli.loadData();
                }
                HashMap<Integer, Integer> productShortages = suppliersOrderReader.readOrderFromCSV();

                System.out.println("Do you want to fulfill the entire order or half? (enter full/half):");
                String orderChoice = sc.next();
                boolean fulfillHalf = orderChoice.equalsIgnoreCase("half");
                suppliersOrderReader.createOrderForSupplierAndWriteToCSV(productShortages, fulfillHalf);
                this.run();
                break;
            case 3:
                // In the next section, the warehouse team will take care of the order that just came in:
                warehouseOrderReader.ReadSuppliersOrderAndUpdateWarehouseStorage();
                PL();
                System.out.println("Warehouse Storage Updated Successfully!");
                this.run();
                break;
            case 4:
                System.out.println("Thank you for using our combined cli useCase");
                break;
        }
    }

    private static void PL() {
        System.out.println("--------------------------------------------------------------------");
    }
}
