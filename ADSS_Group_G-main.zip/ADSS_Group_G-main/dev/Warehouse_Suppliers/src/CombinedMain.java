import DomainLayer.Classes.Product;
import PresentationLayer.MainUserInterface;
import PresentationLayer.SplashScreen;
import PresentationLayer.UserInterface;
import ServiceLayer.ActionsServices.InitiatorService;
import ServiceLayer.ActionsServices.ReportService;
import suppliers.PresentationLayer.Cli;
import java.time.LocalDate;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;
import ServiceLayer.ActionsServices.ReportService;

public class CombinedMain {
    private static final ReportService reportService = ReportService.getInstance();
    private static final InitiatorService initiatorService = InitiatorService.getInstance();
    public static void main(String[] args) throws SQLException, IOException {
        SplashScreen splash = new SplashScreen(5000);
        splash.showSplash();
        PL();
        printSupermarketArt();
        PL();
        initiatorService.initiate(1);
        System.out.println("Generate report on all products ...");
        reportService.generateReportOnAllProducts();
        String day = LocalDate.now().getDayOfWeek().name();
        try {
            if (day.equals("MONDAY") || day.equals("THURSDAY")) {
                System.out.printf("--- Generating automatic system report on All Items for %s---\n", day.toLowerCase());
                ReportService.getInstance().generateReportOnAllItems();
            }
            System.out.println("--- Generating automatic system report on Expired and Defected Items ---");
            ReportService.getInstance().generateReportOnExpiredItems();
            ReportService.getInstance().generateReportOnDefectedItems();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

        PL();
        System.out.println("Enter your choice:");
        System.out.println("1. Warehouse Menu");
        System.out.println("2. Suppliers Menu");
        System.out.println("3. Combined CLI for use case");
        System.out.println("4. Exit");
        PL();

        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                MainUserInterface mainUserInterface = new MainUserInterface();
                mainUserInterface.main(null);
                break;

            case 2:
                Cli cli = new Cli();
                cli.start();
                break;

            case 3:
                CombinedCliUseCase combinedCliUseCase = new CombinedCliUseCase();
                combinedCliUseCase.run();
                break;

            case 4:
                System.out.println("Thank you and goodbye!");
                break;
        }
    }


    private static void PL() {
        System.out.println("--------------------------------------------------------------------");
    }
    public static void printSupermarketArt() {
        System.out.println(
                "         _____________________________\n" +
                        "        /                             \\\n" +
                        "       /                               \\\n" +
                        "      /_________________________________\\\n" +
                        "      |                                 |\n" +
                        "      |     SUPERMARKET LEE System      |\n" +
                        "      |                                 |\n" +
                        "      |   _______________   __________  |\n" +
                        "      |  |               | |          | |\n" +
                        "      |  |               | |          | |\n" +
                        "      |  |               | |          | |\n" +
                        "      |  |               | |          | |\n" +
                        "      |  |_______________| |__________| |\n" +
                        "      |                                 |\n" +
                        "      |_________________________________|\n" +
                        "     /___________________________________\\\n" +
                        "    /_____________________________________\\\n"
        );
    }
}