import suppliers.DataStructures.Message;
import suppliers.DomainLayer.Classes.Product;
import suppliers.DomainLayer.Controllers.Facade;
import suppliers.ServiceLayer.ProductService;

import java.io.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class SuppliersOrderReader {

    private static SuppliersOrderReader instance = null;
    private static ProductService productService = new ProductService();
    private static  Facade facade = new Facade();

    //ForTest Only
    private SuppliersOrderReader (ProductService productService, Facade facade) {
        this.productService = productService;
        this.facade = facade;
    }
    private SuppliersOrderReader() {
    }

    public static SuppliersOrderReader getInstance() {
        if (instance == null) {
            instance = new SuppliersOrderReader();
        }
        return instance;
    }

    public HashMap<Integer, Integer> readOrderFromCSV() {
        String directoryPath = PresentationLayer.ConfigReader.getProperty("output.dir") + File.separator + "Orders" + File.separator + "PendingOrders";
        File dir = new File(directoryPath);
        File[] files = dir.listFiles((d, name) -> name.startsWith("WarehouseOrderReport"));

        if (files == null || files.length == 0) {
            throw new IllegalArgumentException("No files found starting with 'WarehouseOrderReport'");
        }

        // Sort files by last modified date descending
        Arrays.sort(files, (f1, f2) -> Long.compare(f2.lastModified(), f1.lastModified()));
        File csvFile = files[0]; // Use the latest file

        HashMap<Integer, Integer> productShortages = new HashMap<>();
        String line;
        String csvSplitBy = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            if ((line = br.readLine()) != null) {
                String[] headers = line.split(csvSplitBy);
                int makatIndex = -1;
                int amountIndex = -1;

                for (int i = 0; i < headers.length; i++) {
                    if (headers[i].equalsIgnoreCase("makat")) {
                        makatIndex = i;
                    } else if (headers[i].equalsIgnoreCase("Amount")) {
                        amountIndex = i;
                    }
                }

                if (makatIndex == -1 || amountIndex == -1) {
                    throw new IllegalArgumentException("CSV file must contain 'makat' and 'Amount' columns");
                }

                while ((line = br.readLine()) != null) {
                    String[] values = line.split(csvSplitBy);
                    int makat = Integer.parseInt(values[makatIndex]);
                    int amount = Integer.parseInt(values[amountIndex]);
                    productShortages.put(makat, amount);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return productShortages;
    }

    public void createOrderForSupplierAndWriteToCSV(HashMap<Integer, Integer> productShortages, boolean fulfillHalf) {
        String directoryPath = PresentationLayer.ConfigReader.getProperty("output.dir") + File.separator + "Orders" + File.separator + "PendingOrders";
        String outputFilePath = directoryPath + File.separator + "SuppliersDeficienciesOrder.csv";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            writer.write("Supplier,ProductName,Manufacturer,Makat,Amount\n");

            for (Map.Entry<Integer, Integer> entry : productShortages.entrySet()) {
                int makat = entry.getKey();
                int amount = fulfillHalf ? entry.getValue() / 2 : entry.getValue();


                Product product = productService.getProduct(1, makat);
                if (product == null){
                    product = productService.getProduct(2, makat);
                    if (product == null) {
                        product = productService.getProduct(3, makat);
                        if (product == null) {
                            System.out.println("Product with makat " + makat + " not found.");
                            continue;
                        }
                    }
                }

                String supplier = product.getSupplierID() + "";
                String productName = product.getName();
                String manufacturer = product.getManufacturer();

                writer.write(supplier + "," + productName + "," + manufacturer + "," + makat + "," + amount + "\n");

                Message message = facade.createOrderByShortage(1, new HashMap<>(Map.of(makat, amount)));
                facade.printOrders();
                if (message.errorOccurred()) {
                    System.out.println("Error creating order for supplier: " + message.getErrorMessage());
                }
            }

            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
