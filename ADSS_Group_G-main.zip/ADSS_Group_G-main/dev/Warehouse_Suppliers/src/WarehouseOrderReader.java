import PresentationLayer.ConfigReader;
import ServiceLayer.ActionsServices.ReportService;
import ServiceLayer.ClassesServices.ItemService;
import ServiceLayer.ClassesServices.ProductService;

import java.time.LocalDate;
import java.io.File;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class WarehouseOrderReader {
    private Map<String, Integer> orderMap;
    private static WarehouseOrderReader instance = null;
    private static ItemService itemService = ItemService.getInstance();
    private static ProductService productService = ProductService.getInstance();
    private static ReportService reportService = ReportService.getInstance(); //TODO just to visualize that product amount in warehouse updated successfully


    public static WarehouseOrderReader getInstance() {
        if (instance == null) {
            instance = new WarehouseOrderReader();
        }
        return instance;
    }
    //For Tests Only
    public WarehouseOrderReader(ItemService itemService, ProductService productService, ReportService reportService) {
        this.itemService = itemService;
        this.productService = productService;
        this.reportService = reportService;
    }

    public WarehouseOrderReader() {
        this.orderMap = new HashMap<>();
    }



    public void ReadSuppliersOrderAndUpdateWarehouseStorage() throws IOException {
        PL();
        System.out.println("Updating Warehouse Storage ...");
        this.ReadOrder();
        this.UpdateOrderStatus();
        this.UpdateWarehouseStorage();
    }
    private void ReadOrder() {
        String directoryPath = ConfigReader.getProperty("output.dir") + File.separator + "Orders" + File.separator + "PendingOrders";
        String csvFile = directoryPath + File.separator + "SuppliersDeficienciesOrder.csv";
        String line;
        String csvSplitBy = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            if ((line = br.readLine()) != null) {
                String[] headers = line.split(csvSplitBy);
                int makatIndex = -1;
                int amountIndex = -1;

                // find the indices of "makat" and "Amount" columns
                for (int i = 0; i < headers.length; i++) {
                    if (headers[i].equalsIgnoreCase("makat")) {
                        makatIndex = i;
                    } else if (headers[i].equalsIgnoreCase("Amount")) {
                        amountIndex = i;
                    }
                }

                // check if both "makat" and "Amount" columns are found
                if (makatIndex == -1 || amountIndex == -1) {
                    throw new IllegalArgumentException("CSV file must contain 'makat' and 'Amount' columns");
                }

                while ((line = br.readLine()) != null) {
                    String[] values = line.split(csvSplitBy);
                    String makat = values[makatIndex];
                    int amount = Integer.parseInt(values[amountIndex]);
                    this.orderMap.put(makat, amount);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void UpdateOrderStatus(){
        // TODO : Monika : lambda -> (X | X in progress)
    }

    private void UpdateWarehouseStorage() throws IOException {
        LocalDate expirationDate = LocalDate.now().plusMonths(1); // date will be now + 1 month
        boolean toStore = false;

        // iterate over the hash map and update each product & write all to the db
        for (Map.Entry<String, Integer> entry : orderMap.entrySet()) {
            String makatStr = entry.getKey();
            int makat = Integer.parseInt(makatStr);
            int amount = entry.getValue();
            itemService.addItem(amount, makat, expirationDate, toStore);

            // update current product amount in warehouse

            productService.IncreaseProductCurrentAmount(makat, amount, false);
        }
        // Generating report on all products in order to make sure everything is working ...
        PL();
        System.out.println("Generating report on all products for verification ...");
        reportService.generateReportOnAllProducts();
        PL();
    }

    private static void PL() {
        System.out.println("--------------------------------------------------------------------");
    }

}