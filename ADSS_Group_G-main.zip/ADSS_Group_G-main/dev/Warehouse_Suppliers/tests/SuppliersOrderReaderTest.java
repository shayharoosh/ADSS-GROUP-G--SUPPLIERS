import org.junit.jupiter.api.*;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import suppliers.DomainLayer.Classes.Product;
import suppliers.DomainLayer.Controllers.Facade;
import suppliers.ServiceLayer.ProductService;
import suppliers.DataStructures.Message;

import java.util.HashMap;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class SuppliersOrderReaderTest {

    @Mock
    private ProductService productService;

    @Mock
    private Facade facade;

    private SuppliersOrderReader reader;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        reader = SuppliersOrderReader.getInstance();
        // Inject mocks
        setPrivateField(reader, "productService", productService);
        setPrivateField(reader, "facade", facade);
    }

    @Test
    void testReadOrderFromCSV() {
        // Mock behavior
        when(productService.getProduct(anyInt(), anyInt())).thenReturn(new Product());

        HashMap<Integer, Integer> result = reader.readOrderFromCSV();

        // Verify the result
        assertNotNull(result);
        // Add more assertions based on expected behavior
    }

    @Test
    void testCreateOrderForSupplierAndWriteToCSV() {
        HashMap<Integer, Integer> productShortages = new HashMap<>();
        productShortages.put(1234, 10);

        // Mock behavior
        when(productService.getProduct(anyInt(), anyInt())).thenReturn(new Product());
        when(facade.createOrderByShortage(anyInt(), any())).thenReturn(new Message());

        reader.createOrderForSupplierAndWriteToCSV(productShortages, false);

        // Verify interactions
        verify(productService, times(1)).getProduct(anyInt(), eq(1234));
        verify(facade, times(1)).createOrderByShortage(anyInt(), any());
        verify(facade, times(1)).printOrders();
    }

    // Helper method to set private fields
    private void setPrivateField(Object object, String fieldName, Object fieldValue) {
        try {
            java.lang.reflect.Field field = object.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(object, fieldValue);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }
}