import org.junit.jupiter.api.*;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import ServiceLayer.ActionsServices.ReportService;
import ServiceLayer.ClassesServices.ItemService;
import ServiceLayer.ClassesServices.ProductService;

import java.io.IOException;
import static org.mockito.Mockito.*;

class WarehouseOrderReaderTest {

    @Mock
    private ItemService itemService;

    @Mock
    private ProductService productService;

    @Mock
    private ReportService reportService;

    private WarehouseOrderReader reader;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        reader = WarehouseOrderReader.getInstance();
        setPrivateField(reader, "itemService", itemService);
        setPrivateField(reader, "productService", productService);
        setPrivateField(reader, "reportService", reportService);
    }

    @Test
    void testReadSuppliersOrderAndUpdateWarehouseStorage() throws IOException {
        reader.ReadSuppliersOrderAndUpdateWarehouseStorage();

        // Verify that these methods are called
        verify(itemService, atLeastOnce()).addItem(anyInt(), anyInt(), any(), anyBoolean());
        verify(productService, atLeastOnce()).IncreaseProductCurrentAmount(anyInt(), anyInt(), anyBoolean());
        verify(reportService, atLeastOnce()).generateReportOnAllProducts();
    }

    private void setPrivateField(Object object, String fieldName, Object fieldValue) {
        try {
            java.lang.reflect.Field field = object.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(object, fieldValue);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }
}